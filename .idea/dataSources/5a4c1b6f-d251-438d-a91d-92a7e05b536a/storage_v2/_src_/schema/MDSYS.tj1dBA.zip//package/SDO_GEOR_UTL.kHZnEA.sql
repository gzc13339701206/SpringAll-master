create PACKAGE       SDO_GEOR_UTL AUTHID CURRENT_USER AS

-- ---------------------------------------------------------------------
--      procedure to create DML triggers on a georaster table
-- ---------------------------------------------------------------------

PROCEDURE createDMLTrigger
(
    tableName      varchar2,
    columnName     varchar2
);

-- ---------------------------------------------------------------------
-- NAME
--   renameRDT
--
-- DESCRIPTION
--   This routine renames raster data table(s) owned by the current user.
--   It will update all related GeoRaster objects and GeoRaster system
--   data coorespondingly.
--
-- ARGUMENTS
--   oldRDTs - name(s) of existing raster data table(s) to be renamed
--   newRDTs - name(s) of new raster data table(s)
--
-- NOTES
--
--   This routine renames RDTs owned by the current user.
--
--   The RDT names in the strings are seperated with ','.
--   If an oldRDT does not appear in the GeoRaster sysdata, it is ignored.
--   If a newRDT is not unique in the GeoRaster sysdata, ORA-13403 is raised.
--   If a newRDT is NULL, a unique RDT name is automatically generated.
-- ---------------------------------------------------------------------
PROCEDURE renameRDT
(
   oldRDTs VARCHAR2,
   newRDTs VARCHAR2 DEFAULT NULL
);

-- ---------------------------------------------------------------------
-- NAME
--   makeRDTnamesUnique
--
-- DESCRIPTION
--   This routine resolves conflicting raster data table names by
--   automatically renaming some of them so that all raster data tables
--   are uniquely named afterwards.
--
-- ARGUMENTS
--   None.
--
-- NOTES
--   This routine is part of the fix for bug 3703288. In addition to applying
--   the necessary patchset that fixes this bug, an Oracle database of
--   version 10.1.0.2 or 10.1.0.3 needs to run this routine to resolve
--   potential RDT name conflicts. User may choose to run the above
--   renameRDT() to explicitly rename existing RDTs before run this
--   routine.
--
--   This routine should be run while connected as a user with the DBA role.
--
-- ---------------------------------------------------------------------
PROCEDURE makeRDTnamesUnique;

END SDO_GEOR_UTL;
/

