create PACKAGE sdo_rdf AUTHID CURRENT_USER AS

	FUNCTION get_model_id (
		model_name IN VARCHAR2
	) RETURN NUMBER ;

	FUNCTION is_triple (
		model_id IN NUMBER,
		rdf_t_id IN NUMBER
	) RETURN VARCHAR2 ;

	FUNCTION is_triple (
		model_name IN VARCHAR2,
		rdf_t_id IN NUMBER
	) RETURN VARCHAR2 ;

	FUNCTION is_triple (
		model_id IN NUMBER,
		subject IN VARCHAR2,
		property IN VARCHAR2,
		object IN VARCHAR2
	) RETURN VARCHAR2 ;

	FUNCTION is_triple (
		model_name IN VARCHAR2,
		subject IN VARCHAR2,
		property IN VARCHAR2,
		object IN VARCHAR2
	) RETURN VARCHAR2 ;

	FUNCTION get_triple_id (
		model_id IN NUMBER,
		subject IN VARCHAR2,
		property IN VARCHAR2,
		object IN VARCHAR2
	) RETURN NUMBER ;

	FUNCTION get_triple_id (
		model_name IN VARCHAR2,
		subject IN VARCHAR2,
		property IN VARCHAR2,
		object IN VARCHAR2
	) RETURN NUMBER ;

	FUNCTION is_reified_quad (
		model_id IN NUMBER,
		subject IN VARCHAR2,
		property IN VARCHAR2,
		object IN VARCHAR2
	) RETURN VARCHAR2 ;

	FUNCTION is_reified_quad (
		model_name IN VARCHAR2,
		subject IN VARCHAR2,
		property IN VARCHAR2,
		object IN VARCHAR2
	) RETURN VARCHAR2 ;

	PROCEDURE add_namespaces (
		namespace_1 IN VARCHAR2,
		namespace_2 IN VARCHAR2 DEFAULT NULL,
		namespace_3 IN VARCHAR2 DEFAULT NULL
	);

       PROCEDURE create_rdf_model (model_name IN VARCHAR2, table_name IN VARCHAR2, column_name IN VARCHAR2);
       PROCEDURE drop_rdf_model (model_name IN VARCHAR2);
       PROCEDURE create_rdf_network (tablespace_name in varchar2);
       PROCEDURE drop_rdf_network ;

END sdo_rdf ;
/

