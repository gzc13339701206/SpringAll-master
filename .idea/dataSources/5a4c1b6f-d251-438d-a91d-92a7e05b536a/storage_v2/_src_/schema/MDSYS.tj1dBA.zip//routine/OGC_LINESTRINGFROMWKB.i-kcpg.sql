create FUNCTION OGC_LineStringFromWKB(
  wkb   IN BLOB,
  srid  IN INTEGER DEFAULT NULL)
    RETURN LineString IS
BEGIN
  RETURN TREAT(ST_GEOMETRY.FROM_WKB(wkb, srid) AS LineString);
END OGC_LineStringFromWKB;
/

