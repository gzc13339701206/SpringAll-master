create type RDF_Alias as object (
      namespace_id  varchar2(30),
      namespace_val varchar2(4000))
/

