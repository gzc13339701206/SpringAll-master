create FUNCTION OGC_InteriorRingN(
  p Polygon,
  n Integer)
    RETURN LineString IS
  arr ST_LineString_Array;
BEGIN
  arr := p.ST_InteriorRingsP();
  RETURN arr(n);
END OGC_InteriorRingN;
/

