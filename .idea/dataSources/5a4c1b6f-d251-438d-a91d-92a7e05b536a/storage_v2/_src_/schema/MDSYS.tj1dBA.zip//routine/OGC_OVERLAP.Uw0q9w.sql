create FUNCTION OGC_Overlap(
  g1 Geometry,
  g2 Geometry)
    RETURN Integer IS
BEGIN
  RETURN g1.ST_Overlap(g2);
END OGC_Overlap;
/

