create FUNCTION OGC_GeometryN(
  g GeometryCollection,
  n Integer)
    RETURN Geometry IS
  arr ST_GEOMETRY_ARRAY;
BEGIN
  arr := g.ST_Geometries();
  RETURN arr(n);
END OGC_GeometryN;
/

