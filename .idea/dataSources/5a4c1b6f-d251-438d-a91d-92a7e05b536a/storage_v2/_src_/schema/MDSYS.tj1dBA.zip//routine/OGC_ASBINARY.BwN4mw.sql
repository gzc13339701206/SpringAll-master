create FUNCTION OGC_AsBinary(
  g Geometry)
    RETURN BLOB IS
BEGIN
  RETURN g.GET_WKB();
END OGC_AsBinary;
/

