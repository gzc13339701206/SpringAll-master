create TYPE sdo_rdf_triple_s
                                                                             AS OBJECT
	(rdf_t_id NUMBER,
	rdf_m_id NUMBER,
	rdf_s_id NUMBER,
	rdf_p_id NUMBER,
	rdf_o_id NUMBER,
	CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
					subject VARCHAR2,
					property VARCHAR2,
					object VARCHAR2)
	RETURN SELF AS RESULT DETERMINISTIC,
	CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
					subject VARCHAR2,
					property VARCHAR2,
					object CLOB)
	RETURN SELF AS RESULT DETERMINISTIC,
	CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
					sub_or_bn VARCHAR2,
					property VARCHAR2,
					obj_or_bn VARCHAR2,
					bn_m_id NUMBER)
	RETURN SELF AS RESULT DETERMINISTIC,
	CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
					sub_or_bn VARCHAR2,
					property VARCHAR2,
					object CLOB,
					bn_m_id NUMBER)
	RETURN SELF AS RESULT DETERMINISTIC,
	CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
					rdf_t_id NUMBER)
	RETURN SELF AS RESULT DETERMINISTIC,
	CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
					rdf_t_id NUMBER,
					property VARCHAR2,
					object VARCHAR2)
	RETURN SELF AS RESULT DETERMINISTIC,
	CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
					subject VARCHAR2,
					property VARCHAR2,
					rdf_t_id NUMBER)
	RETURN SELF AS RESULT DETERMINISTIC,
	CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
					s_rdf_t_id NUMBER,
					property VARCHAR2,
					o_rdf_t_id NUMBER)
	RETURN SELF AS RESULT DETERMINISTIC,
	CONSTRUCTOR FUNCTION sdo_rdf_triple_s(model_name VARCHAR2,
					reif_subject VARCHAR2,
					reif_property VARCHAR2,
					subject VARCHAR2,
					property VARCHAR2,
					object VARCHAR2)
	RETURN SELF AS RESULT DETERMINISTIC,
	MEMBER FUNCTION get_triple RETURN SDO_RDF_TRIPLE DETERMINISTIC,
	MEMBER FUNCTION get_object RETURN CLOB DETERMINISTIC,
	MEMBER FUNCTION get_subject RETURN VARCHAR2 DETERMINISTIC,
	MEMBER FUNCTION get_property RETURN VARCHAR2 DETERMINISTIC
	)
/

