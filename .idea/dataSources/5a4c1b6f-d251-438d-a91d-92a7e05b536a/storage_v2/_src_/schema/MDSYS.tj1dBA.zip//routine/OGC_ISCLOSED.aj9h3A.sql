create FUNCTION OGC_IsClosed(
  g Geometry)
    RETURN Integer DETERMINISTIC IS
BEGIN
  IF(UPPER(GeometryType(g)) IN ('LINESTRING', 'ST_CIRCULARSTRING', 'ST_COMPOUNDCURVE')) THEN
    RETURN TREAT(g AS Curve).ST_IsClosed();
  END IF;
  IF(UPPER(GeometryType(g)) IN ('MULTILINESTRING')) THEN
    RETURN TREAT(g AS MultiCurve).ST_IsClosed();
  END IF;
  RETURN NULL;
END OGC_IsClosed;
/

