create PACKAGE SDO_ROUTER_PARTITION AUTHID current_user AS

  PROCEDURE create_node_part;

  PROCEDURE create_super_tables;

  FUNCTION min_eigenvector(sum_x2 IN NUMBER, sum_y2 IN NUMBER, sum_xy IN NUMBER)
    RETURN mdsys.vector_2d;

  FUNCTION table_exists(tab_name in VARCHAR2)
    RETURN VARCHAR2;

  PROCEDURE create_test_table(p_tab_name IN VARCHAR2, n IN NUMBER);

  FUNCTION adjust_m(start_m IN NUMBER, end_m IN NUMBER, m IN NUMBER)
    RETURN NUMBER;

  FUNCTION get_pid(m IN NUMBER, pid IN NUMBER)
    RETURN NUMBER;


  PROCEDURE adjust_final_pid(p_tab_name IN VARCHAR2);

  PROCEDURE make_partition_equal(tab_name IN VARCHAR2,
                                  pid IN NUMBER,
                                  v_no IN NUMBER,
                                  part_counter IN NUMBER);

  PROCEDURE new_partition_proc(p_tab_name IN VARCHAR2,
                                max_v_no IN NUMBER,
                                partition_id IN NUMBER,
                                make_equal IN BOOLEAN,
                                part_counter IN OUT NUMBER);

  PROCEDURE graph_partition(p_tab_name IN VARCHAR2,
                            max_v_no IN NUMBER,
                            make_equal IN BOOLEAN);

  PROCEDURE recover_graph_partition(p_tab_name IN VARCHAR2,
                                    min_pid IN NUMBER,
                                    max_pid IN NUMBER,
                                    p_level IN NUMBER,
                                    max_v_no IN NUMBER,
                                    make_equal IN BOOLEAN);

  PROCEDURE clean_tables;

  PROCEDURE drop_tmp_tables;

  PROCEDURE partition_router(p_tab_name IN VARCHAR2 := 'NODE_PART',
                          max_v_no IN NUMBER DEFAULT 10000,
                          make_equal IN BOOLEAN DEFAULT TRUE);

  PROCEDURE run_test_partition(p_tab_name IN VARCHAR2,
                                v_no IN NUMBER,
                                max_v_no IN NUMBER,
                                make_equal IN BOOLEAN);

  PROCEDURE elocation_partition(node_tab_name IN VARCHAR2,
                                edge_tab_name IN VARCHAR2,
                                max_v_no IN NUMBER,
                                is_directed IN BOOLEAN);

  PROCEDURE elocation_prepare_blob(node_tab_name IN VARCHAR2,
                                    node_part_tab_name IN VARCHAR2,
                                    edge_tab_name IN VARCHAR2 );

  PROCEDURE build_partition_graph(v_tab IN VARCHAR2,
                                  e_tab IN VARCHAR2,
                                  p_v_tab IN VARCHAR2,
                                  p_e_tab IN VARCHAR2,
                                  is_directed IN BOOLEAN);

  PROCEDURE elocation_test_tables(node_tab_name IN VARCHAR2,
                                  edge_tab_name IN VARCHAR2,
                                  n IN NUMBER);

  PROCEDURE update_elocation_node(in_node_tab IN VARCHAR2,
                                  out_node_tab IN VARCHAR2,
                                  node_part_tab IN VARCHAR2);

  PROCEDURE update_elocation_edge(in_edge_tab IN VARCHAR2,
                                  out_edge_tab IN VARCHAR2,
                                  node_part_tab IN VARCHAR2);

  PROCEDURE prepare_partition_edge(edge_tab IN VARCHAR2,
                                    edge_part_tab IN VARCHAR2,
                                    node_part_tab IN VARCHAR2);

  FUNCTION outedge_array(p_id IN NUMBER, edge_part_tab IN VARCHAR2)
    RETURN mdsys.num_array;

  FUNCTION node_outedges(node_id IN NUMBER, edge_part_tab IN VARCHAR2)
    RETURN mdsys.num_array;

  FUNCTION node_inedges(node_id IN NUMBER, edge_part_tab IN VARCHAR2)
    RETURN mdsys.num_array;

  PROCEDURE elocation_partition_router AS LANGUAGE java
    NAME
 'oracle.spatial.router.partitioning.ElocationPartition.partition_router()';

  FUNCTION get_geometry_info(edge_ids       IN  sdo_list_type,
                             merged_coords  OUT sdo_list_type)
  RETURN NUMBER;

  FUNCTION get_edge_info(edge_ids       IN  sdo_list_type,
                           to_edge_ids  OUT sdo_list_type,
                           rets         OUT mdsys.string_array)
  RETURN mdsys.string_array ;

END SDO_ROUTER_PARTITION;
/

