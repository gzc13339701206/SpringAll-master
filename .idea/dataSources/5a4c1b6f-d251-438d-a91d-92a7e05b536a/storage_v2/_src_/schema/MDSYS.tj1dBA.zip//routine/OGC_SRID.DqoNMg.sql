create FUNCTION OGC_SRID(
  g Geometry)
    RETURN Integer IS
BEGIN
  RETURN g.ST_SRID();
END OGC_SRID;
/

