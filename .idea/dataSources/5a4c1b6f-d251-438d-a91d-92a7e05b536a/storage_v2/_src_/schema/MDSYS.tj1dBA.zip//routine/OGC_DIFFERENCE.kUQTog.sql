create FUNCTION OGC_Difference(
  g1 Geometry,
  g2 Geometry)
    RETURN Geometry IS
BEGIN
  RETURN g1.ST_Difference(g2);
END OGC_Difference;
/

