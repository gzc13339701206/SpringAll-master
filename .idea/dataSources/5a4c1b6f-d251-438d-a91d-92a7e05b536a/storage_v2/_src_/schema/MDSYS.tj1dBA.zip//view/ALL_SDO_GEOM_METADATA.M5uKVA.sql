create view ALL_SDO_GEOM_METADATA as
SELECT SDO_OWNER OWNER,
       SDO_TABLE_NAME TABLE_NAME,
       SDO_COLUMN_NAME COLUMN_NAME,
       SDO_DIMINFO DIMINFO,
       SDO_SRID SRID
FROM SDO_GEOM_METADATA_TABLE
WHERE
(exists
   (select table_name from all_tables
    where table_name=sdo_table_name
      and owner = sdo_owner
    union all
      select table_name from all_object_tables
      where table_name=sdo_table_name
      and owner = sdo_owner
    union all
      select SYNONYM_NAME from all_synonyms
      where SYNONYM_NAME=sdo_table_name
      and owner = sdo_owner
    union all
    select view_name table_name from all_views
    where  view_name=sdo_table_name
      and owner = sdo_owner))
/

