create PACKAGE sdo_idx AUTHID current_user AS

  FUNCTION imp_exp(ia IN sys.odciindexinfo,  newblock OUT PLS_INTEGER)
          RETURN varchar2;
  PROCEDURE ie_crt_geom_metadata;

  PROCEDURE cmt_idx_chngs(schema varchar2, iname varchar2,
		          iptn varchar2, tnum number);

  PROCEDURE tts_index_initialize( owner varchar2, iname varchar2);

  FUNCTION  process_params(params IN varchar2, invert_mask IN number,
			   mask_str IN OUT varchar2, dst IN OUT number,
			   units_str IN OUT varchar2, mltpl_msks IN OUT number)
   	    RETURN number;


END sdo_idx;
/

