create FUNCTION OGC_SymmetricDifference(
  g1 Geometry,
  g2 Geometry)
    RETURN Geometry DETERMINISTIC IS
BEGIN
  RETURN g1.ST_SymmetricDifference(g2);
END OGC_SymmetricDifference;
/

