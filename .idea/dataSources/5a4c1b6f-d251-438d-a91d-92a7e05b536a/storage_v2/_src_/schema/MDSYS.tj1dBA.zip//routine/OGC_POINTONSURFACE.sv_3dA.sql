create FUNCTION OGC_PointOnSurface(
  s Geometry)
    RETURN Point DETERMINISTIC IS
BEGIN
  IF(UPPER(GeometryType(s)) IN ('POLYGON')) THEN
    RETURN TREAT(s AS Surface).ST_PointOnSurface();
  END IF;
  IF(UPPER(GeometryType(s)) IN ('MULTIPOLYGON')) THEN
    RETURN TREAT(s AS MultiSurface).ST_PointOnSurface();
  END IF;
  RETURN NULL;
END OGC_PointOnSurface;
/

