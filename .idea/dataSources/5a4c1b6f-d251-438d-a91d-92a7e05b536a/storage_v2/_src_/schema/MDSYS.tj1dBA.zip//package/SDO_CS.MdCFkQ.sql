create PACKAGE sdo_cs AUTHID current_user AS

  -- for TRANSFORM operator: trusted callout interface
  FUNCTION transform_orig(geom IN mdsys.sdo_geometry,
                     dim  IN mdsys.sdo_dim_array,
                     to_srid IN NUMBER)
              RETURN mdsys.sdo_geometry DETERMINISTIC;
  PRAGMA restrict_references(transform_orig, wnds, rnps, wnps);

  FUNCTION transform_orig(geom IN mdsys.sdo_geometry,
                     tolerance  IN number,
                     to_srid IN NUMBER)
              RETURN mdsys.sdo_geometry DETERMINISTIC;
  PRAGMA restrict_references(transform_orig, wnds, rnps, wnps);

  FUNCTION transform_orig(geom   IN mdsys.sdo_geometry,
                     to_srid   IN NUMBER)
              RETURN mdsys.sdo_geometry DETERMINISTIC;
  PRAGMA restrict_references(transform_orig, wnds, rnps, wnps);

  FUNCTION transform_orig(geom   IN mdsys.sdo_geometry,
                     dim    IN mdsys.sdo_dim_array,
                     to_srname IN VARCHAR2)
              RETURN mdsys.sdo_geometry DETERMINISTIC;
--  PRAGMA restrict_references(transform_orig, wnds, rnps, wnps);

  FUNCTION transform_orig(geom   IN mdsys.sdo_geometry,
                     tolerance    IN number,
                     to_srname IN VARCHAR2)
              RETURN mdsys.sdo_geometry DETERMINISTIC;
--  PRAGMA restrict_references(transform_orig, wnds, rnps, wnps);

  FUNCTION transform_orig(geom   IN mdsys.sdo_geometry,
                     to_srname IN VARCHAR2)
              RETURN mdsys.sdo_geometry DETERMINISTIC;
--  PRAGMA restrict_references(transform_orig, wnds, rnps, wnps);

  PROCEDURE transform_layer( table_in   IN  VARCHAR2,
                            column_in  IN  VARCHAR2,
                            table_out  IN  VARCHAR2,
                            to_srid    IN  NUMBER   );
  FUNCTION viewport_transform(geom IN mdsys.sdo_geometry,
                               to_srid   IN NUMBER)
              RETURN mdsys.sdo_geometry DETERMINISTIC;
  PRAGMA restrict_references(viewport_transform, wnds, rnps, wnps);
--  FUNCTION viewport_transform(geom IN mdsys.sdo_geometry,
--                               to_srname   IN VARCHAR2)
--              RETURN mdsys.sdo_geometry DETERMINISTIC;
--  PRAGMA restrict_references(transform, wnds, rnps, wnps);
  FUNCTION validate_wkt(srid in NUMBER)
     RETURN varchar2;
  PRAGMA restrict_references(validate_wkt, wnds, rnps, wnps);

  PROCEDURE transform_layer(
    table_in  IN VARCHAR2,
    column_in IN VARCHAR2,
    table_out IN VARCHAR2,
    use_plan  IN TFM_PLAN);

  PROCEDURE transform_layer(
    table_in  IN VARCHAR2,
    column_in IN VARCHAR2,
    table_out IN VARCHAR2,
    use_case  IN VARCHAR2,
    to_srid   IN NUMBER);

  FUNCTION determine_default_chain(
    source_srid IN NUMBER,
    target_srid IN NUMBER)
      RETURN SDO_SRID_CHAIN;

  FUNCTION determine_chain(
    transient_rule_set  IN SDO_TRANSIENT_RULE_SET,
    use_case            IN VARCHAR2,
    source_srid         IN NUMBER,
    target_srid         IN NUMBER)
      RETURN TFM_PLAN;

  FUNCTION internal_det_chain_VARCHAR(
    plan IN TFM_PLAN)
      RETURN VARCHAR2;

  FUNCTION internal_det_chain(
    transient_rule_set  IN SDO_TRANSIENT_RULE_SET,
    use_case            IN VARCHAR2,
    source_srid         IN NUMBER,
    target_srid         IN NUMBER,
    explain             IN BOOLEAN,
    explanation         OUT VARCHAR2)
      RETURN TFM_PLAN;

  FUNCTION internal_det_srid_wkt(
    srid1 NUMBER)
      RETURN VARCHAR2;

  FUNCTION internal_epsg_param_to_legacy(
    param_id  NUMBER,
    method_id NUMBER)
      RETURN VARCHAR2;

  FUNCTION map_oracle_srid_to_epsg(
    legacy_srid NUMBER)
      RETURN NUMBER;

  FUNCTION map_epsg_srid_to_oracle(
    epsg_srid NUMBER)
      RETURN NUMBER;

  PROCEDURE create_pref_concatenated_op(
    op_id     IN NUMBER,
    op_name   IN VARCHAR2,
    use_plan  IN TFM_PLAN,
    use_case  IN VARCHAR2);

  PROCEDURE create_concatenated_op(
    op_id     IN NUMBER,
    op_name   IN VARCHAR2,
    use_plan  IN TFM_PLAN);

  PROCEDURE delete_op(
    op_id     IN NUMBER);

  PROCEDURE add_preference_for_op(
    op_id       IN NUMBER,
    source_crs  IN NUMBER   DEFAULT NULL,
    target_crs  IN NUMBER   DEFAULT NULL,
    use_case    IN VARCHAR2 DEFAULT NULL);

  PROCEDURE revoke_preference_for_op(
    op_id       IN NUMBER,
    source_crs  IN NUMBER   DEFAULT NULL,
    target_crs  IN NUMBER   DEFAULT NULL,
    use_case    IN VARCHAR2 DEFAULT NULL);

  PROCEDURE create_obvious_epsg_rules(
    use_case    IN VARCHAR2 DEFAULT NULL);

  PROCEDURE delete_all_epsg_rules(
    use_case    IN VARCHAR2 DEFAULT NULL);

  FUNCTION transform_to_base_unit(
    value           IN NUMBER,
    source_unit_id  IN NUMBER)
      RETURN NUMBER;

  FUNCTION transform_to_wkt_param_unit(
    value                     IN NUMBER,
    source_unit_id            IN NUMBER,
    target_unit_id_if_length  IN NUMBER)
      RETURN NUMBER;

  PROCEDURE create_crs_using_legacy_proj(
    epsg_srid   IN NUMBER,
    new_srid    IN NUMBER);

  ------------------------------------------------------------------------------

  FUNCTION internal_densify_prior_to_tfm(
    mbr SDO_GEOMETRY)
      RETURN SDO_GEOMETRY;
  PRAGMA restrict_references(internal_densify_prior_to_tfm, wnds, rnps, wnps);

  ------------------------------------------------------------------------------

  FUNCTION transform(
    geom    IN MDSYS.SDO_GEOMETRY,
    dim     IN MDSYS.SDO_DIM_ARRAY,
    to_srid IN NUMBER)
      RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;
  PRAGMA restrict_references(transform, wnds, rnps, wnps);

  FUNCTION transform(
    geom      IN MDSYS.SDO_GEOMETRY,
    tolerance IN NUMBER,
    to_srid   IN NUMBER)
      RETURN MDSYS.SDO_GEOMETRY;
  PRAGMA restrict_references(transform, wnds, rnps, wnps);

  FUNCTION transform(
    geom    IN MDSYS.SDO_GEOMETRY,
    to_srid IN NUMBER)
      RETURN MDSYS.SDO_GEOMETRY;
  PRAGMA restrict_references(transform, wnds, rnps, wnps);

  FUNCTION transform(
    geom      IN MDSYS.SDO_GEOMETRY,
    dim       IN MDSYS.SDO_DIM_ARRAY,
    to_srname IN  VARCHAR2)
      RETURN MDSYS.SDO_GEOMETRY;
--  PRAGMA restrict_references(transform, wnds, rnps, wnps);

  FUNCTION transform(
    geom      IN MDSYS.SDO_GEOMETRY,
    tolerance IN NUMBER,
    to_srname IN VARCHAR2)
      RETURN MDSYS.SDO_GEOMETRY;
--  PRAGMA restrict_references(transform, wnds, rnps, wnps);

  FUNCTION transform(
    geom      IN MDSYS.SDO_GEOMETRY,
    to_srname IN VARCHAR2)
      RETURN MDSYS.SDO_GEOMETRY;
--  PRAGMA restrict_references(transform, wnds, rnps, wnps);

  ------------------------------------------------------------------------------

  PROCEDURE convert_NADCON_to_XML(
    LAA_CLOB  IN CLOB,
    LOA_CLOB  IN CLOB,
    xml_grid  OUT XMLTYPE);

  PROCEDURE convert_NTv2_to_XML(
    NTv2_CLOB IN CLOB,
    xml_grid  OUT XMLTYPE);

  PROCEDURE convert_XML_to_NADCON(
    xml_grid  IN XMLTYPE,
    LAA_CLOB  OUT CLOB,
    LOA_CLOB  OUT CLOB);

  PROCEDURE convert_XML_to_NTv2(
    xml_grid  IN XMLTYPE,
    NTv2_CLOB OUT CLOB);

  FUNCTION find_geog_crs(
    reference_srid          IN NUMBER,
    is_legacy               IN VARCHAR2,
    max_rel_num_difference  IN NUMBER DEFAULT 0.000001)
      RETURN SDO_SRID_LIST;

  FUNCTION find_proj_crs(
    reference_srid          IN NUMBER,
    is_legacy               IN VARCHAR2,
    max_rel_num_difference  IN NUMBER DEFAULT 0.000001)
      RETURN SDO_SRID_LIST;

  FUNCTION get_epsg_data_version
    RETURN VARCHAR2;

  ------------------------------------------------------------------------------

  FUNCTION from_OGC_SimpleFeature_SRS(
    wkt VARCHAR2)
      RETURN VARCHAR2;

  FUNCTION to_OGC_SimpleFeature_SRS(
    wkt VARCHAR2)
      RETURN VARCHAR2;

  ------------------------------------------------------------------------------

  PROCEDURE intl_populate_datum_7params(
    datum_id  NUMBER,
    op_id     NUMBER);

  ------------------------------------------------------------------------------

  FUNCTION to_USNG(
    geom              SDO_GEOMETRY,
    accuracyInMeters  NUMBER,
    datum             VARCHAR2 DEFAULT 'NAD83')
      RETURN
        VARCHAR2;

  FUNCTION from_USNG(
    usng              VARCHAR2,
    srid              NUMBER,
    datum             VARCHAR2 DEFAULT 'NAD83')
      RETURN SDO_GEOMETRY;

  ------------------------------------------------------------------------------

  PROCEDURE update_wkts_for_all_epsg_crs;

  PROCEDURE update_wkts_for_epsg_crs(
    srid NUMBER);

  PROCEDURE update_wkts_for_epsg_param(
    coord_op_id   NUMBER,
    parameter_id  NUMBER);

  PROCEDURE update_wkts_for_epsg_op(
    coord_op_id   NUMBER);

  PROCEDURE update_wkts_for_epsg_datum(
    datum_id NUMBER);

  PROCEDURE update_wkts_for_epsg_ellips(
    ellipsoid_id NUMBER);

  PROCEDURE update_wkts_for_epsg_pm(
    prime_meridian_id NUMBER);

END sdo_cs;
/

