create view USER_SDO_NETWORK_USER_DATA as
SELECT  network, table_type, data_name, data_type,data_length
    FROM  sdo_network_user_data
    WHERE sdo_owner = sys_context('USERENV', 'CURRENT_SCHEMA')
/

create trigger SDO_NETWORK_UD_INS_TRIG
  instead of insert
  on USER_SDO_NETWORK_USER_DATA
  for each row
-- missing source code
/

create trigger SDO_NETWORK_UD_DEL_TRIG
  instead of delete
  on USER_SDO_NETWORK_USER_DATA
  for each row
-- missing source code
/

create trigger SDO_NETWORK_UD_UPD_TRIG
  instead of update
  on USER_SDO_NETWORK_USER_DATA
  for each row
-- missing source code
/

