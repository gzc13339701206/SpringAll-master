create view USER_SDO_LRS_METADATA as
SELECT 	SDO_TABLE_NAME 	TABLE_NAME,
	SDO_COLUMN_NAME COLUMN_NAME,
	SDO_DIM_POS 	DIM_POS,
	SDO_DIM_UNIT 	DIM_UNIT
FROM SDO_LRS_METADATA_TABLE,
     (select sys_context('userenv', 'CURRENT_SCHEMA') username from dual)
WHERE  sdo_owner = username
/

create trigger SDO_LRS_TRIG_INS
  instead of insert
  on USER_SDO_LRS_METADATA
  for each row
-- missing source code
/

create trigger SDO_LRS_TRIG_DEL
  instead of delete
  on USER_SDO_LRS_METADATA
  for each row
-- missing source code
/

create trigger SDO_LRS_TRIG_UPD
  instead of update
  on USER_SDO_LRS_METADATA
  for each row
-- missing source code
/

