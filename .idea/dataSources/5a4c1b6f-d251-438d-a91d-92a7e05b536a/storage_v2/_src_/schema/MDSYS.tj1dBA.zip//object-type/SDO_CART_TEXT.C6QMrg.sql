create TYPE SDO_CART_TEXT
                                                                                   AS OBJECT (
       VALUE           VARCHAR2(4000),
       LOCATION         SDO_GEOMETRY,
       TEXT_ATTRIBUTES  XMLType,
       LEADER_LINE      SDO_GEOMETRY,
       ENVELOPE         SDO_GEOMETRY )
/

