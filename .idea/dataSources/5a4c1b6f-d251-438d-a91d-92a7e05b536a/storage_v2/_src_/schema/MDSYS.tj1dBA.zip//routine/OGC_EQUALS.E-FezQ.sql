create FUNCTION OGC_Equals(
  g1 Geometry,
  g2 Geometry)
    RETURN Integer DETERMINISTIC IS
BEGIN
  RETURN g1.ST_Equals(g2);
END OGC_Equals;
/

