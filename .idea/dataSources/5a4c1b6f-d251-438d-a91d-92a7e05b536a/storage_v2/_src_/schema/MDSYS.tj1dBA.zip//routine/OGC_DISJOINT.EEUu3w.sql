create FUNCTION OGC_Disjoint(
  g1 Geometry,
  g2 Geometry)
    RETURN Integer IS
BEGIN
  RETURN g1.ST_Disjoint(g2);
END OGC_Disjoint;
/

