create FUNCTION OGC_MultiLineStringFromWKB(
  wkb   IN BLOB,
  srid  IN INTEGER DEFAULT NULL)
    RETURN MultiLineString IS
BEGIN
  RETURN TREAT(ST_GEOMETRY.FROM_WKB(wkb, srid) AS MultiLineString);
END OGC_MultiLineStringFromWKB;
/

