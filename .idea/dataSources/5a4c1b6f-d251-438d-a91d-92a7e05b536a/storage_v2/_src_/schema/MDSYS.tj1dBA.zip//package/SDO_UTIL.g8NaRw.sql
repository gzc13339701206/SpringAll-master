create PACKAGE sdo_util AUTHID current_user AS

-- CONSTANT DECLARATION
  SDO_GTYPE_POLYGON       CONSTANT  NUMBER := 3;
  SDO_GTYPE_MULTIPOLYGON  CONSTANT  NUMBER := 7;
  SDO_GTYPE_COLLECTION    CONSTANT  NUMBER := 4;

  FUNCTION extract(geometry IN mdsys.sdo_geometry,
                   element  IN NUMBER,
                   ring     IN NUMBER DEFAULT 0)
    RETURN mdsys.sdo_geometry DETERMINISTIC;
    PRAGMA restrict_references(extract, wnds, rnps, wnps, trust);

  FUNCTION append(geometry1 IN MDSYS.sdo_geometry,
                  geometry2 IN MDSYS.sdo_geometry)
    RETURN mdsys.sdo_geometry DETERMINISTIC;
    PRAGMA restrict_references(append, wnds, wnps);


  FUNCTION ExtractVoids(geometry IN mdsys.sdo_geometry,
                        dim      IN mdsys.sdo_dim_array)
    RETURN mdsys.sdo_geometry DETERMINISTIC;
    PRAGMA restrict_references(ExtractVoids, rnds, wnds, rnps, wnps, trust);

 FUNCTION GetVertices(geometry IN mdsys.sdo_geometry)
 RETURN vertex_set_type;
-- PRAGMA restrict_references(GetVertices, wnds, rnps, wnps);

  FUNCTION GetNumElem(geometry IN mdsys.sdo_geometry)
    RETURN NUMBER DETERMINISTIC;
    PRAGMA restrict_references(GetNumElem, rnds, wnds, rnps, wnps, trust);

  FUNCTION GetNumRings(
    geom IN MDSYS.SDO_GEOMETRY)
      RETURN NUMBER DETERMINISTIC;
  PRAGMA restrict_references(GetNumRings, rnds, wnds, rnps, wnps, trust);

  FUNCTION GetNumVertices(geometry IN mdsys.sdo_geometry)
    RETURN NUMBER;
    PRAGMA restrict_references(GetNumVertices, rnds, wnds, rnps, wnps, trust);

  FUNCTION OuterLn(geometry IN mdsys.sdo_geometry,
                   dim      IN mdsys.sdo_dim_array)
    RETURN mdsys.sdo_geometry DETERMINISTIC;
    PRAGMA restrict_references(OuterLn,rnds,wnds,rnps,wnps,trust);

  FUNCTION RefineMGon(mgon IN mdsys.sdo_geometry,
                      gon  IN mdsys.sdo_geometry,
                      dim  IN mdsys.sdo_dim_array)
    RETURN mdsys.sdo_geometry DETERMINISTIC;
    PRAGMA restrict_references(RefineMGon,rnds,wnds,rnps,wnps,trust);

 -- truncate the original number up to no_of_digits
 -- no_of_digits positive:  truncate the number to no_of_digits AFTER the decimal point
 -- ex: truncate_number(1.123456789,5) returns 1.12345
 -- no_of_digits negative:  truncate the number up to no_of_digits BEFORE the decimal point
 -- ex: truncate_number(987654321.123456789,-5) returns 987600000.0

 FUNCTION truncate_number(value NUMBER, no_of_digits NUMBER)
    RETURN NUMBER;
 PRAGMA restrict_references(truncate_number, wnds, rnps, wnps);

 FUNCTION rectify_geometry(
    geometry     IN MDSYS.SDO_GEOMETRY,
    tolerance    IN NUMBER)
   RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;
   PRAGMA RESTRICT_REFERENCES(rectify_geometry, rnds, wnds, rnps, wnps, trust);

  /* simplify a geometry */
  FUNCTION simplify(
   geometry       IN mdsys.sdo_geometry,
   threshold      IN NUMBER,
   tolerance      IN NUMBER := 0.0000005)
    RETURN mdsys.sdo_geometry DETERMINISTIC;
    PRAGMA restrict_references(simplify, rnds, wnds, rnps, wnps, trust);

 FUNCTION polygontoline(geometry IN mdsys.sdo_geometry)
    return MDSYS.SDO_GEOMETRY deterministic;

 FUNCTION remove_duplicates(geometry IN sdo_geometry, dim in sdo_dim_array)
    return MDSYS.SDO_GEOMETRY deterministic;

 FUNCTION remove_duplicate_vertices(geometry IN sdo_geometry,
                                                tolerance in NUMBER)
    return MDSYS.SDO_GEOMETRY deterministic;

 FUNCTION circle_polygon (center_longitude     number,
                          center_latitude      number,
                          radius               number,
                          arc_tolerance            number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;

 FUNCTION ellipse_polygon (center_longitude                number,
                           center_latitude                 number,
                           semi_major_axis                 number,
                           semi_minor_axis                 number,
                           azimuth                         number,
                           arc_tolerance                       number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;

 FUNCTION point_at_bearing(start_point sdo_geometry,
                   bearing number,
                   distance number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;

 FUNCTION convert_unit(value NUMBER, in_unit varchar2, out_unit varchar2)
 RETURN number;


 PROCEDURE Prepare_For_TTS (table_space IN VARCHAR2);

 PROCEDURE Initialize_Indexes_For_TTS ;

 FUNCTION to_gmlgeometry(theGeom IN MDSYS.SDO_GEOMETRY)
 RETURN CLOB DETERMINISTIC;

 FUNCTION to_wkbgeometry(geometry IN MDSYS.SDO_GEOMETRY)
 RETURN BLOB DETERMINISTIC;
-- AS LANGUAGE JAVA NAME
-- 'oracle.spatial.util.Adapters.structToWkb(oracle.sql.STRUCT) return oracle.sql.BLOB';

 FUNCTION to_wktgeometry(geometry IN MDSYS.SDO_GEOMETRY)
 RETURN CLOB DETERMINISTIC;
-- AS LANGUAGE JAVA NAME
-- 'oracle.spatial.util.Adapters.structToWkt(oracle.sql.STRUCT) return oracle.sql.CLOB';

 FUNCTION from_wkbgeometry(geometry IN BLOB)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC
 AS LANGUAGE JAVA NAME
 'oracle.spatial.util.Adapters.wkbToSTRUCT(oracle.sql.BLOB) return oracle.sql.STRUCT';

 FUNCTION from_wktgeometry(geometry IN CLOB)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC
 AS LANGUAGE JAVA NAME
 'oracle.spatial.util.Adapters.wktToSTRUCT(oracle.sql.CLOB) return oracle.sql.STRUCT';

 FUNCTION from_wktgeometry(geometry IN VARCHAR2)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC
 AS LANGUAGE JAVA NAME
 'oracle.spatial.util.Adapters.wktToSTRUCT(java.lang.String) return oracle.sql.STRUCT';

 FUNCTION validate_wkbgeometry(geometry IN BLOB)
 RETURN VARCHAR2 DETERMINISTIC
 AS LANGUAGE JAVA NAME
 'oracle.spatial.util.Adapters.validateWkb(oracle.sql.BLOB) return java.lang.String';

 FUNCTION validate_wktgeometry(geometry IN CLOB)
 RETURN VARCHAR2 DETERMINISTIC
 AS LANGUAGE JAVA NAME
 'oracle.spatial.util.Adapters.validateWkt(oracle.sql.CLOB) return java.lang.String';

 FUNCTION validate_wktgeometry(geometry IN VARCHAR2)
 RETURN VARCHAR2 DETERMINISTIC
 AS LANGUAGE JAVA NAME
 'oracle.spatial.util.Adapters.validateWkt(java.lang.String) return java.lang.String';

 FUNCTION concat_lines (geometry1 IN MDSYS.SDO_GEOMETRY,
                        geometry2 IN MDSYS.SDO_GEOMETRY)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;

 PROCEDURE internal_ordinate_copy(src IN MDSYS.SDO_ORDINATE_ARRAY,
                            src_position IN INTEGER,
                            dst IN OUT NOCOPY MDSYS.SDO_ORDINATE_ARRAY,
                            dst_position IN INTEGER,
                            length IN INTEGER);

 FUNCTION reverse_linestring(geometry IN MDSYS.SDO_GEOMETRY)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;

 FUNCTION internal_merge_linestrings(geometry IN MDSYS.SDO_GEOMETRY)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;

 FUNCTION internal_make_line_out_of_elem(
     multilinestring IN MDSYS.SDO_GEOMETRY, element_index IN INTEGER)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;

 PROCEDURE internal_reverse_line_points(
       ordinates IN OUT NOCOPY MDSYS.SDO_ORDINATE_ARRAY);

END sdo_util;
/

