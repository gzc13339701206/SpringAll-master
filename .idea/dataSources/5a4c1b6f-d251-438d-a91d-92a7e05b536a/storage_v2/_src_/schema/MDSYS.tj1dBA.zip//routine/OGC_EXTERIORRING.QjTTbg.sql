create FUNCTION OGC_ExteriorRing(
  p Polygon)
    RETURN LineString IS
BEGIN
  RETURN p.ST_ExteriorRing();
END OGC_ExteriorRing;
/

