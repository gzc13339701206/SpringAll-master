create FUNCTION OGC_Relate(
  g1            Geometry,
  g2            Geometry,
  PatternMatrix VARCHAR2)
    RETURN Integer DETERMINISTIC IS
BEGIN
  RETURN g1.ST_Relate(g2, PatternMatrix);
END OGC_Relate;
/

