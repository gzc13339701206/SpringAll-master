create FUNCTION OGC_Buffer(
  g Geometry,
  d NUMBER)
    RETURN Geometry DETERMINISTIC IS
BEGIN
  RETURN g.ST_Buffer(d);
END OGC_Buffer;
/

