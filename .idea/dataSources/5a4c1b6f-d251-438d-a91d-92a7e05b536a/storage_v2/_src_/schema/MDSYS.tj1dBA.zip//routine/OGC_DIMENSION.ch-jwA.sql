create FUNCTION OGC_Dimension(
  g Geometry)
    RETURN Integer IS
BEGIN
  RETURN g.ST_CoordDim();
END OGC_Dimension;
/

