create PACKAGE sdo_rdf_internal  AS

	FUNCTION replace_rdf_prefix (
		string IN VARCHAR2
	) RETURN VARCHAR2 ;

	FUNCTION get_subject_node_type (
		subject IN VARCHAR2
	) RETURN VARCHAR2 ;

	FUNCTION get_property_link_type (
		property IN VARCHAR2
	) RETURN VARCHAR2 ;

	FUNCTION get_property_value_type (
		property IN VARCHAR2
	) RETURN VARCHAR2 ;

	FUNCTION get_object_node_type (
		object IN VARCHAR2
	) RETURN VARCHAR2 ;

	FUNCTION get_object_node_type (
		object IN CLOB
	) RETURN VARCHAR2 ;

	FUNCTION get_literal (
		object IN VARCHAR2
	) RETURN VARCHAR2 ;

	FUNCTION get_literal (
		object IN CLOB
	) RETURN CLOB ;

	FUNCTION get_literaltype (
		object IN VARCHAR2
	) RETURN VARCHAR2 ;

	FUNCTION get_literaltype (
		object IN CLOB
	) RETURN VARCHAR2 ;

	FUNCTION get_model_id (
		model_name IN VARCHAR2
	) RETURN NUMBER ;

	FUNCTION is_triple (
		model_id IN NUMBER,
		rdf_t_id IN NUMBER
	) RETURN VARCHAR2 ;

	FUNCTION is_triple (
		model_name IN VARCHAR2,
		rdf_t_id IN NUMBER
	) RETURN VARCHAR2 ;

	FUNCTION is_triple (
		model_id IN NUMBER,
		subject IN VARCHAR2,
		property IN VARCHAR2,
		object IN VARCHAR2
	) RETURN VARCHAR2 ;

	FUNCTION is_triple (
		model_name IN VARCHAR2,
		subject IN VARCHAR2,
		property IN VARCHAR2,
		object IN VARCHAR2
	) RETURN VARCHAR2 ;

	FUNCTION get_triple_id (
		model_id IN NUMBER,
		subject IN VARCHAR2,
		property IN VARCHAR2,
		object IN VARCHAR2
	) RETURN NUMBER ;

	FUNCTION get_triple_id (
		model_name IN VARCHAR2,
		subject IN VARCHAR2,
		property IN VARCHAR2,
		object IN VARCHAR2
	) RETURN NUMBER ;

	FUNCTION is_reified (
		model_id IN NUMBER,
		rdf_t_id IN NUMBER
	) RETURN VARCHAR2 ;

	FUNCTION is_reified (
		model_name IN VARCHAR2,
		rdf_t_id IN NUMBER
	) RETURN VARCHAR2 ;

	FUNCTION is_reified (
		model_id IN NUMBER,
		subject IN VARCHAR2,
		property IN VARCHAR2,
		object IN VARCHAR2
	) RETURN VARCHAR2 ;

	FUNCTION is_reified (
		model_name IN VARCHAR2,
		subject IN VARCHAR2,
		property IN VARCHAR2,
		object IN VARCHAR2
	) RETURN VARCHAR2 ;

	FUNCTION is_reified_quad (
		model_id IN NUMBER,
		subject IN VARCHAR2,
		property IN VARCHAR2,
		object IN VARCHAR2
	) RETURN VARCHAR2 ;

	FUNCTION is_reified_quad (
		model_name IN VARCHAR2,
		subject IN VARCHAR2,
		property IN VARCHAR2,
		object IN VARCHAR2
	) RETURN VARCHAR2 ;

	FUNCTION get_triple_cost (
		rdf_t_id IN NUMBER
	) RETURN NUMBER ;

	PROCEDURE delete_link$_id (rdf_t_id IN NUMBER);

	PROCEDURE set_triple_cost (rdf_t_id IN NUMBER);

	PROCEDURE parse_subject_node (
		v_subject IN VARCHAR2, sv_type IN VARCHAR2, sv_id OUT NUMBER, new_sv OUT BOOLEAN
	);

	PROCEDURE parse_property_value (
		v_property IN VARCHAR2, pv_type IN VARCHAR2, pv_id OUT NUMBER, pl_type OUT VARCHAR2, new_pv OUT BOOLEAN
	);

	PROCEDURE parse_object_node (
		v_object IN VARCHAR2, lit_type IN VARCHAR2, lit_lang IN VARCHAR2, ov_type IN VARCHAR2,
		ov_id OUT NUMBER, cov_id OUT NUMBER, new_ov OUT BOOLEAN
	);

	PROCEDURE parse_object_node (
		v_object IN CLOB, lit_type IN VARCHAR2, lit_lang IN VARCHAR2, ov_type IN VARCHAR2,
		ov_id OUT NUMBER, cov_id OUT NUMBER, new_ov OUT BOOLEAN
	);

	PROCEDURE parse_triple (
		m_id IN NUMBER, pv_id IN NUMBER, sv_id IN NUMBER, ov_id IN NUMBER, cov_id IN NUMBER,
		new_sv IN BOOLEAN, new_ov IN BOOLEAN, new_pv IN BOOLEAN, pl_type IN VARCHAR2,
		pl_id OUT NUMBER
	);

	PROCEDURE get_value$_type$ (
		subject IN OUT VARCHAR2, property IN OUT VARCHAR2, object IN OUT VARCHAR2,
		sv_type OUT VARCHAR2, pv_type OUT VARCHAR2, ov_type OUT VARCHAR2,
		lit_type OUT VARCHAR2, lit_lang OUT VARCHAR2
	);

	PROCEDURE get_value$_type$ (
		subject IN OUT VARCHAR2, property IN OUT VARCHAR2, object IN OUT CLOB,
		sv_type OUT VARCHAR2, pv_type OUT VARCHAR2, ov_type OUT VARCHAR2,
		lit_type OUT VARCHAR2, lit_lang OUT VARCHAR2
	);

	PROCEDURE insert_sub_rdf_node$ (
		sv_id IN NUMBER, sv_type IN VARCHAR2
	);

	PROCEDURE insert_obj_rdf_node$ (
		ov_id IN NUMBER
	);

	PROCEDURE add_namespaces (
		namespace_1 IN VARCHAR2,
		namespace_2 IN VARCHAR2 DEFAULT NULL,
		namespace_3 IN VARCHAR2 DEFAULT NULL
	);

       PROCEDURE create_rdf_model (model_name IN VARCHAR2, table_name IN VARCHAR2, column_name IN VARCHAR2);
       PROCEDURE drop_rdf_model (model_name IN VARCHAR2);
       PROCEDURE create_rdf_network (tablespace_name in varchar2);
       PROCEDURE drop_rdf_network ;

END sdo_rdf_internal;
/

