create FUNCTION OGC_GeometryType(
  g Geometry)
    RETURN VARCHAR2 IS
BEGIN
  RETURN g.ST_GeometryType();
END OGC_GeometryType;
/

