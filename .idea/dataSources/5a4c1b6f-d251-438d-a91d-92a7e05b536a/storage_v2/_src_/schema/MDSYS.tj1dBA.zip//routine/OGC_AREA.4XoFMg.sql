create FUNCTION OGC_Area(
  s Geometry)
    RETURN NUMBER DETERMINISTIC IS
BEGIN
  IF(UPPER(GeometryType(s)) IN ('POLYGON')) THEN
    RETURN TREAT(s AS Surface).ST_Area();
  END IF;
  IF(UPPER(GeometryType(s)) IN ('MULTIPOLYGON')) THEN
    RETURN TREAT(s AS MultiSurface).ST_Area();
  END IF;
  RETURN NULL;
END OGC_Area;
/

