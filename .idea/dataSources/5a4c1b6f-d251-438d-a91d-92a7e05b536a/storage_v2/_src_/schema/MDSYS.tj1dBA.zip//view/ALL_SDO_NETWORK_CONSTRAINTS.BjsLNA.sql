create view ALL_SDO_NETWORK_CONSTRAINTS as
SELECT  constraint, description, class_name
    FROM  sdo_network_constraints
/

