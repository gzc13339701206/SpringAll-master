create FUNCTION OGC_EndPoint(
  c Curve)
    RETURN Point IS
BEGIN
  RETURN c.ST_EndPoint();
END OGC_EndPoint;
/

