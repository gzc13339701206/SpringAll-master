create FUNCTION OGC_Distance(
  g1 Geometry,
  g2 Geometry)
    RETURN NUMBER DETERMINISTIC IS
BEGIN
  RETURN g1.ST_Distance(g2);
END OGC_Distance;
/

