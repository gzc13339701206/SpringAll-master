create FUNCTION OGC_Intersects(
  g1 Geometry,
  g2 Geometry)
    RETURN Integer DETERMINISTIC IS
BEGIN
  RETURN g1.ST_Intersects(g2);
END OGC_Intersects;
/

