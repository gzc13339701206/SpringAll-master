create FUNCTION OGC_NumPoints(
  c Curve)
    RETURN Integer IS
BEGIN
  RETURN c.ST_NumPoints();
END OGC_NumPoints;
/

