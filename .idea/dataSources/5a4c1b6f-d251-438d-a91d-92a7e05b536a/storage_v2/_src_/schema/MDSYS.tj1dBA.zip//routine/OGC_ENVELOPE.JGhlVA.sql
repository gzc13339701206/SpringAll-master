create FUNCTION OGC_Envelope(
  g Geometry)
    RETURN Geometry IS
BEGIN
  RETURN g.ST_Envelope();
END OGC_Envelope;
/

