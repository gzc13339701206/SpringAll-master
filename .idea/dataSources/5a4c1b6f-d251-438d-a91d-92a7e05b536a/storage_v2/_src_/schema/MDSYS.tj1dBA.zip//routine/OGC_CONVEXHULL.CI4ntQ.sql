create FUNCTION OGC_ConvexHull(
  g Geometry)
    RETURN Geometry IS
BEGIN
  RETURN g.ST_ConvexHull();
END OGC_ConvexHull;
/

