create FUNCTION OGC_Boundary(
  g Geometry)
    RETURN Geometry IS
BEGIN
  RETURN g.ST_Boundary();
END OGC_Boundary;
/

