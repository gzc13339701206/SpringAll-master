create PACKAGE sdo_net AUTHID current_user AS


  -- check if the network exists in the network metadata
  FUNCTION network_exists(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(network_exists,WNDS,WNPS,RNPS);

  -- return the network ID from network name
  FUNCTION get_network_id(network IN VARCHAR2)
    RETURN NUMBER;
  PRAGMA RESTRICT_REFERENCES(get_network_id,WNDS,WNPS,RNPS);

  -- return the network ID from network name
--  FUNCTION get_network_id(network IN VARCHAR2, owner IN VARCHAR2)
--    RETURN NUMBER;
--  PRAGMA RESTRICT_REFERENCES(get_network_id,WNDS,WNPS,RNPS);

  -- return  network name from network ID
  FUNCTION get_network_name(network_id IN NUMBER)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_network_name,WNDS,WNPS,RNPS);

  -- return  network name from network ID
  FUNCTION get_network_name(network_id IN NUMBER, owner OUT VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_network_name,WNDS,WNPS,RNPS);

  -- return  network owner from network ID
  FUNCTION get_network_owner(network_id IN NUMBER)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_network_owner,WNDS,WNPS,RNPS);


  -- return the type of network
  FUNCTION get_network_type(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_network_type,WNDS,WNPS,RNPS);


  -- return the type of network
  FUNCTION get_network_category(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_network_category,WNDS,WNPS,RNPS);


  -- return the type of geometry
  FUNCTION get_geometry_type(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_geometry_type,WNDS,WNPS,RNPS);


  -- return no of hierarchy levels
  FUNCTION get_no_of_hierarchy_levels(network IN VARCHAR2)
    RETURN NUMBER;
  PRAGMA RESTRICT_REFERENCES(get_no_of_hierarchy_levels,WNDS,WNPS,RNPS);

  -- return no of partition
  FUNCTION get_no_of_partitions(network IN VARCHAR2)
    RETURN NUMBER;
  PRAGMA RESTRICT_REFERENCES(get_no_of_partitions,WNDS,WNPS,RNPS);


  -- return geometry table(LRS) name of network
  FUNCTION get_lrs_table_name(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_lrs_table_name,WNDS,WNPS,RNPS);

  -- return LRS geom column of network
  FUNCTION get_lrs_geom_column(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_lrs_geom_column,WNDS,WNPS,RNPS);


  -- return node table name of network
  FUNCTION get_node_table_name(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_node_table_name,WNDS,WNPS,RNPS);

  -- return node geom column of network
  FUNCTION get_node_geom_column(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_node_geom_column,WNDS,WNPS,RNPS);

  -- return node cost column of network
  FUNCTION get_node_cost_column(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_node_cost_column,WNDS,WNPS,RNPS);

  -- return node partition column of network
  FUNCTION get_node_partition_column(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_node_partition_column,WNDS,WNPS,RNPS);


  -- return link table name of network
  FUNCTION get_link_table_name(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_link_table_name,WNDS,WNPS,RNPS);

  -- return link geom column of network
  FUNCTION get_link_geom_column(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_link_geom_column,WNDS,WNPS,RNPS);

  -- return link direction of network
  FUNCTION get_link_direction(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_link_direction,WNDS,WNPS,RNPS);

  -- return link partition column of network
  FUNCTION get_link_partition_column(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_link_partition_column,WNDS,WNPS,RNPS);

  -- return link cost column of network
  FUNCTION get_link_cost_column(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_link_cost_column,WNDS,WNPS,RNPS);

  -- return path table name of network
  FUNCTION get_path_table_name(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_path_table_name,WNDS,WNPS,RNPS);

  -- return path geom column name of network
  FUNCTION get_path_geom_column(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_path_geom_column,WNDS,WNPS,RNPS);

  -- return path-link table name of network
  FUNCTION get_path_link_table_name(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_path_link_table_name,WNDS,WNPS,RNPS);


  -- return partition table name of network
  FUNCTION get_partition_table_name(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_partition_table_name,WNDS,WNPS,RNPS);


  -- return no of nodes of the network
  FUNCTION get_no_of_nodes(network IN VARCHAR2)
    RETURN NUMBER;
--  PRAGMA RESTRICT_REFERENCES(get_no_of_nodes,WNDS,WNPS,RNPS);

  -- return no of nodes of the network of specified hierarchy_level
  FUNCTION get_no_of_nodes(network IN VARCHAR2, hierarchy_level IN NUMBER)
    RETURN NUMBER;
--  PRAGMA RESTRICT_REFERENCES(get_no_of_nodes,WNDS,WNPS,RNPS);

  -- return no of links of the network
  FUNCTION get_no_of_links(network IN VARCHAR2)
    RETURN NUMBER;
--  PRAGMA RESTRICT_REFERENCES(get_no_of_links,WNDS,WNPS,RNPS);

  -- return no of links of the network of specified hierarchy_level
  FUNCTION get_no_of_links(network IN VARCHAR2, hierarchy_level IN NUMBER)
    RETURN NUMBER;
--  PRAGMA RESTRICT_REFERENCES(get_no_of_links,WNDS,WNPS,RNPS);

  -- return no of links of the given path
  FUNCTION get_no_of_links_in_path(network IN VARCHAR2, path_id IN NUMBER)
    RETURN NUMBER;
--  PRAGMA RESTRICT_REFERENCES(get_no_of_links_in_path,WNDS,WNPS,RNPS);

  -- return no of nodes of the given path
  FUNCTION get_no_of_nodes_in_path(network IN VARCHAR2, path_id IN NUMBER)
    RETURN NUMBER;
--  PRAGMA RESTRICT_REFERENCES(get_no_of_nodes_in_path,WNDS,WNPS,RNPS);


  -- return the in-link ids of a node
  FUNCTION get_in_links(network IN VARCHAR2, node_id in number)
    RETURN SDO_NUMBER_ARRAY DETERMINISTIC ;
--  PRAGMA RESTRICT_REFERENCES(get_in_links,WNDS,WNPS,RNPS);

  -- return the out-link ids of a node
  FUNCTION get_out_links(network IN VARCHAR2, node_id in number)
    RETURN SDO_NUMBER_ARRAY DETERMINISTIC;
--  PRAGMA RESTRICT_REFERENCES(get_out_links,WNDS,WNPS,RNPS);


  -- return the in-degree of a node
  FUNCTION get_node_in_degree(network IN VARCHAR2, node_id in number)
    RETURN NUMBER;
--  PRAGMA RESTRICT_REFERENCES(get_node_in_degree,WNDS,WNPS,RNPS);

  -- return the out-degree of a node
  FUNCTION get_node_out_degree(network IN VARCHAR2, node_id in number)
    RETURN NUMBER;
--  PRAGMA RESTRICT_REFERENCES(get_node_out_degree,WNDS,WNPS,RNPS);

  -- return the degree of a node(in_degree+out_degree)
  FUNCTION get_node_degree(network IN VARCHAR2, node_id in number)
    RETURN NUMBER;
--  PRAGMA RESTRICT_REFERENCES(get_node_degree,WNDS,WNPS,RNPS);


  -- return the child nodes of a given node
  FUNCTION get_child_nodes(network IN VARCHAR2, node_id in number)
    RETURN SDO_NUMBER_ARRAY DETERMINISTIC;
--  PRAGMA RESTRICT_REFERENCES(get_child_nodes,WNDS,WNPS,RNPS);

  -- return the child links of a given link
  FUNCTION get_child_links(network IN VARCHAR2, link_id in number)
    RETURN SDO_NUMBER_ARRAY DETERMINISTIC;
--  PRAGMA RESTRICT_REFERENCES(get_child_links,WNDS,WNPS,RNPS);

  -- return the path links of a given path
  FUNCTION get_links_in_path(network IN VARCHAR2, path_id in number)
    RETURN SDO_NUMBER_ARRAY DETERMINISTIC;
--  PRAGMA RESTRICT_REFERENCES(get_links_in_path,WNDS,WNPS,RNPS);

  -- return the path links of a given path
  FUNCTION get_nodes_in_path(network IN VARCHAR2, path_id in number)
    RETURN SDO_NUMBER_ARRAY DETERMINISTIC;
--  PRAGMA RESTRICT_REFERENCES(get_nodes_in_path,WNDS,WNPS,RNPS);


  --
  -- create xxx_network assumes the following naming convention
  -- table name length limitation: 32 char.
  -- network name length limitation : 24 char
  --

  -- default table/columns names:
  -- node table			: <network>_node$
  -- link table			: <network>_link$
  -- path table			: <network>_path$
  -- path link  table 		: <network>_plink$ (path_id, link_id)
  -- node geom. column  	: geometry
  -- node lrs geom column	: geom_id and measure
  -- node topo geom column	: topo_geometry
  -- link geom. column  	: geometry
  -- link lrs geom column	: geom_id, start_measure, and end_measure
  -- link topo geom column	: topo_geometry
  -- path geom. column  	: geometry
  -- node cost  column  	: cost
  -- link cost  column  	: cost
  -- path cost  column  	: cost
  -- storage parameters         : for create table statement

  -- create a logical network
  PROCEDURE create_logical_network(network 			IN VARCHAR2,
				   no_of_hierarchy_levels 	IN NUMBER,
				   is_directed       		IN BOOLEAN,
				   node_table_name   		IN VARCHAr2,
   	                           node_cost_column  		IN VARCHAR2,
				   link_table_name   		IN VARCHAR2,
				   link_cost_column  		IN VARCHAR2,
				   path_table_name     		IN VARCHAR2,
				   path_link_table_name		IN VARCHAR2,
				   is_complex		        IN BOOLEAN DEFAULT FALSE,
			   	   storage_parameters           IN VARCHAR2 DEFAULT NULL);
--  PRAGMA RESTRICT_REFERENCES(create_logical_network,WNPS,RNPS);

  -- create a logical network (simplified version)
  PROCEDURE create_logical_network(network 			IN VARCHAR2,
				   no_of_hierarchy_levels 	IN NUMBER,
				   is_directed 			IN BOOLEAN,
				   node_with_cost		IN BOOLEAN DEFAULT FALSE,
				   is_complex		        IN BOOLEAN DEFAULT FALSE,
			           storage_parameters           IN VARCHAR2 DEFAULT NULL);
--  PRAGMA RESTRICT_REFERENCES(create_logical_network,WNPS,RNPS);


  -- create a spatial (SDO_GEOMETRY) network
  PROCEDURE create_sdo_network(network 			IN VARCHAR2,
			       no_of_hierarchy_levels 	IN NUMBER,
			       is_directed 		IN BOOLEAN,
			       node_table_name		IN VARCHAR2,
			       node_geom_column		IN VARCHAR2,
			       node_cost_column		IN VARCHAR2,
			       link_table_name		IN VARCHAR2,
			       link_geom_column		IN VARCHAR2,
			       link_cost_column		IN VARCHAR2,
			       path_table_name		IN VARCHAR2,
			       path_geom_column		IN VARCHAR2,
			       path_link_table_name	IN VARCHAR2,
			       is_complex		IN BOOLEAN DEFAULT FALSE,
			       storage_parameters       IN VARCHAR2 DEFAULT NULL);

--  PRAGMA RESTRICT_REFERENCES(create_sdo_network,WNPS,RNPS);


  -- create a spatial (SDO_GEOMETRY) network
  PROCEDURE create_sdo_network(network IN VARCHAR2,
			       no_of_hierarchy_levels 	IN NUMBER,
			       is_directed 		IN BOOLEAN,
			       node_with_cost	 	IN BOOLEAN DEFAULT FALSE,
			       is_complex		IN BOOLEAN DEFAULT FALSE,
			       storage_parameters   	IN VARCHAR2 DEFAULT NULL);
--  PRAGMA RESTRICT_REFERENCES(create_sdo_network,WNPS,RNPS);

  -- create a spatial (LRS_GEOMETRY) network
  PROCEDURE create_lrs_network(network 			IN VARCHAR2,
			       no_of_hierarchy_levels 	IN NUMBER,
			       is_directed 		IN BOOLEAN,
			       node_table_name		IN VARCHAR2,
			       node_cost_column		IN VARCHAR2,
			       link_table_name		IN VARCHAR2,
			       link_cost_column		IN VARCHAR2,
			       lrs_table_name  		IN VARCHAR2,
			       lrs_geom_column 		IN VARCHAR2,
			       path_table_name		IN VARCHAR2,
			       path_geom_column		IN VARCHAR2,
			       path_link_table_name	IN VARCHAR2,
			       is_complex		IN BOOLEAN DEFAULT FALSE,
			       storage_parameters   	IN VARCHAR2 DEFAULT NULL);
--  PRAGMA RESTRICT_REFERENCES(create_lrs_network,WNPS,RNPS);


  -- create a spatial (LRS_GEOMETRY) network
  PROCEDURE create_lrs_network(network 			IN VARCHAR2,
			       lrs_table_name  		IN VARCHAR2,
			       lrs_geom_column 		IN VARCHAR2,
			       no_of_hierarchy_levels 	IN NUMBER,
			       is_directed 		IN BOOLEAN,
                               node_with_cost 		IN BOOLEAN DEFAULT FALSE,
			       is_complex		IN BOOLEAN DEFAULT FALSE,
			       storage_parameters   	IN VARCHAR2 DEFAULT NULL);
--  PRAGMA RESTRICT_REFERENCES(create_lrs_network,WNPS,RNPS);

  -- create a spatial (TOPO_GEOMETRY) network
  PROCEDURE create_topo_network(network IN VARCHAR2,
			        no_of_hierarchy_levels IN NUMBER,
			        is_directed 		IN BOOLEAN,
				node_table_name		IN VARCHAR2,
				node_geom_column	IN VARCHAR2,
			        node_cost_column	IN VARCHAR2,
			        link_table_name		IN VARCHAR2,
				link_geom_column	IN VARCHAR2,
			        link_cost_column	IN VARCHAR2,
			        path_table_name		IN VARCHAR2,
			        path_geom_column	IN VARCHAR2,
			        path_link_table_name	IN VARCHAR2,
			        is_complex		IN BOOLEAN DEFAULT FALSE,
			        storage_parameters   	IN VARCHAR2 DEFAULT NULL);
--  PRAGMA RESTRICT_REFERENCES(create_topo_network,WNPS,RNPS);


  -- create a spatial (TOPO_GEOMETRY) network
  PROCEDURE create_topo_network(network IN VARCHAR2,
			        no_of_hierarchy_levels 	IN NUMBER,
			        is_directed 		IN BOOLEAN,
				node_table_name		IN VARCHAR2,
			        node_cost_column	IN VARCHAR2,
			        link_table_name		IN VARCHAR2,
			        link_cost_column	IN VARCHAR2,
			        path_table_name		IN VARCHAR2,
			        path_geom_column	IN VARCHAR2,
			        path_link_table_name	IN VARCHAR2,
			        is_complex		IN BOOLEAN DEFAULT FALSE,
			        storage_parameters   	IN VARCHAR2 DEFAULT NULL);
--  PRAGMA RESTRICT_REFERENCES(create_topo_network,WNPS,RNPS);



  -- create a spatial (TOPO_GEOMETRY) network
  PROCEDURE create_topo_network(network 		IN VARCHAR2,
			        no_of_hierarchy_levels 	IN NUMBER,
			        is_directed 		IN BOOLEAN,
				node_with_cost 		IN BOOLEAN DEFAULT FALSE,
			        is_complex		IN BOOLEAN DEFAULT FALSE,
			        storage_parameters   	IN VARCHAR2 DEFAULT NULL);

--  PRAGMA RESTRICT_REFERENCES(create_topo_network,WNPS,RNPS);


  -- create a spatial (TOPO_GEOMETRY) network from existing topology data
  -- The nodes and links in the resultant network have one-to-one mapping
  -- to the nodes and edges in the given topology
  PROCEDURE create_topo_network(network                  in varchar2,
                                no_of_hierarchy_levels   in number,
                                is_directed              in boolean,
                                node_with_cost           in boolean,
                                is_complex               in boolean,
                                topology                 in varchar2,
			        storage_parameters   	 in varchar2 );

  -- create a general network creation
  PROCEDURE create_network(network 			IN VARCHAR2,
		           geom_type   			IN VARCHAR2,
			   no_of_hierarchy_levels 	IN NUMBER,
			   is_directed 			IN BOOLEAN,
			   node_table_name 		IN VARCHAR2,
			   node_geom_column 		IN VARCHAR2,
			   node_cost_column		IN VARCHAR2,
			   link_table_name 		IN VARCHAR2,
			   link_geom_column 		IN VARCHAR2,
			   link_cost_column		IN VARCHAR2,
			   lrs_table_name   		IN VARCHAR2,
			   lrs_geom_column  		IN VARCHAR2,
			   path_table_name		IN VARCHAR2,
			   path_geom_column		IN VARCHAR2,
			   path_link_table_name		IN VARCHAR2,
			   is_complex			IN BOOLEAN DEFAULT FALSE,
			   storage_parameters   	IN VARCHAR2 DEFAULT NULL);

--  PRAGMA RESTRICT_REFERENCES(create_network,WNPS,RNPS);


  -- create a general network creation
  PROCEDURE create_network(network 			IN VARCHAR2,
		           geom_type   			IN VARCHAR2,
			   no_of_hierarchy_levels 	IN NUMBER,
			   is_directed 			IN BOOLEAN,
			   node_with_cost 		IN BOOLEAN,
			   lrs_table_name   		IN VARCHAR2,
			   lrs_geom_column  		IN VARCHAR2,
			   is_complex			IN BOOLEAN DEFAULT FALSE,
			   storage_parameters   	IN VARCHAR2 DEFAULT NULL);
--  PRAGMA RESTRICT_REFERENCES(create_network,WNPS,RNPS);


  -- validate a network
  FUNCTION validate_network(network IN VARCHAR2)
    RETURN VARCHAR2;
  -- PRAGMA RESTRICT_REFERENCES(validate_network,WNDS,WNPS,RNPS);


  -- create an empty  node table with necessary columns
  PROCEDURE create_node_table(table_name  		in varchar2,
			      geom_type   		in varchar2,
			      geom_column 		in varchar2,
			      cost_column 		in varchar2,
			      partition_column 		in varchar2,
			      no_of_hierarchy_levels 	in number,
			      is_complex 		in boolean default false,
			      storage_parameters   	in varchar2 default null);

--  PRAGMA RESTRICT_REFERENCES(create_node_table,WNPS,RNPS);

  -- create an empty  node table with necessary columns
  PROCEDURE create_node_table(table_name  		in varchar2,
			      geom_type   		in varchar2,
			      geom_column 		in varchar2,
			      cost_column 		in varchar2,
			      no_of_hierarchy_levels 	in number,
			      is_complex 		in boolean default false,
			      storage_parameters   	in varchar2 default null);

--  PRAGMA RESTRICT_REFERENCES(create_node_table,WNPS,RNPS);


  -- create an empty link table with necessary columns
  PROCEDURE create_link_table(table_name  		in varchar2,
			      geom_type   		in varchar2,
			      geom_column 		in varchar2,
			      cost_column 		in varchar2,
			      no_of_hierarchy_levels 	in number,
			      add_bidirected_column 	in boolean default false,
			      storage_parameters   	in varchar2 default null);
--  PRAGMA RESTRICT_REFERENCES(create_link_table,WNPS,RNPS);

  -- create an empty compact path table with necessary columns
  PROCEDURE create_path_table(table_name in varchar2,  geom_column in varchar2,
			      storage_parameters   IN VARCHAR2 DEFAULT NULL);
--  PRAGMA RESTRICT_REFERENCES(create_path_table,WNPS,RNPS);

  -- create an empty compact path table with necessary columns
  PROCEDURE create_path_link_table(table_name in varchar2,
			      	   storage_parameters   IN VARCHAR2 DEFAULT NULL);
--  PRAGMA RESTRICT_REFERENCES(create_path_link_table,WNPS,RNPS);

  -- create an empty lrs geom table with necessary columns
  PROCEDURE create_lrs_table(table_name in varchar2,  geom_column in varchar2,
			      storage_parameters   IN VARCHAR2 DEFAULT NULL);
--  PRAGMA RESTRICT_REFERENCES(create_lrs_table,WNPS,RNPS);

  -- create an empty partition table with necessary columns
  PROCEDURE create_partition_table(table_name in varchar2);
--  PRAGMA RESTRICT_REFERENCES(create_partition_table,WNPS,RNPS);


  -- validate a node schema
  FUNCTION validate_node_schema(network IN VARCHAR2)
    RETURN VARCHAR2;
  --PRAGMA RESTRICT_REFERENCES(validate_node_schema,WNDS,WNPS,RNPS);

  -- validate a link schema
  FUNCTION validate_link_schema(network IN VARCHAR2)
    RETURN VARCHAR2;
  --PRAGMA RESTRICT_REFERENCES(validate_link_schema,WNDS,WNPS,RNPS);

  -- validate a path schema
  FUNCTION validate_path_schema(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(validate_path_schema,WNDS,WNPS,RNPS);


  -- validate an lrs geom schema
  FUNCTION validate_lrs_schema(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(validate_lrs_schema,WNDS,WNPS,RNPS);

  -- validate a partition table schema
  FUNCTION validate_partition_schema(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(validate_partition_schema,WNDS,WNPS,RNPS);

  --
  -- drop a network
  -- it drops :
  -- node table, link table, and path table
  -- network metadata
  --

  PROCEDURE drop_network(network	in varchar2);
--  PRAGMA RESTRICT_REFERENCES(drop_network,WNPS,RNPS);

  --
  -- create a point geometry from an LRS geometry and a measure
  --
  FUNCTION get_lrs_node_geometry(network	in VARCHAR2,
			         node_id	in number)
	RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;
  PRAGMA RESTRICT_REFERENCES(get_lrs_node_geometry,WNPS,RNPS);

  --
  -- create a point geometry from a topology
  --
  FUNCTION get_topo_node_geometry(network	in VARCHAR2,
			          node_id	in number)
	RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;
--  PRAGMA RESTRICT_REFERENCES(get_topo_node_geometry,WNPS,RNPS);


  --
  -- get the node geometry
  --
  FUNCTION get_node_geometry(network	in VARCHAR2,
			     node_id	in number)
	RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;
--  PRAGMA RESTRICT_REFERENCES(get_node_geometry,WNPS,RNPS);


  --
  -- create linestring geometry from an LRS geometry and start/end measure
  --
  FUNCTION get_lrs_link_geometry(network	in VARCHAR2,
			         link_id	in number)

	RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;
--  PRAGMA RESTRICT_REFERENCES(get_lrs_link_geometry,WNPS,RNPS);

  --
  -- create linestring geometry from a topo geometry
  --
  FUNCTION get_topo_link_geometry(network	in VARCHAR2,
			          link_id	in number)

	RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;
--  PRAGMA RESTRICT_REFERENCES(get_topo_link_geometry,WNPS,RNPS);


  --
  -- get the link geometry
  --
  FUNCTION get_link_geometry(network	in VARCHAR2,
			     link_id	in number)

	RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;
--  PRAGMA RESTRICT_REFERENCES(get_link_geometry,WNPS,RNPS);



  --
  -- network type queries
  --


  FUNCTION is_spatial(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(is_spatial,WNDS,WNPS,RNPS);

  FUNCTION is_logical(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(is_logical,WNDS,WNPS,RNPS);

  FUNCTION is_hierarchical(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(is_hierarchical,WNDS,WNPS,RNPS);

  -- a simple network does not refer nodes/links in another networks
  -- a complex network has the network_type anything other than  'COMPLEX'
  -- before 10GR1, all networks are simple networks

  FUNCTION is_simple(network IN VARCHAR2)
    RETURN VARCHAR2;
--  PRAGMA RESTRICT_REFERENCES(is_simple,WNDS,WNPS,RNPS);

  -- a complex network can refer nodes/links in another networks
  -- a complex network has the network_type = 'COMPLEX'
  -- after 10GR2, a network can refer nodes/links in other networks (network_id, and element_id)

  FUNCTION is_complex(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(is_complex,WNDS,WNPS,RNPS);


  FUNCTION is_simple(network IN VARCHAR2,path_id in number)
    RETURN VARCHAR2;
--  PRAGMA RESTRICT_REFERENCES(is_simple,WNDS,WNPS,RNPS);

  FUNCTION is_link_in_path(network IN VARCHAR2,path_id in number, link_id in number)
    RETURN VARCHAR2;
--  PRAGMA RESTRICT_REFERENCES(is_link_in_path,WNDS,WNPS,RNPS);

  FUNCTION is_node_in_path(network IN VARCHAR2,path_id in number,node_id in number)
    RETURN VARCHAR2;
--  PRAGMA RESTRICT_REFERENCES(is_node_in_path,WNDS,WNPS,RNPS);


  FUNCTION sdo_geometry_network(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(sdo_geometry_network,WNDS,WNPS,RNPS);

  FUNCTION lrs_geometry_network(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(lrs_geometry_network,WNDS,WNPS,RNPS);

  FUNCTION topo_geometry_network(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(topo_geometry_network,WNDS,WNPS,RNPS);


  --
  -- copy network structure
  --

 PROCEDURE copy_network(source_network 	in varchar2,
		        target_network  in varchar2,
			storage_parameters in varchar2 default NULL);


  --
  -- create delete trigger on node/link table
  --

 PROCEDURE create_delete_trigger(network in varchar2);


  -- return the hierarchy_level of a node
  FUNCTION get_node_hierarchy_level(network IN VARCHAR2, node_id in number)
    RETURN NUMBER;
--  PRAGMA RESTRICT_REFERENCES(get_node_hierarchy_level,WNDS,WNPS,RNPS);


  --
  -- add referential constraints
  --

  PROCEDURE create_ref_constraints(network IN VARCHAR2);
--  PRAGMA RESTRICT_REFERENCES(create_ref_constraints,WNPS,RNPS);

  --
  -- drop referential constraints
  --

  PROCEDURE drop_ref_constraints(network IN VARCHAR2);
--  PRAGMA RESTRICT_REFERENCES(drop_ref_constraints,WNPS,RNPS);

  --
  -- enable referential constraints
  --

  PROCEDURE enable_ref_constraints(network IN VARCHAR2);
--  PRAGMA RESTRICT_REFERENCES(enable_ref_constraints,WNPS,RNPS);


  --
  -- disable referential constraints
  --

  PROCEDURE disable_ref_constraints(network IN VARCHAR2);
--  PRAGMA RESTRICT_REFERENCES(disable_ref_constraints,WNPS,RNPS);

  --
  -- add an geometry metadata entry
  --

  PROCEDURE insert_geom_metadata(geom_table_name       IN VARCHAR2,
                                 geom_column_name      IN VARCHAR2,
                                 diminfo               IN MDSYS.SDO_DIM_ARRAY,
                                 srid                  IN NUMBER);
  PRAGMA RESTRICT_REFERENCES(insert_geom_metadata,WNPS,RNPS);


  --
  -- add geometry metadata entries for a spatial network
  --

  PROCEDURE insert_geom_metadata(network 	       IN VARCHAR2,
                                 diminfo               IN MDSYS.SDO_DIM_ARRAY,
                                 srid                  IN NUMBER);
  PRAGMA RESTRICT_REFERENCES(insert_geom_metadata,WNPS,RNPS);



  --
  -- return the ids of isolated nodes
  --

  FUNCTION get_isolated_nodes(network IN VARCHAR2)
    RETURN SDO_NUMBER_ARRAY DETERMINISTIC ;
--  PRAGMA RESTRICT_REFERENCES(get_isolated_nodes,WNDS,WNPS,RNPS);

  --
  -- return the ids of invalid nodes
  --

  FUNCTION get_invalid_nodes(network IN VARCHAR2)
    RETURN SDO_NUMBER_ARRAY DETERMINISTIC ;
--  PRAGMA RESTRICT_REFERENCES(get_invalid_nodes,WNDS,WNPS,RNPS);


  --
  -- return the ids of invalid links
  --

  FUNCTION get_invalid_links(network IN VARCHAR2)
    RETURN SDO_NUMBER_ARRAY DETERMINISTIC ;
--  PRAGMA RESTRICT_REFERENCES(get_invalid_links,WNDS,WNPS,RNPS);

  --
  -- return the ids of invalid paths
  --

  FUNCTION get_invalid_paths(network IN VARCHAR2)
    RETURN SDO_NUMBER_ARRAY DETERMINISTIC ;
--  PRAGMA RESTRICT_REFERENCES(get_invalid_paths,WNDS,WNPS,RNPS);


  --
  -- add path-link information to the path-link table
  -- the seq no is indicated by the order in the given link array
  --
  PROCEDURE insert_path_link_info(network 	        IN VARCHAR2,
				  path_id		IN NUMBER,
     	                          links			IN SDO_NUMBER_ARRAY,
        	                  is_simple		IN BOOLEAN DEFAULT TRUE) ;
--  PRAGMA RESTRICT_REFERENCES(insert_path_link_info,WNPS,RNPS);


  --
  -- delete a node from a network
  --
  --
  PROCEDURE delete_node(network 	IN VARCHAR2,
			node_id		IN NUMBER) ;
--  PRAGMA RESTRICT_REFERENCES(delete_node,WNPS,RNPS);

  --
  -- delete a link from a network
  --
  --
  PROCEDURE delete_link(network 	IN VARCHAR2,
			link_id		IN NUMBER) ;
--  PRAGMA RESTRICT_REFERENCES(delete_link,WNPS,RNPS);


  --
  -- delete a path from a network
  --
  --
  PROCEDURE delete_path(network 	IN VARCHAR2,
			path_id		IN NUMBER) ;
--  PRAGMA RESTRICT_REFERENCES(delete_path,WNPS,RNPS);

  --
  -- change a spatial network into a logical network (Metadata Level)
  --
  --

  PROCEDURE switch_to_logical_network(network 	IN VARCHAR2);
  PRAGMA RESTRICT_REFERENCES(switch_to_logical_network,WNPS,RNPS);

  --
  -- change a logical network into a spatial network (Metadata Level)
  --
  --

  PROCEDURE switch_to_spatial_network(network 	    IN VARCHAR2,
				      node_geom_col IN VARCHAR2,
				      link_geom_col IN VARCHAR2,
				      path_geom_col IN VARCHAR2);
--  PRAGMA RESTRICT_REFERENCES(switch_to_spatial_network,WNPS,RNPS);



  -- return the topology of a topology network
  FUNCTION get_topology(network IN VARCHAR2)
    RETURN VARCHAR2;
  PRAGMA RESTRICT_REFERENCES(get_topology,WNDS,WNPS,RNPS);


END sdo_net;
/

