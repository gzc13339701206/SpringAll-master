create FUNCTION OGC_StartPoint(
  c Curve)
    RETURN Point IS
BEGIN
  RETURN c.ST_StartPoint();
END OGC_StartPoint;
/

