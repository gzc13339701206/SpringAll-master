create FUNCTION OGC_Centroid(
  g Geometry)
    RETURN Geometry IS
BEGIN
  RETURN g.ST_Centroid();
END OGC_Centroid;
/

