create FUNCTION OGC_PointN(
  c Curve,
  n Integer)
    RETURN Point IS
BEGIN
  RETURN c.ST_PointN(n);
END OGC_PointN;
/

