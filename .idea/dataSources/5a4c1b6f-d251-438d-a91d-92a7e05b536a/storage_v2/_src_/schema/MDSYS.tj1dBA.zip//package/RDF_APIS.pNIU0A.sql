create PACKAGE rdf_apis authid current_user AS

   -- Create a Rulebase
   PROCEDURE CREATE_RULEBASE (
        rulebase_name   VARCHAR2);

   -- Delete a Rulebase
   PROCEDURE DROP_RULEBASE (
        rulebase_name   VARCHAR2);

   -- Infer + store triples for specified models + rules
   PROCEDURE CREATE_RULES_INDEX (
        index_name_in   varchar2,
        models_in       MDSYS.RDF_Models,
        rulebases_in    MDSYS.RDF_Rulebases);

   -- Remove inferred triples for specified rulesindex
   PROCEDURE DROP_RULES_INDEX (
        index_name      varchar2);

   FUNCTION LOOKUP_RULES_INDEX (
        models          MDSYS.RDF_Models,
        rulebases       MDSYS.RDF_Rulebases)
   RETURN varchar2;

   -- CLEANUP_FAILED: cleanup a failed operation
   --   typ: 'RULEBASE' or 'RULES_INDEX'
   --   name: rulebase or ruleindex name.
   PROCEDURE CLEANUP_FAILED(
         rdf_object_type    varchar2,
         rdf_object_name    varchar2);

   PROCEDURE DROP_USER_INFERENCE_OBJS(uname varchar2);

   ---------------------------------------------------------------------------
   -- Interfaces below this line are intended for internal use only;
   -- they should not be documented or directly invoked by the user.
   ---------------------------------------------------------------------------

   FUNCTION  raiseURIError(rulename varchar2, pos int) RETURN int;

END rdf_apis;
/

