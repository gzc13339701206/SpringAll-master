create type vertex_type as object
(X  number,
 Y  number,
 Z  number,
 W  number,
 ID number );
/

