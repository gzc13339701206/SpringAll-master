create FUNCTION OGC_Union(
  g1 Geometry,
  g2 Geometry)
    RETURN Geometry IS
BEGIN
  RETURN g1.ST_Union(g2);
END OGC_Union;
/

