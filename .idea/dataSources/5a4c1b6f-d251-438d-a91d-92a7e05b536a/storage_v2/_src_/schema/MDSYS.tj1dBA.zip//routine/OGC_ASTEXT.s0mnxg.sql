create FUNCTION OGC_AsText(
  g Geometry)
    RETURN VARCHAR2 IS
BEGIN
  RETURN g.GET_WKT();
END OGC_AsText;
/

