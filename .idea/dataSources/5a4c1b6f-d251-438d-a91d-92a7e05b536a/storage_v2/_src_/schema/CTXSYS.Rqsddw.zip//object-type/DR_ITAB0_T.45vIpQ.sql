create type dr$itab0_t as object(
  token_text       varchar2(64),
  token_type       number(3),
  token_first      number,
  token_last       number,
  token_count      number,
  token_info_raw   raw(4000),
  token_info_blob  blob
);
/

