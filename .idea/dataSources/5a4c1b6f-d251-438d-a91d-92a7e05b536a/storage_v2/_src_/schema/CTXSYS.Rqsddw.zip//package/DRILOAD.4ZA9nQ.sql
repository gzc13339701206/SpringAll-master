create package driload as

/*---------------------------- build_dml --------------------------------*/
/*
  NAME
    build_dml

  DESCRIPTION
    Build a dml statement giving an index name and a list of text key
    values. Used by CTXLOAD for long binary update and export.

  ARGUMENTS
    idx_name   -- index name
    op         -- operation user wants to perform, UPDATE or SELECT
                  (supports INSERT also but it's not being used for now)
    tvalues    -- text key values, multiple ones are separated by commas
                  i.e.  value1,value2,...value<n>
                  comma preceded by a backslash will be treated as part
                  of the value
    coltype    -- datatype of column
    selstmt    -- select statement
                  if op is SELECT return a SELECT for all LONG and LONG RAW
                  if op is UPDATE return SELECT FOR UPDATE for LOBs and
                  null for LONG and LONG RAW

  RETURNS
    Return column type (so that we can support LONG also in the future)
*/
PROCEDURE BUILD_DML(
   IDX_NAME    IN     VARCHAR2,
   OP          IN     VARCHAR2,
   TVALUES     IN     VARCHAR2,
   COLTYPE     IN OUT NUMBER,
   SELSTMT     IN OUT VARCHAR2
);

/*---------------------------- resolve_sqe --------------------------------*/
/*
  NAME
    resolve_sqe

  NOTES
    TODO: move this to a more appropriate place
*/
FUNCTION resolve_sqe( p_idx_id in number, p_sqe_name in varchar2)
return varchar2;

end driload;
/

