create type dr$opttf_impl_t authid current_user as object(
  key     RAW(16),

  static function ODCITableStart(
      sctx        OUT    dr$opttf_impl_t,
      optim_state IN     dr$optim_state_t,
      mycur              SYS_REFCURSOR,
      tempItab           VARCHAR2,
      ntab               VARCHAR2)
     return PLS_INTEGER,

  static function ODCITableStart2(
      sctx OUT    dr$opttf_impl_t,
      mycur       SYS_REFCURSOR,
      tempItab    VARCHAR2,
      ntab        VARCHAR2)
     return PLS_INTEGER
    is
    language C
    library dr$lib
    name "optStart"
    with context
    parameters (
      context,
      sctx,
      sctx INDICATOR STRUCT,
      mycur,
      tempItab,
      ntab,
      return INT
    ),

  member function ODCITableFetch(self IN OUT dr$opttf_impl_t, nrows IN Number,
                                 outarr OUT dr$itab0_set_t) return PLS_INTEGER
    as language C
    library dr$lib
    name "optFetch"
    with context
    parameters (
      context,
      self,
      self INDICATOR STRUCT,
      nrows,
      outarr OCIColl,
      outarr INDICATOR sb2,
      return INT
    ),

  member function ODCITableClose(self IN dr$opttf_impl_t) return PLS_INTEGER
    as language C
    library dr$lib
    name "optClose"
    with context
    parameters (
      context,
      self,
      self INDICATOR STRUCT,
      return INT
    )
);
/

