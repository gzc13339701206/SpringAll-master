create view DRV$UNINDEXED as
select "UNX_IDX_ID","UNX_IXP_ID","UNX_ROWID" from dr$unindexed
/

