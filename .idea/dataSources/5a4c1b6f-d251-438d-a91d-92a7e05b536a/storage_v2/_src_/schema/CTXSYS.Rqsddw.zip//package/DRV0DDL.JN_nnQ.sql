create package drv0ddl authid current_user is

  TYPE itab_rec_t is record(
    token_text  varchar2(64),
    token_type  number(3),
    token_first number,
    token_last  number,
    token_count number,
    token_info_raw   raw(4000),
    token_info_blob  blob);

   TYPE itab_typ_cur is ref cursor return itab_rec_t;

   FUNCTION optimize_index(
     optim_state dr$optim_state_t,
     crsr        drv0ddl.itab_typ_cur,
     tempItab    VARCHAR2,
     ntab        VARCHAR2
   ) return dr$itab0_set_t
     order crsr BY (token_text, token_type, token_first)
     parallel_enable (partition crsr BY HASH(token_text))
     pipelined using dr$opttf_impl_t ;
end drv0ddl;
/

