create type textureEncoding as VARRAY(5) of DOUBLE PRECISION;
/

