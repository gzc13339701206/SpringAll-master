create type colorFrequenciesList as VARRAY(100) of DOUBLE PRECISION;
/

