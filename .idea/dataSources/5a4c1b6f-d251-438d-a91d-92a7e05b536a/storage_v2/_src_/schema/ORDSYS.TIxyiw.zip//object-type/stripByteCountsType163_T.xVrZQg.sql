create TYPE          "stripByteCountsType163_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","tag" NUMBER(38),"StripByteCount" "StripByteCount165_COLL")NOT FINAL INSTANTIABLE
/

