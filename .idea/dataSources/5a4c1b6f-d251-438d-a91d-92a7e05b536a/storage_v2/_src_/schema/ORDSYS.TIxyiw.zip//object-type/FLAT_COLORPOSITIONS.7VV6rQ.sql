create type flat_colorPositions as VARRAY(27) of DOUBLE PRECISION;
/

