create TYPE          "exifMetadata192_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","TiffIfd" "TiffIfd193_T","ExifIfd" "ExifIfd194_T","GpsIfd" "GpsIfd195_T","InteroperabilityIfd" "InteroperabilityIfd196_T")FINAL INSTANTIABLE
/

