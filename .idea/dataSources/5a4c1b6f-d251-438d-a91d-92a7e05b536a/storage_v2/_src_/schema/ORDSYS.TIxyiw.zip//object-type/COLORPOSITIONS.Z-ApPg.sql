create type colorPositions as VARRAY(9) of SI_Color;
/

