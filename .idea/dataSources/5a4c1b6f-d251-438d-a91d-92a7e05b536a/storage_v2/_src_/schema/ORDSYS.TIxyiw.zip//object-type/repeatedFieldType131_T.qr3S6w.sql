create TYPE          "repeatedFieldType131_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","tag" NUMBER(38),"Field" "Field132_COLL")NOT FINAL INSTANTIABLE
/

