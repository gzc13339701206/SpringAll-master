create TYPE          "byline99_COLL" AS VARRAY(2147483647) OF "bylineType98_T"
/

