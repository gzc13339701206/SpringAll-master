create TYPE          "singleFieldType133_T" UNDER "singleField_t130_T"("tag" NUMBER(38))NOT FINAL INSTANTIABLE
/

