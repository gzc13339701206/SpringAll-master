create TYPE colorsList AS VARRAY(100) of SI_Color;
/

