create TYPE          "subjectAreaType157_T" UNDER "subjectLocationType158_T"("Diameter" NUMBER(38),"Width" NUMBER(38),"Height" NUMBER(38))NOT FINAL INSTANTIABLE
/

