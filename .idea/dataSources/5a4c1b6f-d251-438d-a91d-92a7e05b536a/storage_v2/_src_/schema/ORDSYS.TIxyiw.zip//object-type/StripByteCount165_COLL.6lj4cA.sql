create TYPE          "StripByteCount165_COLL" AS VARRAY(2147483647) OF "StripByteCount164_T"
/

