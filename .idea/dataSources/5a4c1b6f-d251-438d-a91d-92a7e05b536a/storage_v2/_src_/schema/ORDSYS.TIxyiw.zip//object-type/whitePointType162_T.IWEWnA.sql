create TYPE          "whitePointType162_T" UNDER "chromaticity160_T"("tag" NUMBER(38))NOT FINAL INSTANTIABLE
/

