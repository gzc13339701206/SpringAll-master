create TYPE SI_StillImage
                                                                             AUTHID CURRENT_USER
  AS OBJECT
    (
     -- THE FUNCTIONS, PACKAGES AND TYPES SUPPLIED BY THIS PACKAGE AND
     --ITS EXTERNAL
     -- INTERFACE ARE RESERVED BY ORACLE AND ARE SUBJECT TO CHANGE IN FUTURE
     -- RELEASES. THIS PACKAGE MUST NOT BE MODIFIED BY THE CUSTOMER.  DOING SO
     -- COULD CAUSE INTERNAL ERRORS AND SECURITY VIOLATIONS IN THE DBMS.

     --Type attributes
     content_si           ORDSYS.ORDSOURCE,
     contentLength_si     INTEGER,
     format_si            VARCHAR2(4000),
     height_si            INTEGER,
     width_si             INTEGER,

     --ora attribute extensions
     mimeType_ora          VARCHAR2(4000),
     contentFormat_ora     VARCHAR2(4000),
     compressionFormat_ora VARCHAR2(4000),

     --Flag to
     retainFeatures_SI  INTEGER,

     --ora extension attributes to cache image features
     --use internal of image features to avoid circular reference
     --issues
     averageColorSpec_ora   SI_Color,
     colorsList_ora         colorsList,
     frequenciesList_ora    colorFrequenciesList,
     colorPositions_ora     colorPositions,
     textureEncoding_ora    textureEncoding,

    --
    --Constructors methods
    CONSTRUCTOR FUNCTION
    SI_StillImage(content IN BLOB) return SELF as RESULT DETERMINISTIC,
    --
    CONSTRUCTOR FUNCTION
    SI_StillImage( content IN BLOB,
                   explicitFormat IN VARCHAR2
                   ) return SELF as RESULT DETERMINISTIC,
    --
    CONSTRUCTOR FUNCTION
    SI_StillImage(content IN BLOB,
                  explicitFormat IN VARCHAR2,
                  height IN INTEGER,
                  width IN INTEGER)  return SELF as RESULT DETERMINISTIC,


     --
     --Accessor methods for SI_ attributes
     MEMBER FUNCTION SI_height return INTEGER DETERMINISTIC,
     PRAGMA RESTRICT_REFERENCES(SI_height, WNDS, WNPS, RNDS, RNPS),

     MEMBER FUNCTION SI_width return INTEGER DETERMINISTIC,
     PRAGMA RESTRICT_REFERENCES(SI_width, WNDS, WNPS, RNDS, RNPS),

     MEMBER FUNCTION SI_format return VARCHAR2 DETERMINISTIC,
     PRAGMA RESTRICT_REFERENCES(SI_format, WNDS, WNPS, RNDS, RNPS),

     MEMBER FUNCTION SI_content return BLOB DETERMINISTIC,
     PRAGMA RESTRICT_REFERENCES(SI_content, WNDS, WNPS, RNDS, RNPS),

     MEMBER FUNCTION SI_contentLength return INTEGER DETERMINISTIC,
     PRAGMA RESTRICT_REFERENCES(SI_contentLength, WNDS, WNPS, RNDS, RNPS),

     --Accessor method of for retainFeatures_SI attribute
     MEMBER FUNCTION SI_retainFeatures return BOOLEAN DETERMINISTIC,
     PRAGMA RESTRICT_REFERENCES(SI_retainFeatures, WNDS, WNPS, RNDS, RNPS),

     --Image processing methods
     MEMBER PROCEDURE SI_setContent(SELF IN OUT NOCOPY SI_StillImage,
                                    content IN BLOB),
     MEMBER PROCEDURE SI_changeFormat(SELF IN OUT NOCOPY SI_StillImage,
                                      targetFormat IN VARCHAR2),
     MEMBER FUNCTION SI_Thumbnail(SELF IN SI_StillImage)
                     return SI_StillImage DETERMINISTIC ,

     MEMBER FUNCTION SI_Thumbnail(SELF IN SI_StillImage,
                                  height IN INTEGER,
                                  width IN INTEGER)
                     return SI_StillImage DETERMINISTIC,

     --Oracle extension for image feature caching
     --Extract image features and turn on image feature caching
     MEMBER PROCEDURE   SI_InitFeatures,

     --Resets image features attributes to null and stop
     --image feature caching
     MEMBER PROCEDURE   SI_ClearFeatures

) INSTANTIABLE
NOT FINAL;
/

