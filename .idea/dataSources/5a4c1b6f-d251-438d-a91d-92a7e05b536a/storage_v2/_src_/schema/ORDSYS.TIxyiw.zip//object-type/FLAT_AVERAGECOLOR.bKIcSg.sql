create type flat_averageColor as VARRAY(3) of integer;
/

