create TYPE          "stripOffsetsType166_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","tag" NUMBER(38),"StripOffset" "StripOffset168_COLL")NOT FINAL INSTANTIABLE
/

