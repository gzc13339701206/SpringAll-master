create TYPE          "supplementalCategory95_COLL" AS VARRAY(2147483647) OF VARCHAR2(4000 CHAR)
/

