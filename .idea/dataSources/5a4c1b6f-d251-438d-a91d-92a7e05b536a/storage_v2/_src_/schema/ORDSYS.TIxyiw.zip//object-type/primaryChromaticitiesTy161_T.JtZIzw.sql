create TYPE          "primaryChromaticitiesTy161_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","tag" NUMBER(38),"Color_1" "chromaticity160_T","Color_2" "chromaticity160_T","Color_3" "chromaticity160_T")NOT FINAL INSTANTIABLE
/

