create TYPE          "StripOffset168_COLL" AS VARRAY(2147483647) OF "StripOffset167_T"
/

