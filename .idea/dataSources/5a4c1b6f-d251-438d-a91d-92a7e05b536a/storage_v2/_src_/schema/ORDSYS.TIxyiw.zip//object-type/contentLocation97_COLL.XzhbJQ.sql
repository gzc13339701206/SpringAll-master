create TYPE          "contentLocation97_COLL" AS VARRAY(2147483647) OF "locationType96_T"
/

