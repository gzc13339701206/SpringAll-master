create TYPE          "Field132_COLL" AS VARRAY(2147483647) OF "singleField_t130_T"
/

