create TYPE       "error-page-type55_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","error-page" "error-page58_COLL")NOT FINAL INSTANTIABLE
/

