create TYPE       "security-role-ref5_COLL" AS VARRAY(65535) OF "security-role-ref4_T"
/

