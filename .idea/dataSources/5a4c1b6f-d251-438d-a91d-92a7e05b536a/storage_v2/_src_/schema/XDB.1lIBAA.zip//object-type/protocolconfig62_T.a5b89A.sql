create TYPE       "protocolconfig62_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","common" "common63_T","ftpconfig" "ftpconfig65_T","httpconfig" "httpconfig66_T")FINAL INSTANTIABLE
/

