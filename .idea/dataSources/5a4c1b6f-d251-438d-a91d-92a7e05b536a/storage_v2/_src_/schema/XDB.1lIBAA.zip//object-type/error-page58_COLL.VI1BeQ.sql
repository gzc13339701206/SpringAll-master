create TYPE       "error-page58_COLL" AS VARRAY(2147483647) OF "error-page56_T"
/

