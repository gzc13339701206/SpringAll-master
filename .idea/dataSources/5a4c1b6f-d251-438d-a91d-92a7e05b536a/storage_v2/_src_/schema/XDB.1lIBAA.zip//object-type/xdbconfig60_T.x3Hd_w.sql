create TYPE       "xdbconfig60_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","sysconfig" "sysconfig61_T","userconfig" "userconfig70_T")FINAL INSTANTIABLE
/

