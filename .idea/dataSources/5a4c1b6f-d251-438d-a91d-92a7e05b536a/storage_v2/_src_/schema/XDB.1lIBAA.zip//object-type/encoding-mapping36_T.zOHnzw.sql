create TYPE       "encoding-mapping36_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","extension" VARCHAR2(4000 CHAR),"encoding" VARCHAR2(4000 CHAR))FINAL INSTANTIABLE
/

