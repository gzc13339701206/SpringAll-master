create TYPE       "lang-mapping43_COLL" AS VARRAY(2147483647) OF "lang-mapping42_T"
/

