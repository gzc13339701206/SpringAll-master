create TYPE       "servlet-config-type44_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","servlet-mappings" "servlet-mappings45_T","servlet-list" "servlet-list48_T")NOT FINAL INSTANTIABLE
/

