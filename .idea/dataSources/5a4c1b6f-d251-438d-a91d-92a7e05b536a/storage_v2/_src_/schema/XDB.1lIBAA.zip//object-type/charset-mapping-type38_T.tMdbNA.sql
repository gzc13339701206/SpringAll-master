create TYPE       "charset-mapping-type38_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","charset-mapping" "charset-mapping40_COLL")NOT FINAL INSTANTIABLE
/

