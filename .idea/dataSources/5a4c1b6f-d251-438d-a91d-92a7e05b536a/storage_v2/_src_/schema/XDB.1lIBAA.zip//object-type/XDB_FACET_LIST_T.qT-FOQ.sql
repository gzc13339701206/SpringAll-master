create type     xdb$facet_list_t                                        as
VARRAY(65535) of xdb.xdb$facet_t;
/

