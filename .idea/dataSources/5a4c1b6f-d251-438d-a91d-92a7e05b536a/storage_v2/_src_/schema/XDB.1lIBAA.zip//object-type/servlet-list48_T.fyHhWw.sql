create TYPE       "servlet-list48_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","servlet" "servlet54_COLL")FINAL INSTANTIABLE
/

