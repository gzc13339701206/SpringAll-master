create type     PathidSet_t as varray(2147483647) of RAW(8);
/

