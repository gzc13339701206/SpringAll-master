create TYPE       "welcome-file-type59_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","welcome-file" "upload-as-long-raw26_COLL")NOT FINAL INSTANTIABLE
/

