create TYPE       "mime-mapping-type32_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","mime-mapping" "mime-mapping34_COLL")NOT FINAL INSTANTIABLE
/

