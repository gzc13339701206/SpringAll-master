create FUNCTION XMLROOT (XML XMLType, PI VARCHAR2 DEFAULT NULL)
RETURN XMLType DETERMINISTIC
IS
  tempCLOB CLOB;
  tempXML XMLType;
BEGIN
  SELECT XMLParse(DOCUMENT '<?xml version="1.0" encoding="UTF-8"?>' || PI ||
                  XML.getClobVal() WELLFORMED)
    INTO tempXML
    FROM DUAL;
  RETURN tempXML;
END;
/

