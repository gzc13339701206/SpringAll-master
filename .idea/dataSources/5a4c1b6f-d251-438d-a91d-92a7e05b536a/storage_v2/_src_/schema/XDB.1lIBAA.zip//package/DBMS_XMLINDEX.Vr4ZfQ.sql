create PACKAGE     dbms_xmlindex AUTHID CURRENT_USER IS

----------------------------------------------------------------------------
-- PROCEDURE - CreateNumberIndex
--     Creates an index for number values in the XMLIndex. The index
--     is created on the VALUE column of the XMLIndex path table on the
--     expression TO_BINARY_DOUBLE(VALUE).
-- PARAMETERS -
--  xml_index_schema
--     Schema of the XMLIndex
--  xml_index_name
--     Name of the XMLIndex
--  num_index_name
--     Name of the number index to create
--  num_index_clause
--     Storage clause for the number index. This would simply be appended
--     to the CREATE INDEX statement.
----------------------------------------------------------------------------
PROCEDURE CreateNumberIndex(xml_index_schema IN VARCHAR2,
                            xml_index_name   IN VARCHAR2,
                            num_index_name   IN VARCHAR2,
                            num_index_clause IN VARCHAR2 := '');


----------------------------------------------------------------------------
-- PROCEDURE - CreateDateIndex
--     Creates an index for date values in the XMLIndex. The user specifies
--     the XML type name (date, dateTime etc.) and the index is created
--     on SYS_XMLCONV(VALUE) which would always return a TIMESTAMP datatype.
-- PARAMETERS -
--  xml_index_schema
--     Schema of the XMLIndex
--  xml_index_name
--     Name of the XMLIndex
--  date_index_name
--     Name of the date index to be created
--  xmltypename
--     XML type name - one of the following
--         dateTime
--         time
--         date
--         gDay
--         gMonth
--         gYear
--         gYearMonth
--         gMonthDay
--  date_index_clause
--     Storage clause for the date index. This would simply be appended
--     to the CREATE INDEX statement.
----------------------------------------------------------------------------
PROCEDURE CreateDateIndex(xml_index_schema  IN VARCHAR2,
                          xml_index_name    IN VARCHAR2,
                          date_index_name   IN VARCHAR2,
                          xmltypename       IN VARCHAR2,
                          date_index_clause IN VARCHAR2 := '');

end dbms_xmlindex;
/

