create TYPE       "plsql68_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","log-level" NUMBER(10),"max-parameters" NUMBER(10))FINAL INSTANTIABLE
/

