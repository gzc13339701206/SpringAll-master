create TYPE       "ftp-log-entry13_COLL" AS VARRAY(2147483647) OF "ftp-log-entry-type10_T"
/

