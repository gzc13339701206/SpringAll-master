create TYPE       "XDB$ACE_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","grant" RAW(1),"privilege" "XDB$PRIV_T","principalID" RAW(2000),"flags" NUMBER(10))FINAL INSTANTIABLE
/

