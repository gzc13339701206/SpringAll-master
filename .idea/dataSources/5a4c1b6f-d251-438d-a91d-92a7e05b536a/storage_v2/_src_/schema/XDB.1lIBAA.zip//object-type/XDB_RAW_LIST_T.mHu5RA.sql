create type     xdb$raw_list_t                                        as varray(1000) of raw(2000);
/

