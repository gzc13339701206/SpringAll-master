create TYPE       "XDB$ACL_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","shared" RAW(1),"description" VARCHAR2(4000 CHAR),"ace" "XDB$ACE_LIST_T","schemaOID" RAW(2000),"elementNum" NUMBER(10))FINAL INSTANTIABLE
/

