create TYPE       "bind-bucket-lengths27_COLL" AS VARRAY(2147483647) OF NUMBER(10)
/

