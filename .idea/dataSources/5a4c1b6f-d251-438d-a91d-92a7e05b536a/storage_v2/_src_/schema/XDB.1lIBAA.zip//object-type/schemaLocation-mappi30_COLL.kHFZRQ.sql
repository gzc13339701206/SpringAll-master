create TYPE       "schemaLocation-mappi30_COLL" AS VARRAY(2147483647) OF "schemaLocation-mapping29_T"
/

