create package     XMLIndex_FUNCIMPL authid current_user is
  function getnodes_func(res sys.xmltype,
                           pathstr varchar2,
                           ia sys.odciindexctx,
                           sctx IN OUT XDB.XMLIndexMethods,
                           sflg number)
  return number;

  function load_func
  return XDB.XMLIndexTab_t
  is language C name "QMIX_LOADFUNC" LIBRARY XDB.XMLINDEX_LIB
     with context parameters (
       context,
       RETURN  INDICATOR sb4,
       RETURN  OCIColl);

  function isattr_func(loc IN RAW)
  return Number
  is language C name "QMIX_ISATTR" LIBRARY XDB.XMLINDEX_LIB
     with context parameters (
       context,
       loc    RAW,
       loc    INDICATOR sb4,
       loc    LENGTH    sb4,
       RETURN OCINumber);

end XMLIndex_FUNCIMPL;
/

