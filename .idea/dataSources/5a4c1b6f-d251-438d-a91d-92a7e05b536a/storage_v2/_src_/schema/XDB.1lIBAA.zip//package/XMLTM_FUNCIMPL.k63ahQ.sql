create package     XMLTM_FUNCIMPL authid current_user is
  function SuffixPathids(pathid IN RAW)
  return XDB.PathidSet_t
  is language C name "QMTM_SUFFIXPATHIDS"
     LIBRARY XDB.XMLTM_LIB
     with context parameters (
       context,
       pathid  RAW,
       pathid  INDICATOR sb4,
       pathid  LENGTH sb4,
       RETURN  INDICATOR sb4,
       RETURN  OCIColl);
end XMLTM_FUNCIMPL;
/

