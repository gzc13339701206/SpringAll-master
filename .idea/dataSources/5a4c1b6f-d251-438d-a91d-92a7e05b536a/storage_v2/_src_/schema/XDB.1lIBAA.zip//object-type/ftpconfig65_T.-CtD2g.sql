create TYPE       "ftpconfig65_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","ftp-port" NUMBER(5),"ftp-listener" VARCHAR2(4000 CHAR),"ftp-protocol" VARCHAR2(4000 CHAR),"logfile-path" VARCHAR2(4000 CHAR),"log-level" NUMBER(10),"session-timeout" NUMBER(10),"buffer-size" NUMBER(10),"ftp-welcome-message" VARCHAR2(4000 CHAR))FINAL INSTANTIABLE
/

