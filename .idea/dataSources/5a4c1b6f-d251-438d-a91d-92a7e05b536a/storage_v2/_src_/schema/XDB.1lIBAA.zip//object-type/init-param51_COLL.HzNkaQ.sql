create TYPE       "init-param51_COLL" AS VARRAY(2147483647) OF "param50_T"
/

