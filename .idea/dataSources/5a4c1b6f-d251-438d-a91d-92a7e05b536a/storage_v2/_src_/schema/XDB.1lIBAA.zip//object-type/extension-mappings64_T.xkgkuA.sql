create TYPE       "extension-mappings64_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","mime-mappings" "mime-mapping-type32_T","lang-mappings" "lang-mapping-type41_T","charset-mappings" "charset-mapping-type38_T","encoding-mappings" "encoding-mapping-type35_T","xml-extensions" "xml-extension-type31_T")FINAL INSTANTIABLE
/

