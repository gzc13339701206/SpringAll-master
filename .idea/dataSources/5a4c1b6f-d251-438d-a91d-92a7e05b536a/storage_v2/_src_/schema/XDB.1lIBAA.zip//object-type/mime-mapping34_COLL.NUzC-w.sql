create TYPE       "mime-mapping34_COLL" AS VARRAY(2147483647) OF "mime-mapping33_T"
/

