create TYPE       "xdb-log-entry8_COLL" AS VARRAY(2147483647) OF "xdb-log-entry-type6_T"
/

