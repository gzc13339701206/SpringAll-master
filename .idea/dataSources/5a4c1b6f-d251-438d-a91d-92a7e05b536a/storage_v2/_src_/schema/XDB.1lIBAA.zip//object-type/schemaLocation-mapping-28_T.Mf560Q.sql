create TYPE       "schemaLocation-mapping-28_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","schemaLocation-mapping" "schemaLocation-mappi30_COLL")NOT FINAL INSTANTIABLE
/

