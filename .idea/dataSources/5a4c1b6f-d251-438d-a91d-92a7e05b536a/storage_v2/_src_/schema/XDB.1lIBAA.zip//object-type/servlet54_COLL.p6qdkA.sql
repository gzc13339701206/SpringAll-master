create TYPE       "servlet54_COLL" AS VARRAY(2147483647) OF "servlet49_T"
/

