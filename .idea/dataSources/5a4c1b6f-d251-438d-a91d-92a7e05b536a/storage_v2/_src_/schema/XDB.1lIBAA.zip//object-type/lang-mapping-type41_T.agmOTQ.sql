create TYPE       "lang-mapping-type41_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","lang-mapping" "lang-mapping43_COLL")NOT FINAL INSTANTIABLE
/

