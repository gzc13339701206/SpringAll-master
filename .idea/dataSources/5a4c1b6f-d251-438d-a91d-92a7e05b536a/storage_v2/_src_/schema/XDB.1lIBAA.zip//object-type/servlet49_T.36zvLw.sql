create TYPE       "servlet49_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","servlet-name" VARCHAR2(4000 CHAR),"servlet-language" "XDB$ENUM_T","icon" VARCHAR2(4000 CHAR),"display-name" VARCHAR2(4000 CHAR),"description" VARCHAR2(4000 CHAR),"servlet-schema" VARCHAR2(4000 CHAR),"init-param" "init-param51_COLL","load-on-startup" VARCHAR2(4000 CHAR),"security-role-ref" "security-role-ref53_COLL","servlet-class" VARCHAR2(4000 CHAR),"jsp-file" VARCHAR2(4000 CHAR),"plsql" "plsql-servlet-config25_T")FINAL INSTANTIABLE
/

