create TYPE       "servlet-mapping46_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","servlet-pattern" VARCHAR2(4000 CHAR),"servlet-name" VARCHAR2(4000 CHAR))FINAL INSTANTIABLE
/

