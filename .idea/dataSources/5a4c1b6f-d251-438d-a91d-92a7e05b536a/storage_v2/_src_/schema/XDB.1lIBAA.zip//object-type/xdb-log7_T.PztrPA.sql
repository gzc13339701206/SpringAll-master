create TYPE       "xdb-log7_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","xdb-log-entry" "xdb-log-entry8_COLL")FINAL INSTANTIABLE
/

