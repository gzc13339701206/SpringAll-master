create TYPE       "servlet-mappings45_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","servlet-mapping" "servlet-mapping47_COLL")FINAL INSTANTIABLE
/

