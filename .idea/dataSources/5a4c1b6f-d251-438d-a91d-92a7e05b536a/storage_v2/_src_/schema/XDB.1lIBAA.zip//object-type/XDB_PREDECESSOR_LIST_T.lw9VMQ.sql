create type     XDB$PREDECESSOR_LIST_T                                        AS varray(1000) of raw(16);
/

