create TYPE       "ftp-log12_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","ftp-log-entry" "ftp-log-entry13_COLL")FINAL INSTANTIABLE
/

