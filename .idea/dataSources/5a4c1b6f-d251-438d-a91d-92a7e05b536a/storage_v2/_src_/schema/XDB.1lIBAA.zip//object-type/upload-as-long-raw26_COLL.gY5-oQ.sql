create TYPE       "upload-as-long-raw26_COLL" AS VARRAY(2147483647) OF VARCHAR2(4000 CHAR)
/

