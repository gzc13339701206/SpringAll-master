create TYPE       "http-log-entry19_COLL" AS VARRAY(2147483647) OF "http-log-entry-type15_T"
/

