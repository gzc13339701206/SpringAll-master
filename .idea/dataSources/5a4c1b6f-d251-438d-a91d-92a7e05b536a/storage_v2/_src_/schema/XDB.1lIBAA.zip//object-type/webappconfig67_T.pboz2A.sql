create TYPE       "webappconfig67_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","welcome-file-list" "welcome-file-type59_T","error-pages" "error-page-type55_T","servletconfig" "servlet-config-type44_T")FINAL INSTANTIABLE
/

