create TYPE       "charset-mapping40_COLL" AS VARRAY(2147483647) OF "charset-mapping39_T"
/

