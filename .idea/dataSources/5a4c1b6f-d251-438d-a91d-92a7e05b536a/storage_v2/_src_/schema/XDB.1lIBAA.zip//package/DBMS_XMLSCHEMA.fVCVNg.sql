create package     dbms_xmlschema authid current_user is
  ---------------------------------------------
  --  OVERVIEW
  --
  --  This package provides procedures to
  --  (*) register an XML schema
  --  (*) delete a previously registered XML schema
  --  (*) re-compile a previously registered XML schema
  --  (*) generate an XML schema
  --
  ---------------------------------------------

  ------------
  -- CONSTANTS
  --
  ------------
  DELETE_RESTRICT CONSTANT NUMBER := 1;
  DELETE_INVALIDATE CONSTANT NUMBER := 2;
  DELETE_CASCADE  CONSTANT NUMBER := 3;
  DELETE_CASCADE_FORCE CONSTANT NUMBER := 4;

  ENABLE_HIERARCHY_NONE CONSTANT PLS_INTEGER        := 1;
  ENABLE_HIERARCHY_CONTENTS CONSTANT PLS_INTEGER    := 2;
  ENABLE_HIERARCHY_RESMETADATA CONSTANT PLS_INTEGER := 3;

  REGISTER_NODOCID CONSTANT NUMBER := 1;

  REGISTER_CSID_NULL CONSTANT NUMBER := -1;

  ------------
  -- TYPES
  ------------
  TYPE URLARR is VARRAY(1000) of VARCHAR2(1000);
  TYPE XMLARR is VARRAY(1000) of XMLType;
  TYPE UNAME_ARR is VARRAY(1000) of VARCHAR2(100);

  ---------------------------------------------
  -- PROCEDURE - registerSchema
  -- PARAMETERS -
  --  schemaURL
  --     A name that uniquely identifies the schema document.
  --  schemaDoc
  --     a valid XML schema document
  --  local
  --     Is this a local or global schema ? By default, all schemas
  --     are registered as local schemas i.e. under
  --       /sys/schemas/<username>/...
  --     If a schema is registered as global, it is added under
  --       /sys/schemas/PUBLIC/...
  --     You need write privileges on the above directory to be
  --     able to register a schema as global.
  --  genTypes
  --     Should the schema compiler generate object types ?
  --  genbean
  --     Should the schema compiler generate Java beans ?
  --  genTables
  --     Should the schema compiler generate default tables ?
  --  force
  --     Should the schema be created/stored even with errors?
  --       Setting this to TRUE will register the schema in the
  --       hierarchy even if there were compilation errors, but
  --       the schema cannot be used until it is made valid.
  --  csid
  --     Character set id of the input blob or bfile.
  --     The value REGISTER_CSID_NULL indicates that the CSID was
  --     not passed in. If users pass in REGISTER_CSID_NULL as the value
  --     of the csid parameter, then the behavior will be the same as
  --     when csid was not passed in.
  --  options
  --     Additional options to specify how the schema should be
  --     registered. The various options are represented as bits
  --     of an integer and the options parameter should be
  --     constructed by doing a bitor of the desired bits.
  --     The possible bits for this are:
  --       REGISTER_NODOCID :: this will suppress the creation
  --       of the DOCID column for out of line tables. This is a
  --       storage optimization which might be desirable when
  --       we do not need to join back to the document table (for example
  --       if we do not care about rewriting certain queries that could
  --       be rewritten by making use of the DOCID column)
  --  enableHierarchy
  --     Specifies how the tables generated during schema registration
  --     should be hierarchically enabled. It must be one of the following:
  --     ENABLE_HIERARCHY_NONE : none of the tables will have hierarchy
  --     enabled on them
  --     ENABLE_HIERARCHY_CONTENTS : enables hierarchy for contents i.e.
  --     the tables can be used to store contents of resources
  --     ENABLE_HIERARCHY_RESMETADATA : enables hierarchy for resource metadata
  --     i.e. the tables can be used to store resource metadata
  --
  -- EXCEPTIONS
  --   ORA-31001: Invalid resource handle or path name
  --   todo
  ---------------------------------------------
  procedure registerSchema(schemaURL IN varchar2,
                           schemaDoc IN VARCHAR2,
                           local IN BOOLEAN := TRUE,
                           genTypes IN BOOLEAN := TRUE,
                           genbean IN BOOLEAN := FALSE,
                           genTables IN BOOLEAN := TRUE,
                           force IN BOOLEAN := FALSE,
                           owner IN VARCHAR2 := '',
                           enableHierarchy IN pls_integer :=
                           ENABLE_HIERARCHY_CONTENTS,
                           options IN pls_integer := 0);

  procedure registerSchema(schemaURL IN varchar2,
                           schemaDoc IN CLOB,
                           local IN BOOLEAN := TRUE,
                           genTypes IN BOOLEAN := TRUE,
                           genbean IN BOOLEAN := FALSE,
                           genTables IN BOOLEAN := TRUE,
                           force IN BOOLEAN := FALSE,
                           owner IN VARCHAR2 := '',
                           enableHierarchy IN pls_integer :=
                           ENABLE_HIERARCHY_CONTENTS,
                           options IN pls_integer := 0);

  procedure registerSchema(schemaURL IN varchar2,
                           schemaDoc IN BLOB,
                           local IN BOOLEAN := TRUE,
                           genTypes IN BOOLEAN := TRUE,
                           genbean IN BOOLEAN := FALSE,
                           genTables IN BOOLEAN := TRUE,
                           force IN BOOLEAN := FALSE,
                           owner IN VARCHAR2 := '',
                           csid IN NUMBER := REGISTER_CSID_NULL,
                           enableHierarchy IN pls_integer :=
                           ENABLE_HIERARCHY_CONTENTS,
                           options IN pls_integer := 0);

  procedure registerSchema(schemaURL IN varchar2,
                           schemaDoc IN BFILE,
                           local IN BOOLEAN := TRUE,
                           genTypes IN BOOLEAN := TRUE,
                           genbean IN BOOLEAN := FALSE,
                           genTables IN BOOLEAN := TRUE,
                           force IN BOOLEAN := FALSE,
                           owner IN VARCHAR2 := '',
                           csid IN NUMBER := REGISTER_CSID_NULL,
                           enableHierarchy IN pls_integer :=
                           ENABLE_HIERARCHY_CONTENTS,
                           options IN pls_integer := 0);

  procedure registerSchema(schemaURL IN varchar2,
                           schemaDoc IN sys.XMLType,
                           local IN BOOLEAN := TRUE,
                           genTypes IN BOOLEAN := TRUE,
                           genbean IN BOOLEAN := FALSE,
                           genTables IN BOOLEAN := TRUE,
                           force IN BOOLEAN := FALSE,
                           owner IN VARCHAR2 := '',
                           enableHierarchy IN pls_integer :=
                           ENABLE_HIERARCHY_CONTENTS,
                           options IN pls_integer := 0);

  procedure registerSchema(schemaURL IN varchar2,
                           schemaDoc IN sys.UriType,
                           local IN BOOLEAN := TRUE,
                           genTypes IN BOOLEAN := TRUE,
                           genbean IN BOOLEAN := FALSE,
                           genTables IN BOOLEAN := TRUE,
                           force IN BOOLEAN := FALSE,
                           owner IN VARCHAR2 := '',
                           enableHierarchy IN pls_integer :=
                           ENABLE_HIERARCHY_CONTENTS,
                           options IN pls_integer := 0);

  ---------------------------------------------
  -- PROCEDURE - registerURI
  -- PARAMETERS -
  --  schemaURL
  --     A name that uniquely identifies the schema document.
  --  schemaDocURI
  --     A pathname (URI) corresponding to the physical location of the
  --     schema document. The URI path could be based on HTTP, FTP, DB or XDB
  --     protocols. This function constructs a URIType instance using
  --     the URIFactory - and invokes the regiserSchema function above.
  --  <all other paramaters> Same as above
  ---------------------------------------------
  procedure registerURI(schemaURL IN varchar2,
                        schemaDocURI IN varchar2,
                        local IN BOOLEAN := TRUE,
                        genTypes IN BOOLEAN := TRUE,
                        genbean IN BOOLEAN := FALSE,
                        genTables IN BOOLEAN := TRUE,
                        force IN BOOLEAN := FALSE,
                        owner IN VARCHAR2 := '',
                        enableHierarchy IN pls_integer :=
                        ENABLE_HIERARCHY_CONTENTS,
                        options IN pls_integer := 0);

  ---------------------------------------------
  -- PROCEDURE - deleteSchema
  -- PARAMETERS -
  --  schemaURL : Name identifying the schema to be deleted
  --  option : one of the following
  --    DELETE_RESTRICT ::
  --      Schema deletion fails if there are any tables or schemas that
  --      depend on this schema.
  --    DELETE_INVALIDATE :
  --      Schema deletion does not fail if there are any dependencies.
  --      Instead, it simply invalidates all dependent objects.
  --    DELETE_CASCADE ::
  --      Schema deletion will also drop all default SQL types and
  --      default tables. However the deletion fails if there are
  --      any stored instances conforming to this schema.
  --    DELETE_CASCADE_FORCE ::
  --      Similar to CASCADE except that it does not check for any stored
  --      instances conforming to this schema. Also it ignores any errors.
  --
  -- EXCEPTIONS
  --   ORA-31001: Invalid resource handle or path name
  --   todo
  ---------------------------------------------
  procedure deleteSchema(schemaURL IN varchar2,
                         delete_option IN pls_integer := DELETE_RESTRICT);

  ---------------------------------------------
  -- PROCEDURE - generateBean
  --  This procedure can be used to generate the Java bean code
  --  corresponding to a registered XML schema.
  --  Note that there is also an option to generate the beans
  --  as part of the registration procedure itself.
  -- PARAMETERS -
  --  schemaURL : Name identifying a registered XML schema.
  -- EXCEPTIONS
  --   ORA-31001: Invalid resource handle or path name
  --   todo
  ---------------------------------------------
  procedure generateBean(schemaURL IN varchar2);

  ---------------------------------------------
  -- PROCEDURE - compileSchema
  --  This procedure can be used to re-compile an already registered XML
  --  schema. This is useful for bringing a schema in an invalid
  --  state to a valid state.
  -- PARAMETERS -
  --  schemaURL : URL identifying the schema
  -- EXCEPTIONS
  --   ORA-31001: Invalid resource handle or path name
  ---------------------------------------------
  procedure compileSchema(schemaURL IN varchar2);

  ---------------------------------------------
  -- FUNCTION - generateSchema(s)
  --  These functions generate XML schema(s) from
  --  an oracle type name.  generateSchemas returns a collection
  --  of XMLTypes, one XMLSchema document for each database schema.
  --  generateSchema inlines them all in one schema (XMLType).
  -- PARAMETERS -
  --  schemaName  : the name of the database schema containing the type
  --  typeName    : the name of the oracle type
  --  elementName : the name of the toplevel element in the XMLSchema
  --                defaults to typeName
  --  schemaURL   : specifies base URL where schemas will be stored,
  --                needed by top level schema for import statement
  --  recurse     : whether or not to also generate schema for all types
  --                referred to by the type specified
  --  annotate    : whether or not to put the SQL annotations in the XMLSchema
  --  embedColl   : whether you want collections embedded in the type which
  --                refers to them or you want them to have a complexType
  --                created, can not be false with annotations true
  -- EXCEPTIONS
  --  TBD
  ---------------------------------------------
  function generateSchemas( schemaName IN varchar2, typeName IN varchar2,
                            elementName IN varchar2 := NULL,
                            schemaURL IN varchar2 := NULL,
                            annotate IN BOOLEAN := TRUE,
                            embedColl IN BOOLEAN := TRUE )
    return sys.XMLSequenceType;

  function generateSchema( schemaName IN varchar2, typeName IN varchar2,
                           elementName IN varchar2 := NULL,
                           recurse IN BOOLEAN := TRUE,
                           annotate IN BOOLEAN := TRUE,
                           embedColl IN BOOLEAN := TRUE ) return sys.XMLType;

  procedure CopyEvolve(schemaURLs         IN XDB$STRING_LIST_T,
                       newSchemas         IN XMLSequenceType,
                       transforms         IN XMLSequenceType := NULL,
                       preserveOldDocs    IN BOOLEAN := FALSE,
                       mapTabName         IN VARCHAR2 := NULL,
                       generateTables     IN BOOLEAN := TRUE,
                       force              IN BOOLEAN := FALSE,
                       schemaOwners       IN XDB$STRING_LIST_T := NULL,
                       parallelDegree     IN PLS_INTEGER := 0);


  ---------------------------------------------
  -- FUNCTION - convertToDate
  --  This function converts the string representation of the following
  --  specified XML Schema types into the Oracle DATE representation
  --  using a default reference date and format mask.
  -- PARAMETERS -
  --  strval : string representation of valid value (per XML Schema)
  --  xmltypename : Name of the XML Schema datatype.
  --                Has to be one of the following:
  --                 * gDay
  --                 * gMonth
  --                 * gYear
  --                 * gYearMonth
  --                 * gMonthDay
  --                 * date
  ---------------------------------------------
  function convertToDate(strval varchar2, xmltypename varchar2)
  return DATE deterministic parallel_enable;

  ---------------------------------------------
  -- FUNCTION - convertToTS
  --  This function converts the string representation of the following
  --  specified XML Schema types into the Oracle TIMESTAMP representation
  --  using a default reference date and format mask.
  -- PARAMETERS -
  --  strval : string representation of valid value (per XML Schema)
  --  xmltypename : Name of the XML Schema datatype.
  --                Has to be one of the following:
  --                 * dateTime
  --                 * time
  ---------------------------------------------
  function convertToTS(strval varchar2, xmltypename varchar2)
  return TIMESTAMP deterministic parallel_enable;

  ---------------------------------------------
  -- FUNCTION - convertToTSWithTZ
  --  This function converts the string representation of the following
  --  specified XML Schema types into the Oracle
  --  TIMESTAMP WITH TIMEZONE representation using a default reference
  --  date and format mask.
  -- PARAMETERS -
  --  strval : string representation of valid value (per XML Schema)
  --  xmltypename : Name of the XML Schema datatype.
  --                Has to be one of the following:
  --                 * gDay
  --                 * gMonth
  --                 * gYear
  --                 * gYearMonth
  --                 * gMonthDay
  --                 * date
  --                 * dateTime
  --                 * time
  ---------------------------------------------
  function convertToTSWithTZ(strval varchar2, xmltypename varchar2)
  return TIMESTAMP WITH TIME ZONE deterministic parallel_enable;

end dbms_xmlschema;
/

