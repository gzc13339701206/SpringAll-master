create TYPE       "encoding-mapping-type35_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","encoding-mapping" "encoding-mapping37_COLL")NOT FINAL INSTANTIABLE
/

