create TYPE       "xml-extension-type31_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","extension" "upload-as-long-raw26_COLL")NOT FINAL INSTANTIABLE
/

