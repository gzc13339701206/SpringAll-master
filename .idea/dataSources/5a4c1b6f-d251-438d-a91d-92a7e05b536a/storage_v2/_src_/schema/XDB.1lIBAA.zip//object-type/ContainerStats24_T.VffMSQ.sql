create TYPE       "ContainerStats24_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","RESOID" RAW(32),"TotalRows" NUMBER,"TotalContainers" NUMBER,"FanOut" NUMBER(38),"ImmediateContainers" NUMBER(38),"LastAnalyzedDate" TIMESTAMP)FINAL INSTANTIABLE
/

