create TYPE       "common63_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","extension-mappings" "extension-mappings64_T","session-pool-size" NUMBER(10),"session-timeout" NUMBER(10))FINAL INSTANTIABLE
/

