create TYPE       "servlet-mapping47_COLL" AS VARRAY(2147483647) OF "servlet-mapping46_T"
/

