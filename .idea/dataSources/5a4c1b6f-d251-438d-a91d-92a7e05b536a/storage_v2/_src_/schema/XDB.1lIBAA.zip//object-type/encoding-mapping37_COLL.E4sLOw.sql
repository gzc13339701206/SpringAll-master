create TYPE       "encoding-mapping37_COLL" AS VARRAY(2147483647) OF "encoding-mapping36_T"
/

