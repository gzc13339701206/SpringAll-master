create TYPE       "error-page56_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","location" VARCHAR2(4000 CHAR),"error-code" NUMBER(38),"exception-type" VARCHAR2(4000 CHAR),"OracleError" "OracleError57_T")FINAL INSTANTIABLE
/

