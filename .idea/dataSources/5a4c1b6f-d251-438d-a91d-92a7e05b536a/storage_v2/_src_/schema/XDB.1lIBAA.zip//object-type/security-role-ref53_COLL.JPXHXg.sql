create TYPE       "security-role-ref53_COLL" AS VARRAY(2147483647) OF "security-role-ref52_T"
/

