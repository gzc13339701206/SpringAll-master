create view ALL_WM_VERSIONED_TABLES as
  select /*+ ORDERED */ vt.table_name, vt.owner,
        disabling_ver state,
        vt.hist history,
        decode(vt.notification,0,'NO',1,'YES') notification,
        substr(notifyWorkspaces,2,length(notifyworkspaces)-2) notifyworkspaces,
        sys.ltadm.AreThereConflicts(vt.owner, vt.table_name) conflict,
        sys.ltadm.AreThereDiffs(vt.owner, vt.table_name) diff
 from wmsys.wm$versioned_tables vt, all_views av
 where vt.table_name = av.view_name and vt.owner = av.owner
union all
 select /*+ ORDERED */ vt.table_name, vt.owner,
        disabling_ver state,
        vt.hist history,
        decode(vt.notification,0,'NO',1,'YES') notification,
        substr(notifyWorkspaces,2,length(notifyworkspaces)-2) notifyworkspaces,
        sys.ltadm.AreThereConflicts(vt.owner, vt.table_name) conflict,
        sys.ltadm.AreThereDiffs(vt.owner, vt.table_name) diff
 from wmsys.wm$versioned_tables vt, all_tables at
 where vt.table_name = at.table_name and vt.owner = at.owner
WITH READ ONLY
/

