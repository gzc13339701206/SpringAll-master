create type       WM$NV_PAIR_NT_TYPE
                                                                       AS table of WMSYS.WM$NV_PAIR_TYPE ;
/

