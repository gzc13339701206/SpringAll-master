create view WM$VER_BEF_INST_NEXTVERS_VIEW as
select next_vers
         from wmsys.wm$nextver_table
         where version IN
           (SELECT parent_vers FROM wmsys.wm$ver_bef_inst_parvers_view)
WITH READ ONLY
/

