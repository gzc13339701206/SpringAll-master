create view WM$CURRENT_CHILD_NEXTVERS_VIEW as
  select nvt.next_vers
from wmsys.wm$nextver_table nvt, wmsys.wm$version_table vt
where
(
   nvt.workspace = vt.workspace and
   vt.anc_workspace = nvl(sys_context('lt_ctx','state'),'LIVE') and
   vt.anc_version  >= decode(sys_context('lt_ctx','version'),
                              null,(SELECT current_version
                                    FROM wmsys.wm$workspaces_table
                                    WHERE workspace = 'LIVE'),
                              -1,(select current_version
                                  from wmsys.wm$workspaces_table
                                  where workspace = sys_context('lt_ctx','state')),
                              sys_context('lt_ctx','version')
                          )
)
union all
select nvt.next_vers
from wmsys.wm$nextver_table nvt
where nvt.workspace = nvl(sys_context('lt_ctx','state'),'LIVE') and
      nvt.version > decode(sys_context('lt_ctx','version'),
                            null,(SELECT current_version
                                  FROM wmsys.wm$workspaces_table
                                  WHERE workspace = 'LIVE'),
                            -1,(select current_version
                                from wmsys.wm$workspaces_table
                                where workspace = sys_context('lt_ctx','state')),
                            sys_context('lt_ctx','version')
                          )
WITH READ ONLY
/

