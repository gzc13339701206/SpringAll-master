create view WM$DIFF1_HIERARCHY_VIEW as
select "VERSION","PARENT_VERSION","WORKSPACE" from wmsys.wm$version_hierarchy_table
  start with version =
             decode(sys_context('lt_ctx', 'diffver1'), -1,
             (select current_version from wmsys.wm$workspaces_table
              where workspace = sys_context('lt_ctx', 'diffWspc1')),
             sys_context('lt_ctx', 'diffver1'))
  connect by prior parent_version = version
WITH READ ONLY
/

