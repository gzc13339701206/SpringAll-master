create view WM$NET_DIFF1_HIERARCHY_VIEW as
  select version from wmsys.wm$diff1_hierarchy_view
            minus
            select version from wmsys.wm$base_hierarchy_view
WITH READ ONLY
/

