create view WM$DIFF2_HIERARCHY_VIEW as
select version from wmsys.wm$version_hierarchy_table
  start with version =
             decode(sys_context('lt_ctx', 'diffver2'), -1,
             (select current_version from wmsys.wm$workspaces_table
              where workspace = sys_context('lt_ctx', 'diffWspc2')),
             sys_context('lt_ctx', 'diffver2'))
  connect by prior parent_version  = version
WITH READ ONLY
/

