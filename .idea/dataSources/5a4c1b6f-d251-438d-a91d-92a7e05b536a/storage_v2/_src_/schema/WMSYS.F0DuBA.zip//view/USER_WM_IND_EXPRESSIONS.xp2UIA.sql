create view USER_WM_IND_EXPRESSIONS as
select /*+ ORDERED */ t2.index_name, t1.table_name, t2.column_expression, t2.column_position
from wmsys.wm$constraints_table t1, user_ind_expressions t2
where t1.index_owner = USER
and t1.index_name = t2.index_name
/

