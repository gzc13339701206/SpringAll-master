create view WM$TABLE_PARVERS_VIEW as
  (select table_name,version
          from wmsys.wm$modified_tables
          where workspace = nvl(sys_context('lt_ctx','state'),'LIVE') and
                version   <=
            decode(sys_context('lt_ctx','version'),
                   null,(SELECT current_version
                           FROM wmsys.wm$workspaces_table
                           WHERE workspace = 'LIVE'),
                   -1,(select current_version
                       from wmsys.wm$workspaces_table
                       where workspace = sys_context('lt_ctx','state')),
                   sys_context('lt_ctx','version')))
          union all
         (select table_name,vht.version
          from wmsys.wm$modified_tables vht, wmsys.wm$version_table vt
          where vt.workspace  = nvl(sys_context('lt_ctx','state'),'LIVE')  and
                vht.workspace = vt.anc_workspace and
                vht.version  <= vt.anc_version)
WITH READ ONLY
/

