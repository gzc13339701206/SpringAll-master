create view WM$BASE_HIERARCHY_VIEW as
  select -1 version from dual union all
  select version from wmsys.wm$version_hierarchy_table
  start with version = (select version from wmsys.wm$base_version_view)
  connect by prior parent_version  = version
WITH READ ONLY
/

