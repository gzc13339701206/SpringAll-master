create view USER_WM_CONSTRAINTS as
select /*+ ORDERED */
   constraint_name, constraint_type, table_name,
   search_condition, status, index_owner, index_name, index_type
  from   wmsys.wm$constraints_table ct, user_views uv
  where  ct.owner = USER and
         ct.table_name = uv.view_name
/

