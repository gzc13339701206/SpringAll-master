create view WM$PARCONFLICT_PARVERS_VIEW as
  (select version, vtid,  decode(sign(mt.version - wt.sync_parver), -1, 'NO','YES')
  from wmsys.wm$modified_tables mt, wmsys.wm$workspaces_table wt
  where mt.workspace = SYS_CONTEXT('lt_ctx','parent_conflict_state') and
        wt.workspace = SYS_CONTEXT('lt_ctx','conflict_state')
        and mt.version >= decode(sign(wt.parent_version - wt.sync_parver),-1,
                                 (wt.parent_version+1), sync_parver)
 )
WITH READ ONLY
/

