create view ALL_WM_LOCKED_TABLES as
select /*+ ORDERED */ t.table_owner, t.table_name, t.Lock_mode, t.Lock_owner, t.Locking_state
from wmsys.wm$all_locks_view t, all_views s
where t.table_owner = s.owner and t.table_name = s.view_name
with READ ONLY
/

