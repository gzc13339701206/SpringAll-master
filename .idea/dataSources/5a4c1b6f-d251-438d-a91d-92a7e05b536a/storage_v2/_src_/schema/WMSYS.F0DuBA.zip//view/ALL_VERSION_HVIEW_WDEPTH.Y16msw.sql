create view ALL_VERSION_HVIEW_WDEPTH as
SELECT vht.version, vht.parent_version, vht.workspace, wt.depth
FROM   wmsys.wm$version_hierarchy_table vht, wmsys.wm$workspaces_table wt
WHERE  vht.workspace = wt.workspace
/

