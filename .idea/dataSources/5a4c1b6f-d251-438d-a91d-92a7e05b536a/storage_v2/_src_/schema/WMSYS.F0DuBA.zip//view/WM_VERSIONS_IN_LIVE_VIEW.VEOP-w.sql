create view WM$VERSIONS_IN_LIVE_VIEW as
  (select version
              from wmsys.wm$version_hierarchy_table
              where workspace = 'LIVE')
WITH READ ONLY
/

