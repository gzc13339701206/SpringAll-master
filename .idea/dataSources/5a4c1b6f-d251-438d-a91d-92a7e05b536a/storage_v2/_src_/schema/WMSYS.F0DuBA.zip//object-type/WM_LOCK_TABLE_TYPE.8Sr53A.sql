create type       wm$lock_table_type
                                                                         as table of wmsys.wm$lock_info_type;
/

