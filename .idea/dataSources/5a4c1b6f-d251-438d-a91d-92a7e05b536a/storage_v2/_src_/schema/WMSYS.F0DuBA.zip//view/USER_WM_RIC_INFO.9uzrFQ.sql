create view USER_WM_RIC_INFO as
select ct_owner, ct_name, pt_owner, pt_name, ric_name,
         rtrim(ct_cols,','), rtrim(pt_cols,','),
         pt_unique_const_name, my_mode, status
  from   wmsys.wm$ric_table rt, user_views uv
  where  uv.view_name = rt.ct_name and
         rt.ct_owner = USER
/

