create view WM$TABLE_NEXTVERS_VIEW as
select /*+ INDEX(v1 WM$NEXTVER_TABLE_NV_INDX) USE_NL(v1 v2) */ v2.table_name, v1.next_vers
             from wmsys.wm$nextver_table v1,wmsys.wm$table_parvers_view v2
              where v1.version = v2.parent_vers
/

