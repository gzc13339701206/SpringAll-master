create view WM$PARENT_HIERARCHY_VIEW as
select "VERSION","PARENT_VERSION","WORKSPACE" from wmsys.wm$version_hierarchy_table
   where workspace = sys_context('lt_ctx','parent_state')
WITH READ ONLY
/

