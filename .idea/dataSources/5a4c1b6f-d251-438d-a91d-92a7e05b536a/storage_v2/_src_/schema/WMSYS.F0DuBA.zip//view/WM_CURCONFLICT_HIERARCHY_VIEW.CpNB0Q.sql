create view WM$CURCONFLICT_HIERARCHY_VIEW as
select "VERSION","PARENT_VERSION","WORKSPACE" from wmsys.wm$version_hierarchy_table
   where workspace = nvl(sys_context('lt_ctx','conflict_state'),'LIVE')
WITH READ ONLY
/

