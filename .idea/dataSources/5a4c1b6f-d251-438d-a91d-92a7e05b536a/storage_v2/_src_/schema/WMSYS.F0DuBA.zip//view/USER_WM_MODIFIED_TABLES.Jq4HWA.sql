create view USER_WM_MODIFIED_TABLES as
select table_name, workspace, savepoint
from
      (select distinct o.table_name, o.workspace,
              nvl(s.savepoint, 'LATEST') savepoint,
              min(s.is_implicit) imp, count(s.version) counter
      from wmsys.wm$modified_tables o, wmsys.wm$workspace_savepoints_table s
      where substr(o.table_name, 1, instr(table_name,'.')-1) = USER and
            o.version = s.version (+)
      group by o.table_name, o.workspace, savepoint)
where (imp = 0 or imp is null or counter = 1)
/

