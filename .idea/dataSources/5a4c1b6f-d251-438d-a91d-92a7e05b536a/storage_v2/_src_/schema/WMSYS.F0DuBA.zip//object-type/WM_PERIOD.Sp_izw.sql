create type       wm_period
                                                                                       as object
         (validfrom timestamp with time zone,validtill timestamp with time zone)
/

