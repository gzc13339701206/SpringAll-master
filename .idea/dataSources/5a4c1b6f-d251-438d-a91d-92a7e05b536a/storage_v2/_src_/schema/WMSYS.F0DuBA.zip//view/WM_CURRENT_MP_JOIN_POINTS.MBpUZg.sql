create view WM$CURRENT_MP_JOIN_POINTS as
select mpwst.mp_leaf_workspace,  vht.version
from   wmsys.wm$mp_graph_workspaces_table mpwst, wmsys.wm$workspaces_table wt, wmsys.wm$version_hierarchy_table vht
where  mpwst.mp_graph_workspace  = sys_context('lt_ctx','state')  and
       mpwst.mp_leaf_workspace   = wt.workspace                   and
       wt.workspace              = vht.workspace                  and
       wt.parent_version         = vht.parent_version
WITH READ ONLY
/

