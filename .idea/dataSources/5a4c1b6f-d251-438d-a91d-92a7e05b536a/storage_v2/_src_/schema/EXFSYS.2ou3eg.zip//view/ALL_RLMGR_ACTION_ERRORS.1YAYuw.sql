create view ALL_RLMGR_ACTION_ERRORS as
select rset_owner, rset_name, actschat, oraerrcde from rlm$schacterrs rs
  where
    rs.rset_owner = sys_context('USERENV', 'CURRENT_USER') or
    exists (select 1 from user_role_privs where granted_role = 'DBA') or
    ((rs.rset_owner, rs.rset_name) IN
     (select rsp.rset_owner, rsp.rset_name from rlm$rulesetprivs rsp
         where prv_grantee = sys_context('USERENV', 'CURRENT_USER')))
/

comment on table ALL_RLMGR_ACTION_ERRORS is 'Table listing the errors encountered during action execution'
/

comment on column ALL_RLMGR_ACTION_ERRORS.RULE_CLASS_OWNER is 'Owner of the rule class'
/

comment on column ALL_RLMGR_ACTION_ERRORS.RULE_CLASS_NAME is 'Name of the rule class producing the errors during action execution'
/

comment on column ALL_RLMGR_ACTION_ERRORS.SCHEDULED_TIME is 'Time at which the action was scheduled to run.'
/

comment on column ALL_RLMGR_ACTION_ERRORS.ORA_ERROR is 'Code for the error encountered : ORA-XXXXX'
/

