create view ALL_EXPFIL_ATTRIBUTES as
select atsowner, atsname, attrname, attrtype,
        decode (bitand(attrprop, 16), 16, attrtptab, null), attrdefvl
 from exf$attrlist, all_types ao where
   atsowner = ao.owner and atsname = ao.type_name
 order by atsowner, atsname, elattrid
/

comment on table ALL_EXPFIL_ATTRIBUTES is 'List of all the elementary attributes accessible to the user'
/

comment on column ALL_EXPFIL_ATTRIBUTES.OWNER is 'Owner of the attribute set'
/

comment on column ALL_EXPFIL_ATTRIBUTES.ATTRIBUTE_SET_NAME is 'Name of the attribute set this attribute belongs to'
/

comment on column ALL_EXPFIL_ATTRIBUTES.ATTRIBUTE is 'Name of the attribute'
/

comment on column ALL_EXPFIL_ATTRIBUTES.DATA_TYPE is 'Datatype of the attribute'
/

comment on column ALL_EXPFIL_ATTRIBUTES.ASSOCIATED_TABLE is 'Table associated with table alias attribute'
/

comment on column ALL_EXPFIL_ATTRIBUTES.DEFAULT_VALUE is 'String representation of the default value for the attribute'
/

