create package dbms_rlmgr authid current_user as

  procedure create_rule_class (
              rule_class     IN   VARCHAR2,   -- rule class name --
              event_struct   IN   VARCHAR2,   -- event structure (object) --
              action_cbk     IN   VARCHAR2,   -- action cbk procedure --
              actprf_spec    IN   VARCHAR2 default null,
              rslt_viewnm    IN   VARCHAR2 default null,
              rlcls_prop     IN   VARCHAR2 default null);

  procedure process_rules (
              rule_class     IN   VARCHAR2,
              event_inst     IN   VARCHAR2,
              event_type     IN   VARCHAR2 default null);

  procedure process_rules (
              rule_class     IN   VARCHAR2,
              event_inst     IN   sys.AnyData);

  procedure add_rule (
              rule_class     IN   VARCHAR2,
              rule_id        IN   VARCHAR2,
              rule_cond      IN   VARCHAR2,
              actprf_nml     IN   VARCHAR2 default null,
              actprf_vall    IN   VARCHAR2 default null);

  procedure delete_rule (
              rule_class     IN   VARCHAR2,
              rule_id        IN   VARCHAR2);

  procedure drop_rule_class (
              rule_class    IN   VARCHAR2);

  procedure grant_privilege (
              rule_class     IN   VARCHAR2,
              priv_type      IN   VARCHAR2,
              to_user        IN   VARCHAR2);

  procedure revoke_privilege (
              rule_class     IN   VARCHAR2,
              priv_type      IN   VARCHAR2,
              from_user      IN   VARCHAR2);

  --- APIs for obtaining results as a set --
  procedure add_event (
              rule_class     IN   VARCHAR2,
              event_inst     IN   VARCHAR2,
              event_type     IN   VARCHAR2 default null);

  procedure add_event (
              rule_class     IN   VARCHAR2,
              event_inst     IN   sys.AnyData);

  function consume_event (
              rule_class     IN   VARCHAR2,
              event_ident    IN   VARCHAR2) return number;

  function consume_prim_events (
              rule_class     IN   VARCHAR2,
              event_idents   IN   RLM$EVENTIDS) return number;


  procedure reset_session (
              rule_class     IN   VARCHAR2);

  --- event structure designing APIs ---
  procedure create_event_struct (
              event_struct   IN   VARCHAR2);

  procedure add_elementary_attribute (
              event_struct   IN   VARCHAR2,    --- event structure name
              attr_name      IN   VARCHAR2,    --- attr name
              attr_type      IN   VARCHAR2,    --- attr type
              attr_defvl     IN   VARCHAR2     --- default value for attr
                         default NULL);

  procedure add_elementary_attribute (
              event_struct   IN   VARCHAR2,    --- attr set name
              attr_name      IN   VARCHAR2,    --- table alias (name)
              tab_alias      IN   rlm$table_alias);  -- table alias for

  procedure add_functions (
              event_struct   IN   VARCHAR2,    --- attr set name
              funcs_name     IN   VARCHAR2);   --- function/package/type name

  procedure drop_event_struct (
              event_struct   IN   VARCHAR2);

end dbms_rlmgr;
/

