create view ALL_EXPFIL_EXPRSET_STATS as
select e.ESETOWNER, e.ESETTABLE, e.ESETCOLUMN, e.PREDLHS,
   (((NOEQPREDS+NOLTPREDS+NOGTPREDS+NOLTEQPRS+NOGTEQPRS+NONEQPRS+NOISNLPRS+
      NOISNNLPRS+NOBETPREDS+NONVLPREDS+NOLIKEPRS)*100)/EXSETNEXP),
   NOEQPREDS*100/EXSETNEXP, NOLTPREDS*100/EXSETNEXP, NOGTPREDS*100/EXSETNEXP,
   NOLTEQPRS*100/EXSETNEXP, NOGTEQPRS*100/EXSETNEXP, NONEQPRS*100/EXSETNEXP,
   NOISNLPRS*100/EXSETNEXP, NOISNNLPRS*100/EXSETNEXP, NOBETPREDS*
    100/EXSETNEXP, NONVLPREDS*100/EXSETNEXP,  NOLIKEPRS*100/EXSETNEXP
 from exf$expsetstats e, exf$exprset es, all_tables ao
 where e.esetowner = ao.owner and e.esettable = ao.table_name and
       e.esetowner = es.exsowner and e.esettable = es.exstabnm and
       e.esetcolumn = es.exscolnm
/

comment on table ALL_EXPFIL_EXPRSET_STATS is 'Predicate statistics for the expression sets in the current schema'
/

comment on column ALL_EXPFIL_EXPRSET_STATS.OWNER is 'Owner of the table storing expressions'
/

comment on column ALL_EXPFIL_EXPRSET_STATS.EXPR_TABLE is 'The table storing the expression set'
/

comment on column ALL_EXPFIL_EXPRSET_STATS.EXPR_COLUMN is 'The column storing the expression set'
/

comment on column ALL_EXPFIL_EXPRSET_STATS.ATTRIBUTE_EXP is 'Sub-expression representing the complex or elementary attribute. Also
 the left-hand-side of predicates'
/

comment on column ALL_EXPFIL_EXPRSET_STATS.PCT_OCCURRENCE is 'Percentage occurrence of the attribute in the expression set'
/

comment on column ALL_EXPFIL_EXPRSET_STATS.PCT_EQ_OPER is 'Percentage of predicates (of the attribute) with ''='' operator'
/

comment on column ALL_EXPFIL_EXPRSET_STATS.PCT_LT_OPER is 'Percentage of predicates (of the attribute) with ''<'' operator'
/

comment on column ALL_EXPFIL_EXPRSET_STATS.PCT_GT_OPER is 'Percentage of predicates (of the attribute) with ''>'' operator'
/

comment on column ALL_EXPFIL_EXPRSET_STATS.PCT_LTEQ_OPER is 'Percentage of predicates (of the attribute) with ''<='' operator'
/

comment on column ALL_EXPFIL_EXPRSET_STATS.PCT_GTEQ_OPER is 'Percentage of predicates (of the attribute) with ''>='' operator'
/

comment on column ALL_EXPFIL_EXPRSET_STATS.PCT_NEQ_OPER is 'Percentage of predicates (of the attribute) with ''!='' operator'
/

comment on column ALL_EXPFIL_EXPRSET_STATS.PCT_NUL_OPER is 'Percentage of predicates (of the attribute) with ''IS NULL'' operator'
/

comment on column ALL_EXPFIL_EXPRSET_STATS.PCT_NNUL_OPER is 'Percentage of predicates (of the attribute) with ''IS NOT NULL'' operator'
/

comment on column ALL_EXPFIL_EXPRSET_STATS.PCT_BETW_OPER is 'Percentage of predicates (of the attribute) with ''BETWEEN'' operator'
/

comment on column ALL_EXPFIL_EXPRSET_STATS.PCT_NVL_OPER is 'Percentage of predicates (of the attribute) with ''NVL'' operator'
/

comment on column ALL_EXPFIL_EXPRSET_STATS.PCT_LIKE_OPER is 'Percentage of predicates (of the attribute) with ''LIKE'' operator'
/

