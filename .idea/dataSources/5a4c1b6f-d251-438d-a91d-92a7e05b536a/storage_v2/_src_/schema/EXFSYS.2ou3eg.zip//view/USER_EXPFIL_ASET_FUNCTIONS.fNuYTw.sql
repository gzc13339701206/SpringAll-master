create view USER_EXPFIL_ASET_FUNCTIONS as
select udfasname, udfname, udfobjown, udfobjnm, udftype from
   exf$asudflist where udfasoner = (select user from dual)
/

comment on table USER_EXPFIL_ASET_FUNCTIONS is 'List of approved user-defined functions for the attribute sets'
/

comment on column USER_EXPFIL_ASET_FUNCTIONS.ATTRIBUTE_SET_NAME is 'Name of the attribute set'
/

comment on column USER_EXPFIL_ASET_FUNCTIONS.UDF_NAME is 'Name of the user-defined FUNCTION/PACKAGE/TYPE'
/

comment on column USER_EXPFIL_ASET_FUNCTIONS.OBJECT_OWNER is 'Owner of the object'
/

comment on column USER_EXPFIL_ASET_FUNCTIONS.OBJECT_NAME is 'Name of the object'
/

comment on column USER_EXPFIL_ASET_FUNCTIONS.OBJECT_TYPE is 'Type of the object - FUNCTION/PACKAGE/TYPE'
/

