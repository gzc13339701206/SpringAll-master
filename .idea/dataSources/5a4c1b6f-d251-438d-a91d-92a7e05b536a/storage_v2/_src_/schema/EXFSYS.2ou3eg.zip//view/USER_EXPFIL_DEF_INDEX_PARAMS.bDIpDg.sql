create view USER_EXPFIL_DEF_INDEX_PARAMS as
select atsname, attrsexp, attrtype,
         decode (bitand(attrprop, 1), 1, 'YES','NO'),
         decode (bitand(attrprop, 8), 8, 'YES','NO'),
         varray2str(attroper), xmltattr
  from exf$defidxparam
  where  atsowner = (select user from dual)
/

comment on table USER_EXPFIL_DEF_INDEX_PARAMS is 'List of all the stored attributes in the current schema'
/

comment on column USER_EXPFIL_DEF_INDEX_PARAMS.ATTRIBUTE_SET_NAME is 'Name of the attribute set this attribute belongs to'
/

comment on column USER_EXPFIL_DEF_INDEX_PARAMS.ATTRIBUTE is 'Name of the attribute'
/

comment on column USER_EXPFIL_DEF_INDEX_PARAMS.DATA_TYPE is 'Datatype of the attribute'
/

comment on column USER_EXPFIL_DEF_INDEX_PARAMS.ELEMENTARY is 'Field to indicate if the attribute is elementary'
/

comment on column USER_EXPFIL_DEF_INDEX_PARAMS.INDEXED is 'Field to indicate if the attribute is indexed in the predicate table'
/

comment on column USER_EXPFIL_DEF_INDEX_PARAMS.OPERATOR_LIST is 'List of common operators for the attribute'
/

comment on column USER_EXPFIL_DEF_INDEX_PARAMS.XMLTYPE_ATTR is 'The XMLType attribute for which the current XPath attribute is defined'
/

