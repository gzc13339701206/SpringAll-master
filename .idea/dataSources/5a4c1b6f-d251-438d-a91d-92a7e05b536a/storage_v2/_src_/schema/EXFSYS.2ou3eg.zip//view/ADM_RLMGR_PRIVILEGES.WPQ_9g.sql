create view ADM_RLMGR_PRIVILEGES as
select rset_owner, rset_name, prv_grantee, prv_prcrule, prv_addrule,
         prv_delrule
  from rlm$rulesetprivs
/

comment on table ADM_RLMGR_PRIVILEGES is 'Privileges for the Rule class'
/

comment on column ADM_RLMGR_PRIVILEGES.RULE_CLASS_OWNER is 'Owner of the rule class'
/

comment on column ADM_RLMGR_PRIVILEGES.RULE_CLASS_NAME is 'Name of the rule class'
/

comment on column ADM_RLMGR_PRIVILEGES.GRANTEE is 'Grantee of the privilege'
/

comment on column ADM_RLMGR_PRIVILEGES.PRCS_RULE_PRIV is 'Grantee''s privilege to execute/process rules'
/

comment on column ADM_RLMGR_PRIVILEGES.ADD_RULE_PRIV is 'Grantee''s privilege to add new rules to the rule class'
/

comment on column ADM_RLMGR_PRIVILEGES.DEL_RULE_PRIV is 'Grantee''s privilege to delete rules'
/

