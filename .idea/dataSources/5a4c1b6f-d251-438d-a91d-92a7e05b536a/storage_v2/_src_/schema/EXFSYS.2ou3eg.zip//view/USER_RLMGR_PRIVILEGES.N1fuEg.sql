create view USER_RLMGR_PRIVILEGES as
select rset_owner, rset_name, prv_grantee, prv_prcrule, prv_addrule,
         prv_delrule
  from rlm$rulesetprivs where  prv_grantee = 'PUBLIC' or
    prv_grantee = sys_context('USERENV', 'CURRENT_USER') or
    rset_owner = sys_context('USERENV', 'CURRENT_USER')
/

comment on table USER_RLMGR_PRIVILEGES is 'Privileges for the Rule classes'
/

comment on column USER_RLMGR_PRIVILEGES.RULE_CLASS_OWNER is 'Owner of the rule class'
/

comment on column USER_RLMGR_PRIVILEGES.RULE_CLASS_NAME is 'Name of the rule class'
/

comment on column USER_RLMGR_PRIVILEGES.GRANTEE is 'Grantee of the privilege. Current user of PUBLIC'
/

comment on column USER_RLMGR_PRIVILEGES.PRCS_RULE_PRIV is 'Current user''s privilege to execute/process rules'
/

comment on column USER_RLMGR_PRIVILEGES.ADD_RULE_PRIV is 'Current user''s privilege to add new rules to the rule class'
/

comment on column USER_RLMGR_PRIVILEGES.DEL_RULE_PRIV is 'Current user''s privilege to delete rules'
/

