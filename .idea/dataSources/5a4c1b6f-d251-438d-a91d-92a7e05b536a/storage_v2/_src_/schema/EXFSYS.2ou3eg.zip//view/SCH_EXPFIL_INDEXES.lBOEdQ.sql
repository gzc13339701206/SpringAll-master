create view SCH_EXPFIL_INDEXES as
select io.idxname, io.idxpredtab, io.idxaccfunc, io.idxattrset,
         io.idxesettab, idxesetcol, io.optfccpuct, io.optfcioct,
         io.optixselvt, io.optixcpuct, io.optixioct, io.optptfscct
  from exf$idxsecobj io
  where io.idxowner = SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA')
/

