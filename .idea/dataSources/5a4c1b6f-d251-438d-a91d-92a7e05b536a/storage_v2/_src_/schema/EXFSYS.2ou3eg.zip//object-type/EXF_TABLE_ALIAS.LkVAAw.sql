create type        exf$table_alias as object (
   table_name  VARCHAR2(70)
);
/

