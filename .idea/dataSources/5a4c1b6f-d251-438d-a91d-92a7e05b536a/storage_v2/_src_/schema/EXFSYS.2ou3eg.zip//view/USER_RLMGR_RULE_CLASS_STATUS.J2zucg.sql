create view USER_RLMGR_RULE_CLASS_STATUS as
select rs.rset_name, st.rset_stdesc, st.rset_stcode, st.rset_stnext
 from rlm$ruleset rs, rlm$rulesetstcode st where
    rs.rset_owner = sys_context('USERENV', 'CURRENT_USER') and
    rs.rset_status = st.rset_stcode
/

comment on table USER_RLMGR_RULE_CLASS_STATUS is 'View used to track the progress of rule class creation'
/

comment on column USER_RLMGR_RULE_CLASS_STATUS.RULE_CLASS_NAME is 'Name of the rule class'
/

comment on column USER_RLMGR_RULE_CLASS_STATUS.STATUS is 'Current status of the rule class'
/

comment on column USER_RLMGR_RULE_CLASS_STATUS.STATUS_CODE is 'Internal code for the status'
/

comment on column USER_RLMGR_RULE_CLASS_STATUS.NEXT_OPERATION is 'Next operation performed on the rule class'
/

