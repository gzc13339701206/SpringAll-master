create view RLM$INCRRSLTMAPS as
select /*+ nested_table_get_refs */ nested_table_id as incrrref,
                                      column_value as incrrrid
  from rlm$incrrrschact
/

