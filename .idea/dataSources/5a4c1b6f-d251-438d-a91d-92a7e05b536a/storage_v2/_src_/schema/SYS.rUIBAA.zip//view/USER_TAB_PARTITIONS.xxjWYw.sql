create view USER_TAB_PARTITIONS as
  select o.name, 'NO', o.subname, 0,
       tp.hiboundval, tp.hiboundlen, tp.part#, ts.name,
       tp.pctfree$,
       decode(bitand(ts.flags, 32), 32, to_number(NULL), tp.pctused$),
       tp.initrans, tp.maxtrans, s.iniexts * ts.blocksize,
       decode(bitand(ts.flags, 3), 1, to_number(NULL),
                               s.extsize * ts.blocksize),
       s.minexts, s.maxexts,
       decode(bitand(ts.flags, 3), 1, to_number(NULL),
                                      s.extpct),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
          decode(s.lists, 0, 1, s.lists)),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
          decode(s.groups, 0, 1, s.groups)),
       decode(mod(trunc(tp.flags / 4), 2), 0, 'YES', 'NO'),
       decode(bitand(s.spare1, 2048), 2048, 'ENABLED', 'DISABLED'),
       tp.rowcnt, tp.blkcnt, tp.empcnt, tp.avgspc, tp.chncnt, tp.avgrln,
       tp.samplesize, tp.analyzetime,
       decode(s.cachehint, 0, 'DEFAULT', 1, 'KEEP', 2, 'RECYCLE', NULL),
       decode(bitand(tp.flags, 16), 0, 'NO', 'YES'),
       decode(bitand(tp.flags, 8), 0, 'NO', 'YES')
from   obj$ o, tabpartv$ tp, ts$ ts, sys.seg$ s, sys.tab$ t
where  o.obj# = tp.obj# and ts.ts# = tp.ts# and
       tp.file#=s.file# and tp.block#=s.block# and tp.ts#=s.ts# and
       tp.bo# = t.obj# and bitand(t.trigflag, 1073741824) != 1073741824 and
       o.owner# = userenv('SCHEMAID')
       and o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
union all -- IOT PARTITIONS
select o.name, 'NO', o.subname, 0,
       tp.hiboundval, tp.hiboundlen, tp.part#, NULL,
       TO_NUMBER(NULL),TO_NUMBER(NULL),TO_NUMBER(NULL),TO_NUMBER(NULL),
       TO_NUMBER(NULL),
       TO_NUMBER(NULL),TO_NUMBER(NULL),TO_NUMBER(NULL),TO_NUMBER(NULL),
       TO_NUMBER(NULL),TO_NUMBER(NULL),
       NULL,
       'N/A',
       tp.rowcnt, TO_NUMBER(NULL), TO_NUMBER(NULL), 0, tp.chncnt, tp.avgrln,
       tp.samplesize, tp.analyzetime, NULL,
       decode(bitand(tp.flags, 16), 0, 'NO', 'YES'),
       decode(bitand(tp.flags, 8), 0, 'NO', 'YES')
from   obj$ o, tabpartv$ tp, tab$ t
where  o.obj# = tp.obj# and tp.file#=0 and tp.block#=0 and
       tp.bo# = t.obj# and bitand(t.trigflag, 1073741824) != 1073741824 and
       o.owner# = userenv('SCHEMAID')
       and o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
union all -- COMPOSITE PARTITIONS
select o.name, 'YES', o.subname, tcp.subpartcnt,
       tcp.hiboundval, tcp.hiboundlen, tcp.part#, ts.name,
       tcp.defpctfree,
       decode(bitand(ts.flags, 32), 32, to_number(NULL), tcp.defpctused),
       tcp.definitrans, tcp.defmaxtrans,
       tcp.definiexts, tcp.defextsize, tcp.defminexts, tcp.defmaxexts,
       tcp.defextpct,
       decode(bitand(ts.flags, 32), 32, to_number(NULL), tcp.deflists),
       decode(bitand(ts.flags, 32), 32,  to_number(NULL),tcp.defgroups),
       decode(tcp.deflogging, 0, 'NONE', 1, 'YES', 2, 'NO', 'UNKNOWN'),
       decode(mod(tcp.spare2,256), 0, 'NONE', 1, 'ENABLED', 2, 'DISABLED',
                                      'UNKNOWN'),
       tcp.rowcnt, tcp.blkcnt, tcp.empcnt, tcp.avgspc, tcp.chncnt, tcp.avgrln,
       tcp.samplesize, tcp.analyzetime,
       decode(tcp.defbufpool, 0, 'DEFAULT', 1, 'KEEP', 2, 'RECYCLE', NULL),
       decode(bitand(tcp.flags, 16), 0, 'NO', 'YES'),
       decode(bitand(tcp.flags, 8), 0, 'NO', 'YES')
from   obj$ o, tabcompartv$ tcp, ts$ ts, tab$ t
where  o.obj# = tcp.obj# and tcp.defts# = ts.ts# and
       o.owner# = userenv('SCHEMAID') and
       o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL and
       tcp.bo# = t.obj#
       and bitand(t.trigflag, 1073741824) != 1073741824
/

