create view EXU8POKIU as
SELECT  "OBJID","OWNERID","POSNO","NAME","PROPERTY","FUNCTION","FUNCLEN"
        FROM    sys.exu8poki
        WHERE   ownerid = UID
/

