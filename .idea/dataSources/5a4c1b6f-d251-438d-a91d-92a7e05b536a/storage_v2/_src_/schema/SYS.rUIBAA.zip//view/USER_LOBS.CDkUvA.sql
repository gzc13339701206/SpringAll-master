create view USER_LOBS as
  select o.name,
       decode(bitand(c.property, 1), 1, ac.name, c.name),
       lo.name,
       decode(bitand(l.property, 8), 8, ts1.name, ts.name), io.name,
       l.chunk * decode(bitand(l.property, 8), 8, ts1.blocksize,
                        ts.blocksize),
       decode(bitand(l.flags, 32), 0, l.pctversion$, to_number(NULL)),
       decode(bitand(l.flags, 32), 32, l.retention, to_number(NULL)),
       decode(l.freepools, 0, to_number(NULL), 65534, to_number(NULL),
              65535, to_number(NULL), l.freepools),
       decode(bitand(l.flags, 27), 1, 'NO', 2, 'NO', 8, 'CACHEREADS',
                                   16, 'CACHEREADS', 'YES'),
       decode(bitand(l.flags, 18), 2, 'NO', 16, 'NO', 'YES'),
       decode(bitand(l.property, 2), 2, 'YES', 'NO'),
       decode(c.type#, 113, 'NOT APPLICABLE ',
              decode(bitand(l.property, 512), 512,
                     'ENDIAN SPECIFIC', 'ENDIAN NEUTRAL ')),
       decode(bitand(ta.property, 32), 32, 'YES', 'NO')
from sys.obj$ o, sys.col$ c, sys.attrcol$ ac, sys.lob$ l, sys.obj$ lo,
     sys.obj$ io, sys.ts$ ts, sys.tab$ ta, sys.user$ ut, sys.ts$ ts1
where o.owner# = userenv('SCHEMAID')
  and o.obj# = c.obj#
  and c.obj# = l.obj#
  and c.intcol# = l.intcol#
  and l.lobj# = lo.obj#
  and l.ind# = io.obj#
  and l.ts# = ts.ts#(+)
  and o.owner# = ut.user#
  and ut.tempts# = ts1.ts#
  and c.obj# = ac.obj#(+)
  and c.intcol# = ac.intcol#(+)
  and bitand(c.property,32768) != 32768           /* not unused column */
  and o.obj# = ta.obj#
  and bitand(ta.property, 32) != 32           /* not partitioned table */
union all
select o.name,
       decode(bitand(c.property, 1), 1, ac.name, c.name),
       lo.name,
       NVL(ts1.name,
        (select ts2.name
        from    ts$ ts2, partobj$ po
        where   o.obj# = po.obj# and po.defts# = ts2.ts#)),
       io.name,
       plob.defchunk * NVL(ts1.blocksize, NVL((
        select ts2.blocksize
        from   sys.ts$ ts2, sys.lobfrag$ lf
        where  l.lobj# = lf.parentobj# and
               lf.ts# = ts2.ts# and rownum < 2),
        (select ts2.blocksize
        from   sys.ts$ ts2, sys.lobcomppart$ lcp, sys.lobfrag$ lf
        where  l.lobj# = lcp.lobj# and lcp.partobj# = lf.parentobj# and
               lf.ts# = ts2.ts# and rownum < 2))),
       decode(plob.defpctver$, 101, to_number(NULL), 102, to_number(NULL),
                                   plob.defpctver$),
       decode(l.retention, -1, to_number(NULL), l.retention),
       decode(l.freepools, 0, to_number(NULL), 65534, to_number(NULL),
              65535, to_number(NULL), l.freepools),
       decode(bitand(plob.defflags, 27), 1, 'NO', 2, 'NO', 8, 'CACHEREADS',
                                         16, 'CACHEREADS', 'YES'),
       decode(bitand(plob.defflags,22), 0,'NONE', 4,'YES', 2,'NO',
                                        16,'NO', 'UNKNOWN'),
       decode(bitand(plob.defpro, 2), 2, 'YES', 'NO'),
       decode(c.type#, 113, 'NOT APPLICABLE ',
              decode(bitand(l.property, 512), 512,
                     'ENDIAN SPECIFIC', 'ENDIAN NEUTRAL ')),
       decode(bitand(ta.property, 32), 32, 'YES', 'NO')
from sys.obj$ o, sys.col$ c, sys.attrcol$ ac, sys.partlob$ plob,
     sys.lob$ l, sys.obj$ lo, sys.obj$ io, sys.ts$ ts1, sys.tab$ ta
where o.owner# = userenv('SCHEMAID')
  and o.obj# = c.obj#
  and c.obj# = l.obj#
  and c.intcol# = l.intcol#
  and l.lobj# = lo.obj#
  and l.ind# = io.obj#
  and l.lobj# = plob.lobj#
  and plob.defts# = ts1.ts# (+)
  and c.obj# = ac.obj#(+)
  and c.intcol# = ac.intcol#(+)
  and bitand(c.property,32768) != 32768           /* not unused column */
  and o.obj# = ta.obj#
  and bitand(ta.property, 32) = 32                /* partitioned table */

comment on table USER_LOBS is 'Description of the user''s own LOBs contained in the user''s own tables'
/

comment on column USER_LOBS.TABLE_NAME is 'Name of the table containing the LOB'
/

comment on column USER_LOBS.COLUMN_NAME is 'Name of the LOB column or attribute'
/

comment on column USER_LOBS.SEGMENT_NAME is 'Name of the LOB segment'
/

comment on column USER_LOBS.TABLESPACE_NAME is 'Name of the tablespace containing the LOB segment'
/

comment on column USER_LOBS.INDEX_NAME is 'Name of the LOB index'
/

comment on column USER_LOBS.CHUNK is 'Size of the LOB chunk as a unit of allocation/manipulation in bytes'
/

comment on column USER_LOBS.PCTVERSION is 'Maximum percentage of the LOB space used for versioning'
/

comment on column USER_LOBS.RETENTION is 'Maximum time duration for versioning of the LOB space'
/

comment on column USER_LOBS.FREEPOOLS is 'Number of freepools for this LOB segment'
/

comment on column USER_LOBS.CACHE is 'Is the LOB accessed through the buffer cache?'
/

comment on column USER_LOBS.LOGGING is 'Are changes to the LOB logged?'
/

comment on column USER_LOBS.IN_ROW is 'Are some of the LOBs stored with the base row?'
/

comment on column USER_LOBS.FORMAT is 'Is the LOB storage format dependent on the endianness of the platform?'
/

comment on column USER_LOBS.PARTITIONED is 'Is the LOB column in a partitioned table?'
/

