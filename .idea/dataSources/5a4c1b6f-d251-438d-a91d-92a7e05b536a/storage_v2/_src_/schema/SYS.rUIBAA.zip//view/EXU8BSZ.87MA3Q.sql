create view EXU8BSZ as
SELECT  ts$.blocksize
        FROM    sys.ts$ ts$
/

