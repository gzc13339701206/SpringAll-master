create view SESSION_PRIVS as
select spm.name
from sys.v$enabledprivs ep, system_privilege_map spm
where spm.privilege = ep.priv_number
/

comment on table SESSION_PRIVS is 'Privileges which the user currently has set'
/

comment on column SESSION_PRIVS.PRIVILEGE is 'Privilege Name'
/

