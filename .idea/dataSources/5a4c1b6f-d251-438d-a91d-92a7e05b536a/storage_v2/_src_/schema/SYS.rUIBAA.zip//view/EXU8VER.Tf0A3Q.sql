create view EXU8VER as
SELECT  TO_NUMBER(value$)
        FROM    sys.props$
        WHERE   name = 'EXPORT_VIEWS_VERSION'
/

