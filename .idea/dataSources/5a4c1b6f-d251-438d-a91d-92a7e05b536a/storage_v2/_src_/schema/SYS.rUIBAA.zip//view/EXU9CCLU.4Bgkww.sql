create view EXU9CCLU as
SELECT  "OWNERID","OWNERNAME","CNO","COLNAME","COLNO","INTCOL","PROPERTY"
        FROM    sys.exu9ccl
        WHERE   UID = ownerid
/

