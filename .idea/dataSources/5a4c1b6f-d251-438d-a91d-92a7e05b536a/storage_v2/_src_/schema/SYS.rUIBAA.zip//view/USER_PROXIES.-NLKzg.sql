create view USER_PROXIES as
select u.name,
       decode(p.credential_type#, 0, 'NO',
                                  5, 'YES'),
       decode(p.flags, 0, null,
                       1, 'PROXY MAY ACTIVATE ALL CLIENT ROLES',
                       2, 'NO CLIENT ROLES MAY BE ACTIVATED',
                       4, 'PROXY MAY ACTIVATE ROLE',
                       5, 'PROXY MAY ACTIVATE ALL CLIENT ROLES',
                       8, 'PROXY MAY NOT ACTIVATE ROLE'),
       (select u.name from sys.user$ u where pr.role# = u.user#)
from sys.user$ u, sys.proxy_info$ p, sys.proxy_role_info$ pr
where u.user#  = p.client#
  and p.proxy#  = pr.proxy#(+)
  and p.client# = pr.client#(+)
  and p.proxy# = userenv('SCHEMAID')
/

comment on table USER_PROXIES is 'Description of connections the user is allowed to proxy'
/

comment on column USER_PROXIES.CLIENT is 'Name of the client user who the proxy user can act on behalf of'
/

comment on column USER_PROXIES.AUTHENTICATION is 'Indicates whether proxy is required to supply client''s authentication credentials'
/

comment on column USER_PROXIES.AUTHORIZATION_CONSTRAINT is 'Indicates the proxy''s authority to exercise roles on client''s behalf'
/

comment on column USER_PROXIES.ROLE is 'Name of the role referenced in authorization constraint'
/

