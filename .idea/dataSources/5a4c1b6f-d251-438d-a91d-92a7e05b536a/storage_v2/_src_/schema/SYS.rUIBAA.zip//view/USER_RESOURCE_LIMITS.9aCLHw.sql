create view USER_RESOURCE_LIMITS as
select m.name,
          decode (u.limit#, 2147483647, 'UNLIMITED',
                           0, decode (p.limit#, 2147483647, 'UNLIMITED',
                                               p.limit#),
                           u.limit#)
  from sys.profile$ u, sys.profile$ p,
       sys.resource_map m, user$ s
  where u.resource# = m.resource#
  and p.profile# = 0
  and p.resource# = u.resource#
  and u.type# = p.type#
  and p.type# = 0
  and m.type# = 0
  and s.resource$ = u.profile#
  and s.user# = userenv('SCHEMAID')
/

comment on table USER_RESOURCE_LIMITS is 'Display resource limit of the user'
/

comment on column USER_RESOURCE_LIMITS.RESOURCE_NAME is 'Resource name'
/

comment on column USER_RESOURCE_LIMITS.LIMIT is 'Limit placed on this resource'
/

