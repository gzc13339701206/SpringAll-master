create view GV_$NLS_VALID_VALUES as
select "INST_ID","PARAMETER","VALUE","ISDEPRECATED" from gv$nls_valid_values
/

