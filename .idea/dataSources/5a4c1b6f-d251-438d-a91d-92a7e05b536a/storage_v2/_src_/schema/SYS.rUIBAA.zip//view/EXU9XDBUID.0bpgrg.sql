create view EXU9XDBUID as
SELECT r$.schema#
        FROM sys.registry$ r$
        WHERE r$.cid = 'XDB'
/

