create view EXU9GSAS as
SELECT  value
        FROM    sys.v$parameter
        WHERE   name = 'sort_area_size'
/

