create view EXU9OTNNULL as
SELECT  tobjid, name, conname, defer
  FROM    sys.exu8col_temp
  WHERE   isnull = 1 AND
          BITAND(colprop, 32) != 32       /* Not hidden (exploded col/attrs) */

