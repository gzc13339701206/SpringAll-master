create view ALL_SUBSCRIBED_COLUMNS as
SELECT
   sc.handle, t.source_schema_name, t.source_table_name, sc.column_name,
   s.subscription_name
  FROM sys.cdc_subscribed_columns$ sc, sys.cdc_change_tables$ t,
       sys.cdc_subscribers$ s
  WHERE sc.change_table_obj#=t.obj# AND
        s.handle = sc.handle
/

comment on table ALL_SUBSCRIBED_COLUMNS is 'Change Data Capture subscribed columns'
/

comment on column ALL_SUBSCRIBED_COLUMNS.HANDLE is 'Unique identifier of the subscription'
/

comment on column ALL_SUBSCRIBED_COLUMNS.SOURCE_SCHEMA_NAME is 'Source schema name of the subscribed column'
/

comment on column ALL_SUBSCRIBED_COLUMNS.SOURCE_TABLE_NAME is 'Source table name of the subscribed column'
/

comment on column ALL_SUBSCRIBED_COLUMNS.COLUMN_NAME is 'Name of the subscribed column'
/

comment on column ALL_SUBSCRIBED_COLUMNS.SUBSCRIPTION_NAME is 'Name of the subscription'
/

