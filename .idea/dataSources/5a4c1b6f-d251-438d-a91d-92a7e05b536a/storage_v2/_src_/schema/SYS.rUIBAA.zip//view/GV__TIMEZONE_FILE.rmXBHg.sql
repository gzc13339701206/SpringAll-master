create view GV_$TIMEZONE_FILE as
select "FILENAME","VERSION" from gv$timezone_file
/

