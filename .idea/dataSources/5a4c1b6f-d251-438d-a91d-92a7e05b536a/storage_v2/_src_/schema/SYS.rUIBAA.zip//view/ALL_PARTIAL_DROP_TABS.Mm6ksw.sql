create view ALL_PARTIAL_DROP_TABS as
select u.name, o.name
from sys.user$ u, sys.obj$ o, sys.tab$ t
where o.owner# = u.user#
  and o.obj# = t.obj#
  and bitand(t.flags,32768) = 32768
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or exists (select null from v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */)
                 )
      )
  group by u.name, o.name
/

comment on table ALL_PARTIAL_DROP_TABS is 'All tables with patially dropped columns accessible to the user'
/

comment on column ALL_PARTIAL_DROP_TABS.OWNER is 'Owner of the table'
/

comment on column ALL_PARTIAL_DROP_TABS.TABLE_NAME is 'Name of the table'
/

