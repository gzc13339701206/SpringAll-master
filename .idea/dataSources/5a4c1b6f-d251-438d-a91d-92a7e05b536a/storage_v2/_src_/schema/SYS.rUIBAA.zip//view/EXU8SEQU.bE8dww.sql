create view EXU8SEQU as
SELECT  "OWNER","OWNERID","NAME","OBJID","CURVAL","MINVAL","MAXVAL","INCR","CACHE","CYCLE","ORDER$","AUDT"
        FROM    sys.exu8seq
        WHERE   UID = ownerid
/

