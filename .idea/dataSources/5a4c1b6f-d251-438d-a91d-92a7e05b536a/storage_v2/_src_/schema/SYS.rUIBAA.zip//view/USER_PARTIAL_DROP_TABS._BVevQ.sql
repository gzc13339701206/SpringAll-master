create view USER_PARTIAL_DROP_TABS as
select o.name from sys.tab$ t, sys.obj$ o
where o.obj# = t.obj#
  and o.owner# = userenv('SCHEMAID')
  and bitand(t.flags, 32768) = 32768
/

comment on table USER_PARTIAL_DROP_TABS is 'User tables with unused columns'
/

comment on column USER_PARTIAL_DROP_TABS.TABLE_NAME is 'Name of the table'
/

