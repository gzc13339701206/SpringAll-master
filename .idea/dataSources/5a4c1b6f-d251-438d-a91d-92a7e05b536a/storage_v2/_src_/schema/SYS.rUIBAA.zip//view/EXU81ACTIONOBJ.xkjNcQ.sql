create view EXU81ACTIONOBJ as
SELECT  oa.name, oa.objid, oa.owner, oa.ownerid, oa.property,
                oa.type#, oa.level#, oa.package, oa.pkg_schema
        FROM    sys.exu9actionobj oa
        WHERE   oa.class = 3
/

