create view EXU8TYPBU as
SELECT  "TNAME","TOWNER","TOWNERID","OBJNO","SQLVER"
        FROM    sys.exu8typb
        WHERE   townerid = UID
/

