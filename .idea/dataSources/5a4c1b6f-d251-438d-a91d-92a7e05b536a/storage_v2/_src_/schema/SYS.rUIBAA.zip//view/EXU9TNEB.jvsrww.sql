create view EXU9TNEB as
SELECT  ktfbuesegtsn, ktfbuesegfno, ktfbuesegbno, ktfbueblks
        FROM    sys.x$ktfbue
        WHERE   ktfbueextno = 1
/

