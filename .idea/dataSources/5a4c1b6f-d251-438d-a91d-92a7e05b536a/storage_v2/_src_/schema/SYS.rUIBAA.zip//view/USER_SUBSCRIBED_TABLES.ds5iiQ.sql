create view USER_SUBSCRIBED_TABLES as
SELECT
   s.handle, t.source_schema_name, t.source_table_name, s.view_name,
   t.change_set_name, u.subscription_name
  FROM sys.cdc_subscribed_tables$ s, sys.cdc_change_tables$ t,
       sys.cdc_subscribers$ u, sys.user$ su
  WHERE s.change_table_obj#=t.obj# AND
        s.handle=u.handle AND
        u.username= su.name AND
        su.user#= USERENV('SCHEMAID')
/

comment on table USER_SUBSCRIBED_TABLES is 'Change Data Capture subscribed tables'
/

comment on column USER_SUBSCRIBED_TABLES.HANDLE is 'Unique identifier of the subscription'
/

comment on column USER_SUBSCRIBED_TABLES.SOURCE_SCHEMA_NAME is 'Source schema name of the subscribed table'
/

comment on column USER_SUBSCRIBED_TABLES.SOURCE_TABLE_NAME is 'Source table name of the subscribed table'
/

comment on column USER_SUBSCRIBED_TABLES.VIEW_NAME is 'Subscriber view name for the subscribed table'
/

comment on column USER_SUBSCRIBED_TABLES.CHANGE_SET_NAME is 'Change set name for the subscribed table'
/

comment on column USER_SUBSCRIBED_TABLES.SUBSCRIPTION_NAME is 'Name of the subscription'
/

