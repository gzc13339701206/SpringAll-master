create view IMP8CDTU as
SELECT  "OWNERID","BAD"
        FROM    sys.imp8cdt
        WHERE   ownerid = UID
/

