create view EXU8GLOB as
SELECT  value$
        FROM    sys.props$
        WHERE   name = 'GLOBAL_DB_NAME'
/

