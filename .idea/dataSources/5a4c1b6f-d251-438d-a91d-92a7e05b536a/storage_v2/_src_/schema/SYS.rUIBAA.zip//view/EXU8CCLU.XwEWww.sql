create view EXU8CCLU as
SELECT  "OWNERID","OWNERNAME","CNO","COLNAME","COLNO","INTCOL","PROPERTY"
        FROM    sys.exu8ccl
        WHERE   UID = ownerid
/

