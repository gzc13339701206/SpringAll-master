create view V_$OPTION as
select "PARAMETER","VALUE" from v$option
/

