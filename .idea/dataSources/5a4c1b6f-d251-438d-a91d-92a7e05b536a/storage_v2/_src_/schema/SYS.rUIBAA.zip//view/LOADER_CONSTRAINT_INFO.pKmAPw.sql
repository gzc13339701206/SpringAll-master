create view LOADER_CONSTRAINT_INFO as
select /*+ ordered index (cd i_cdef2) */
       u.name, con.name, cd.con#, cd.type#,o.name, cd.enabled,nvl(cd.defer,0)
   from sys.user$ u, sys.obj$ o, sys.cdef$ cd, sys.con$ con
   where   o.owner# = u.user#
   and    cd.obj#   = o.obj#
   and   con.con#   = cd.con#
   and (o.owner# = userenv('schemaid')
         or o.obj# in
              (select oa.obj#
               from sys.objauth$ oa
               where grantee# in ( select kzsrorol
                                   from x$kzsro
                                 )
              )
         or /* user has system privileges */
            exists (select null from v$enabledprivs
                    where priv_number in (-45 /* LOCK   ANY TABLE */,
                                          -47 /* SELECT ANY TABLE */,
                                          -48 /* INSERT ANY TABLE */,
                                          -49 /* UPDATE ANY TABLE */,
                                          -50 /* DELETE ANY TABLE */)
                    )
        )
/

