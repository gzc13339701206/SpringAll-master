create view EXU8HSTU as
SELECT  "POBJID","TOWNERID","INTCOL","BUCKET","ENDPTHASH","ENDPTVAL"
        FROM    sys.exu8hst
        WHERE   townerid = UID
/

