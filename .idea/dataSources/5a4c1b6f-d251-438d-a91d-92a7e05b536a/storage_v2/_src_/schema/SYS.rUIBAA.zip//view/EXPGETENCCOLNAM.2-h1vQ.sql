create view EXPGETENCCOLNAM as
SELECT c.name, c.obj#
        FROM   sys.col$ c, sys.obj$ o
        WHERE  bitand(c.property,67108864) = 67108864 AND /* encrypted column */
               c.obj#  = o.obj#                       AND
               (UID IN (o.owner#, 0) OR
                 EXISTS (
                    SELECT  role
                    FROM    sys.session_roles
                    WHERE   role = 'SELECT_CATALOG_ROLE'))
/

