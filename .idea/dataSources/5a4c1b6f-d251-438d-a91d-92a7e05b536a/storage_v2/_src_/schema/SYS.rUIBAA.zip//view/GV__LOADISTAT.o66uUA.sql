create view GV_$LOADISTAT as
select "INST_ID","OWNER","TABNAME","INDEXNAME","SUBNAME","MESSAGE_NUM","MESSAGE" from gv$loadistat
/

