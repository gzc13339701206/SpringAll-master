create view GV_$RSRC_PLAN_CPU_MTH as
select "INST_ID","NAME" from gv$rsrc_plan_cpu_mth
/

