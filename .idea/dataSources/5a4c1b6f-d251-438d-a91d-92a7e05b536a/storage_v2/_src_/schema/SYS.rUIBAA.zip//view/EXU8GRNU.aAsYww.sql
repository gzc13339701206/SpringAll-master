create view EXU8GRNU as
SELECT  "OBJID","GRANTOR","GRANTORID","GRANTEE","PRIV","WHO","WGO","CREATORID","SEQUENCE","ISDIR","TYPE"
        FROM    sys.exu8grn
        WHERE   grantorid = UID AND
                creatorid = UID
/

