create view EXU8DIM as
SELECT  o.owner#, u.name, o.name, dm.dimtext
        FROM    sys.obj$ o, sys.user$ u, sys.dim$ dm
        WHERE   u.user# = o.owner# AND
                dm.obj# = o.obj# AND
                (UID IN (0, o.owner#) OR
                 EXISTS (
                    SELECT  role
                    FROM    sys.session_roles
                    WHERE   role = 'SELECT_CATALOG_ROLE'))
/

