create view EXPEXEMPT as
SELECT  COUNT(*)
        FROM    sys.sysauth$
        WHERE   (privilege# =
                        (SELECT privilege
                         FROM   sys.system_privilege_map
                         WHERE  name = 'EXEMPT ACCESS POLICY'))
        AND     grantee# = UID   /* user directly has priv */
        OR      (grantee# = UID   /* user has role with priv */
                        AND privilege# > 0
                        AND privilege# IN
                                (SELECT u1.privilege#
                                 FROM sys.sysauth$ u1, sys.sysauth$ u2
                                 WHERE u1.grantee# = UID
                                 AND u1.privilege# = u2.grantee#
                                 AND u2.privilege# =
                                      (SELECT privilege
                                       FROM   sys.system_privilege_map
                                       WHERE  name = 'EXEMPT ACCESS POLICY')))
/

