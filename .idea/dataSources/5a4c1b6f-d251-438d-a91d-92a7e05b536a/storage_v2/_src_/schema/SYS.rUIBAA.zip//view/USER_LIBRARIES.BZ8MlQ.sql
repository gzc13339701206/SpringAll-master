create view USER_LIBRARIES as
select o.name,
       l.filespec,
       decode(bitand(l.property, 1), 0, 'Y', 1, 'N', NULL),
       decode(o.status, 0, 'N/A', 1, 'VALID', 'INVALID')
from sys.obj$ o, sys.library$ l
where o.owner# = userenv('SCHEMAID')
  and o.obj# = l.obj#
/

comment on table USER_LIBRARIES is 'Description of the user''s own libraries'
/

comment on column USER_LIBRARIES.LIBRARY_NAME is 'Name of the library'
/

comment on column USER_LIBRARIES.FILE_SPEC is 'Operating system file specification of the library'
/

comment on column USER_LIBRARIES.DYNAMIC is 'Is the library dynamically loadable'
/

comment on column USER_LIBRARIES.STATUS is 'Status of the library'
/

