create view IMP9COMPAT as
SELECT  value
        FROM    v$parameter
        WHERE   name = 'compatible'
/

