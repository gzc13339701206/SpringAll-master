create view EXU8CMTU as
SELECT  "USERID","OBJID","COLNO","COLNAME","CMNT"
        FROM    sys.exu8cmt
        WHERE   userid = UID
/

