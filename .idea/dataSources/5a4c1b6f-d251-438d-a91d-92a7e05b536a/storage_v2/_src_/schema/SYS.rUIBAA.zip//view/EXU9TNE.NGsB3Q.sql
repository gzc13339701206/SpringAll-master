create view EXU9TNE as
SELECT  ts#, segfile#, segblock#, length
        FROM    sys.uet$
        WHERE   ext# = 1
/

