create view USER_SUBSCRIBED_COLUMNS as
SELECT
   s.handle, t.source_schema_name, t.source_table_name, s.column_name,
   u.subscription_name
  FROM sys.cdc_subscribed_columns$ s, sys.cdc_change_tables$ t,
       sys.cdc_subscribers$ u, sys.user$ su
  WHERE s.change_table_obj#=t.obj# AND
        s.handle=u.handle AND
        u.username = su.name AND
        su.user#   = userenv('SCHEMAID')
/

comment on table USER_SUBSCRIBED_COLUMNS is 'Change Data Capture subscribed columns'
/

comment on column USER_SUBSCRIBED_COLUMNS.HANDLE is 'Unique identifier of the subscription'
/

comment on column USER_SUBSCRIBED_COLUMNS.SOURCE_SCHEMA_NAME is 'Source schema name of the subscribed column'
/

comment on column USER_SUBSCRIBED_COLUMNS.SOURCE_TABLE_NAME is 'Source table name of the subscribed column'
/

comment on column USER_SUBSCRIBED_COLUMNS.COLUMN_NAME is 'Name of the subscribed column'
/

comment on column USER_SUBSCRIBED_COLUMNS.SUBSCRIPTION_NAME is 'Name of the subscription'
/

