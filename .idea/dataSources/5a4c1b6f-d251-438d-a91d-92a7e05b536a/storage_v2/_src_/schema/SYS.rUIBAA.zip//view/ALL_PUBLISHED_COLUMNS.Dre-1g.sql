create view ALL_PUBLISHED_COLUMNS as
SELECT
   s.change_set_name, s.obj#, s.source_schema_name, s.source_table_name,
   c.column_name, c.data_type, c.data_length, c.data_precision, c.data_scale,
   c.nullable
  FROM sys.cdc_change_tables$ s, all_tables t, all_tab_columns c
  WHERE s.change_table_schema=t.owner AND
        s.change_table_name=t.table_name AND
        c.owner=s.change_table_schema AND
        c.table_name=s.change_table_name AND
        c.column_name NOT LIKE '%$'
/

comment on table ALL_PUBLISHED_COLUMNS is 'Source columns available for Change Data Capture'
/

comment on column ALL_PUBLISHED_COLUMNS.CHANGE_SET_NAME is 'Change set in which source column is published'
/

comment on column ALL_PUBLISHED_COLUMNS.PUB_ID is 'Publication ID in which source column is published'
/

comment on column ALL_PUBLISHED_COLUMNS.SOURCE_SCHEMA_NAME is 'Source schema name of published column'
/

comment on column ALL_PUBLISHED_COLUMNS.SOURCE_TABLE_NAME is 'Source table name of published column'
/

comment on column ALL_PUBLISHED_COLUMNS.COLUMN_NAME is 'Column name of published column'
/

comment on column ALL_PUBLISHED_COLUMNS.DATA_TYPE is 'Column datatype'
/

comment on column ALL_PUBLISHED_COLUMNS.DATA_LENGTH is 'Column length'
/

comment on column ALL_PUBLISHED_COLUMNS.DATA_PRECISION is 'Column precision'
/

comment on column ALL_PUBLISHED_COLUMNS.DATA_SCALE is 'Column scale'
/

comment on column ALL_PUBLISHED_COLUMNS.NULLABLE is 'Whether column is nullable'
/

