create view EXU8SRTU as
SELECT  "SOWNER","SOWNERID","VNAME","MASTER_OWNER","MASTER","TABNUM","REFRESH_TIME"
        FROM    sys.exu8srt
        WHERE   sownerid = UID
/

