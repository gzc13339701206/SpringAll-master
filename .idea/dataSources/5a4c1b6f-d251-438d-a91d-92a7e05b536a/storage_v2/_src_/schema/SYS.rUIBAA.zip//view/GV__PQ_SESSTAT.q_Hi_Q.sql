create view GV_$PQ_SESSTAT as
select "INST_ID","STATISTIC","LAST_QUERY","SESSION_TOTAL" from gv$pq_sesstat
/

