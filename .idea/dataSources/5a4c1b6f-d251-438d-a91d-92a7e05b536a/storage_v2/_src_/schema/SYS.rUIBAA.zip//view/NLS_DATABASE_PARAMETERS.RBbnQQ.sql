create view NLS_DATABASE_PARAMETERS as
select name,
       substr(value$, 1, 40)
from props$
where name like 'NLS%'
/

comment on table NLS_DATABASE_PARAMETERS is 'Permanent NLS parameters of the database'
/

comment on column NLS_DATABASE_PARAMETERS.PARAMETER is 'Parameter name'
/

comment on column NLS_DATABASE_PARAMETERS.VALUE is 'Parameter value'
/

