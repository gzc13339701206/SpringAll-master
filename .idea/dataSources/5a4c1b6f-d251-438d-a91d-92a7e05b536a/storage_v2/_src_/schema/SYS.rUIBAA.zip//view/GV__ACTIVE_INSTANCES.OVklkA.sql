create view GV_$ACTIVE_INSTANCES as
select "INST_ID","INST_NUMBER","INST_NAME" from gv$active_instances
/

