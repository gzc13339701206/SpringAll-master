create view EXU8RFSU as
SELECT  "OBJNO","OWNERID","PROPERTY","COLNAME","REFTYP","SOID","ROBJID","PKEYCNO","PKEYOWNER"
        FROM    sys.exu8rfs
        WHERE   ownerid = UID
/

