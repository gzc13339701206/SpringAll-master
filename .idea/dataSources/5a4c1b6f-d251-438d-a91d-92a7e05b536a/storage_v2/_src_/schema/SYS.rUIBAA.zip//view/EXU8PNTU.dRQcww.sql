create view EXU8PNTU as
SELECT  "POBJNO","PNAME","POWNERID","COBJNO"
        FROM    sys.exu8pnt
        WHERE   pownerid = UID
/

