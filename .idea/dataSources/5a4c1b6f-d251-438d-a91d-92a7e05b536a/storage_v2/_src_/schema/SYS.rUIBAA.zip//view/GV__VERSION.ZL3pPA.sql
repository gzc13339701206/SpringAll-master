create view GV_$VERSION as
select "INST_ID","BANNER" from gv$version
/

