create view USER_PROCEDURES as
select o.name, pi.procedurename,
decode(bitand(pi.properties,8),8,'YES','NO'),
decode(bitand(pi.properties,16),16,'YES','NO'),
u2.name, o2.name,
decode(bitand(pi.properties,32),32,'YES','NO'),
decode(bitand(pi.properties,512),512,'YES','NO'),
decode(bitand(pi.properties,256),256,'YES','NO'),
decode(bitand(pi.properties,1024),1024,'CURRENT_USER','DEFINER')
from sys.obj$ o, sys.procedureinfo$ pi, sys.obj$ o2, sys.user$ u2
where o.owner# = userenv('SCHEMAID') and o.obj# = pi.obj#
and pi.itypeobj# = o2.obj# (+) and o2.owner#  = u2.user# (+)
/

comment on table USER_PROCEDURES is 'Description of the users own procedures'
/

comment on column USER_PROCEDURES.OBJECT_NAME is 'Name of the object : top level function/procedure/package name'
/

comment on column USER_PROCEDURES.PROCEDURE_NAME is 'Name of the procedure'
/

comment on column USER_PROCEDURES.AGGREGATE is 'Is it an aggregate function ?'
/

comment on column USER_PROCEDURES.PIPELINED is 'Is it a pipelined table function ?'
/

comment on column USER_PROCEDURES.IMPLTYPEOWNER is 'Name of the owner of the implementation type (if any)'
/

comment on column USER_PROCEDURES.IMPLTYPENAME is 'Name of the implementation type (if any)'
/

comment on column USER_PROCEDURES.PARALLEL is 'Is the procedure parallel enabled ?'
/

