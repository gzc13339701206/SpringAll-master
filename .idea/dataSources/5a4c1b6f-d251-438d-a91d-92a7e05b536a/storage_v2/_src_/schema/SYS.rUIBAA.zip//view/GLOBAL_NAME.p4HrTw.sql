create view GLOBAL_NAME as
select value$ from sys.props$ where name = 'GLOBAL_DB_NAME'
/

comment on table GLOBAL_NAME is 'global database name'
/

comment on column GLOBAL_NAME.GLOBAL_NAME is 'global database name'
/

