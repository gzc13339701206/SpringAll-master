create view ALL_SYNONYMS as
  select u.name, o.name, s.owner, s.name, s.node
from sys.user$ u, sys.syn$ s, sys.obj$ o
where o.obj# = s.obj#
  and o.type# = 5
  and o.owner# = u.user#
  and (
       o.owner# in (USERENV('SCHEMAID'), 1 /* PUBLIC */)  /* user's private, any public */
       or /* user has any privs on base object in local database */
        exists
        (select null
         from sys.objauth$ ba, sys.obj$ bo, sys.user$ bu
         where s.node is null /* don't know accessibility if syn for db link */
           and bu.name = s.owner
           and bo.name = s.name
           and bu.user# = bo.owner#
           and ba.obj# = bo.obj#
           and (   ba.grantee# in (select kzsrorol from x$kzsro)
                or ba.grantor# = USERENV('SCHEMAID')
               )
        )
       or /* local object, and user has system privileges */
         (s.node is null /* don't know accessibility if syn is for db link */
          and exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                     )
         )
       )
union
select u.name, o.name, s.owner, s.name, s.node
from sys.user$ u, sys.syn$ s, sys.obj$ o, sys."_ALL_SYNONYMS_TREE" st
where o.obj# = s.obj#
  and o.type# = 5
  and o.owner# = u.user#
  and o.obj# = st.syn_id /* syn is in tree pointing to accessible base obj */
  and s.obj# = st.syn_id /* syn is in tree pointing to accessible base obj */

comment on table ALL_SYNONYMS is 'All synonyms for base objects accessible to the user and session'
/

comment on column ALL_SYNONYMS.OWNER is 'Owner of the synonym'
/

comment on column ALL_SYNONYMS.SYNONYM_NAME is 'Name of the synonym'
/

comment on column ALL_SYNONYMS.TABLE_OWNER is 'Owner of the object referenced by the synonym'
/

comment on column ALL_SYNONYMS.TABLE_NAME is 'Name of the object referenced by the synonym'
/

comment on column ALL_SYNONYMS.DB_LINK is 'Name of the database link referenced in a remote synonym'
/

