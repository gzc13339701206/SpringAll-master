create view EXU9LNKU as
SELECT  "OWNER","OWNERID","NAME","USER$","PASSWD","HOST","PUBLIC$","AUTH_USER","AUTH_PASSWD","FLAG"
        FROM    sys.exu9lnk
        WHERE   ownerid = UID
/

