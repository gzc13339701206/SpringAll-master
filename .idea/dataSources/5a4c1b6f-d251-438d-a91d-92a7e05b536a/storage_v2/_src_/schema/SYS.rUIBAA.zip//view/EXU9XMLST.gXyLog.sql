create view EXU9XMLST as
SELECT RAWTOHEX(opq.schemaoid), o.obj#
        FROM sys.opqtype$ opq, sys.obj$ o
        WHERE o.obj# = opq.obj# AND
              opq.type = 1 AND                                   /* XML Type */
              BITAND(opq.flags, 2) = 2                          /* XMLSchema */

