create view ROLE_TAB_PRIVS as
select u1.name,u2.name,o.name,col$.name,tpm.name,
       decode(max(mod(oa.option$,2)), 1, 'YES', 'NO')
from  sys.user$ u1,sys.user$ u2,sys.table_privilege_map tpm,
      sys.objauth$ oa,sys.obj$ o,sys.col$
where grantee# in
   (select distinct(privilege#)
    from sys.sysauth$ sa
    where privilege# > 0
    connect by prior sa.privilege# = sa.grantee#
    start with grantee#=userenv('SCHEMAID') or grantee#=1 or grantee# in
      (select kzdosrol from x$kzdos))
   and u1.user#=oa.grantee# and oa.privilege#=tpm.privilege
   and oa.obj#=o.obj# and oa.obj#=col$.obj#(+) and oa.col#=col$.col#(+)
   and u2.user#=o.owner#
  and (col$.property IS NULL OR bitand(col$.property, 32) = 0 )
group by u1.name,u2.name,o.name,col$.name,tpm.name
/

comment on table ROLE_TAB_PRIVS is 'Table privileges granted to roles'
/

comment on column ROLE_TAB_PRIVS.ROLE is 'Role Name'
/

comment on column ROLE_TAB_PRIVS.TABLE_NAME is 'Table Name or Sequence Name'
/

comment on column ROLE_TAB_PRIVS.COLUMN_NAME is 'Column Name if applicable'
/

comment on column ROLE_TAB_PRIVS.PRIVILEGE is 'Table Privilege'
/

