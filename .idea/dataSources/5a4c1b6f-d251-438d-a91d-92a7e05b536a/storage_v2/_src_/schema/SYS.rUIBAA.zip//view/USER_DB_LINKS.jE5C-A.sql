create view USER_DB_LINKS as
select l.name, l.userid, l.password, l.host, l.ctime
from sys.link$ l
where l.owner# = userenv('SCHEMAID')
/

comment on table USER_DB_LINKS is 'Database links owned by the user'
/

comment on column USER_DB_LINKS.DB_LINK is 'Name of the database link'
/

comment on column USER_DB_LINKS.USERNAME is 'Name of user to log on as'
/

comment on column USER_DB_LINKS.PASSWORD is 'Deprecated-Password for logon'
/

comment on column USER_DB_LINKS.HOST is 'SQL*Net string for connect'
/

comment on column USER_DB_LINKS.CREATED is 'Creation time of the database link'
/

