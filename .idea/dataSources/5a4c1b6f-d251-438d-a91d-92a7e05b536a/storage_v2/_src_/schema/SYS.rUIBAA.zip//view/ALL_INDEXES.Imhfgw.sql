create view ALL_INDEXES as
select u.name, o.name,
       decode(bitand(i.property, 16), 0, '', 'FUNCTION-BASED ') ||
        decode(i.type#, 1, 'NORMAL'||
                          decode(bitand(i.property, 4), 0, '', 4, '/REV'),
                      2, 'BITMAP', 3, 'CLUSTER', 4, 'IOT - TOP',
                      5, 'IOT - NESTED', 6, 'SECONDARY', 7, 'ANSI', 8, 'LOB',
                      9, 'DOMAIN'),
       iu.name, io.name, 'TABLE',
       decode(bitand(i.property, 1), 0, 'NONUNIQUE', 1, 'UNIQUE', 'UNDEFINED'),
       decode(bitand(i.flags, 32), 0, 'DISABLED', 32, 'ENABLED', null),
       i.spare2,
       decode(bitand(i.property, 34), 0,
           decode(i.type#, 9, null, ts.name), null),
       decode(bitand(i.property, 2),0, i.initrans, null),
       decode(bitand(i.property, 2),0, i.maxtrans, null),
       s.iniexts * ts.blocksize,
       decode(bitand(ts.flags, 3), 1, to_number(NULL),
                             s.extsize * ts.blocksize),
       s.minexts, s.maxexts,
        decode(bitand(ts.flags, 3), 1, to_number(NULL),
                                     s.extpct),
       decode(i.type#, 4, mod(i.pctthres$,256), NULL), i.trunccnt,
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
         decode(bitand(o.flags, 2), 2, 1, decode(s.lists, 0, 1, s.lists))),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
         decode(bitand(o.flags, 2), 2, 1, decode(s.groups, 0, 1, s.groups))),
       decode(bitand(i.property, 2),0,i.pctfree$,null),
       decode(bitand(i.property, 2), 2, NULL,
                decode(bitand(i.flags, 4), 0, 'YES', 'NO')),
       i.blevel, i.leafcnt, i.distkey, i.lblkkey, i.dblkkey, i.clufac,
       decode(bitand(i.property, 2), 2,
                   decode(i.type#, 9, decode(bitand(i.flags, 8),
                                        8, 'INPROGRS', 'VALID'), 'N/A'),
                     decode(bitand(i.flags, 1), 1, 'UNUSABLE',
                            decode(bitand(i.flags, 8), 8, 'INRPOGRS',
                                                            'VALID'))),
       rowcnt, samplesize, analyzetime,
       decode(i.degree, 32767, 'DEFAULT', nvl(i.degree,1)),
       decode(i.instances, 32767, 'DEFAULT', nvl(i.instances,1)),
       decode(bitand(i.property, 2), 2, 'YES', 'NO'),
       decode(bitand(o.flags, 2), 0, 'N', 2, 'Y', 'N'),
       decode(bitand(o.flags, 4), 0, 'N', 4, 'Y', 'N'),
       decode(bitand(o.flags, 16), 0, 'N', 16, 'Y', 'N'),
       decode(bitand(o.flags, 2), 2, 'DEFAULT',
             decode(s.cachehint, 0, 'DEFAULT', 1, 'KEEP', 2, 'RECYCLE', NULL)),
       decode(bitand(i.flags, 64), 0, 'NO', 'YES'),
       decode(bitand(o.flags, 2), 0, NULL,
           decode(bitand(i.property, 64), 64, 'SYS$SESSION', 'SYS$TRANSACTION')),
       decode(bitand(i.flags, 128), 128, mod(trunc(i.pctthres$/256),256),
              decode(i.type#, 4, mod(trunc(i.pctthres$/256),256), NULL)),
       itu.name, ito.name, i.spare4,
       decode(bitand(i.flags, 2048), 0, 'NO', 'YES'),
       decode(i.type#, 9, decode(o.status, 5, 'IDXTYP_INVLD',
                                           1, 'VALID'),  ''),
       decode(i.type#, 9, decode(bitand(i.flags, 16), 16, 'FAILED', 'VALID'), ''),
       decode(bitand(i.property, 16), 0, '',
              decode(bitand(i.flags, 1024), 0, 'ENABLED', 'DISABLED')),
       decode(bitand(i.property, 1024), 1024, 'YES', 'NO'),
       decode(bitand(i.property, 16384), 16384, 'YES', 'NO'),
       decode(bitand(o.flags, 128), 128, 'YES', 'NO')
from sys.ts$ ts, sys.seg$ s, sys.user$ iu, sys.obj$ io,
     sys.user$ u, sys.ind$ i, sys.obj$ o, sys.user$ itu, sys.obj$ ito
where u.user# = o.owner#
  and o.obj# = i.obj#
  and i.bo# = io.obj#
  and io.owner# = iu.user#
  and io.type# = 2 /* tables */
  and bitand(i.flags, 4096) = 0
  and bitand(o.flags, 128) = 0
  and i.ts# = ts.ts# (+)
  and i.file# = s.file# (+)
  and i.block# = s.block# (+)
  and i.ts# = s.ts# (+)
  and i.type# in (1, 2, 3, 4, 6, 7, 9)
  and i.indmethod# = ito.obj# (+)
  and ito.owner# = itu.user# (+)
  and (io.owner# = userenv('SCHEMAID')
        or
       io.obj# in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                   )
        or
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
       )
/

comment on table ALL_INDEXES is 'Descriptions of indexes on tables accessible to the user'
/

comment on column ALL_INDEXES.OWNER is 'Username of the owner of the index'
/

comment on column ALL_INDEXES.INDEX_NAME is 'Name of the index'
/

comment on column ALL_INDEXES.TABLE_OWNER is 'Owner of the indexed object'
/

comment on column ALL_INDEXES.TABLE_NAME is 'Name of the indexed object'
/

comment on column ALL_INDEXES.TABLE_TYPE is 'Type of the indexed object'
/

comment on column ALL_INDEXES.UNIQUENESS is 'Uniqueness status of the index: "UNIQUE",  "NONUNIQUE", or "BITMAP"'
/

comment on column ALL_INDEXES.COMPRESSION is 'Compression property of the index: "ENABLED",  "DISABLED", or NULL'
/

comment on column ALL_INDEXES.PREFIX_LENGTH is 'Number of key columns in the prefix used for compression'
/

comment on column ALL_INDEXES.TABLESPACE_NAME is 'Name of the tablespace containing the index'
/

comment on column ALL_INDEXES.INI_TRANS is 'Initial number of transactions'
/

comment on column ALL_INDEXES.MAX_TRANS is 'Maximum number of transactions'
/

comment on column ALL_INDEXES.INITIAL_EXTENT is 'Size of the initial extent'
/

comment on column ALL_INDEXES.NEXT_EXTENT is 'Size of secondary extents'
/

comment on column ALL_INDEXES.MIN_EXTENTS is 'Minimum number of extents allowed in the segment'
/

comment on column ALL_INDEXES.MAX_EXTENTS is 'Maximum number of extents allowed in the segment'
/

comment on column ALL_INDEXES.PCT_INCREASE is 'Percentage increase in extent size'
/

comment on column ALL_INDEXES.PCT_THRESHOLD is 'Threshold percentage of block space allowed per index entry'
/

comment on column ALL_INDEXES.INCLUDE_COLUMN is 'User column-id for last column to be included in index-organized table top index'
/

comment on column ALL_INDEXES.FREELISTS is 'Number of process freelists allocated in this segment'
/

comment on column ALL_INDEXES.FREELIST_GROUPS is 'Number of freelist groups allocated to this segment'
/

comment on column ALL_INDEXES.PCT_FREE is 'Minimum percentage of free space in a block'
/

comment on column ALL_INDEXES.LOGGING is 'Logging attribute'
/

comment on column ALL_INDEXES.BLEVEL is 'B-Tree level'
/

comment on column ALL_INDEXES.LEAF_BLOCKS is 'The number of leaf blocks in the index'
/

comment on column ALL_INDEXES.DISTINCT_KEYS is 'The number of distinct keys in the index'
/

comment on column ALL_INDEXES.AVG_LEAF_BLOCKS_PER_KEY is 'The average number of leaf blocks per key'
/

comment on column ALL_INDEXES.AVG_DATA_BLOCKS_PER_KEY is 'The average number of data blocks per key'
/

comment on column ALL_INDEXES.CLUSTERING_FACTOR is 'A measurement of the amount of (dis)order of the table this index is for'
/

comment on column ALL_INDEXES.STATUS is 'Whether the non-partitioned index is in USABLE or not'
/

comment on column ALL_INDEXES.SAMPLE_SIZE is 'The sample size used in analyzing this index'
/

comment on column ALL_INDEXES.LAST_ANALYZED is 'The date of the most recent time this index was analyzed'
/

comment on column ALL_INDEXES.DEGREE is 'The number of threads per instance for scanning the partitioned index'
/

comment on column ALL_INDEXES.INSTANCES is 'The number of instances across which the partitioned index is to be scanned'
/

comment on column ALL_INDEXES.PARTITIONED is 'Is this index partitioned? YES or NO'
/

comment on column ALL_INDEXES.TEMPORARY is 'Can the current session only see data that it place in this object itself?'
/

comment on column ALL_INDEXES.GENERATED is 'Was the name of this index system generated?'
/

comment on column ALL_INDEXES.SECONDARY is 'Is the index object created as part of icreate for domain indexes?'
/

comment on column ALL_INDEXES.BUFFER_POOL is 'The default buffer pool to be used for index blocks'
/

comment on column ALL_INDEXES.USER_STATS is 'Were the statistics entered directly by the user?'
/

comment on column ALL_INDEXES.DURATION is 'If index on temporary table, then duration is sys$session or sys$transaction else NULL'
/

comment on column ALL_INDEXES.PCT_DIRECT_ACCESS is 'If index on IOT, then this is percentage of rows with Valid guess'
/

comment on column ALL_INDEXES.ITYP_OWNER is 'If domain index, then this is the indextype owner'
/

comment on column ALL_INDEXES.ITYP_NAME is 'If domain index, then this is the name of the associated indextype'
/

comment on column ALL_INDEXES.PARAMETERS is 'If domain index, then this is the parameter string'
/

comment on column ALL_INDEXES.GLOBAL_STATS is 'Are the statistics calculated without merging underlying partitions?'
/

comment on column ALL_INDEXES.DOMIDX_STATUS is 'Is the indextype of the domain index valid'
/

comment on column ALL_INDEXES.DOMIDX_OPSTATUS is 'Status of the operation on the domain index'
/

comment on column ALL_INDEXES.FUNCIDX_STATUS is 'Is the Function-based Index DISABLED or ENABLED?'
/

comment on column ALL_INDEXES.JOIN_INDEX is 'Is this index a join index?'
/

comment on column ALL_INDEXES.IOT_REDUNDANT_PKEY_ELIM is 'Were redundant primary key columns eliminated from iot secondary index?'
/

comment on column ALL_INDEXES.DROPPED is 'Whether index is dropped and is in Recycle Bin'
/

