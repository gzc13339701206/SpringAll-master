create view ALL_UNUSED_COL_TABS as
select u.name, o.name, count(*)
from sys.user$ u, sys.obj$ o, sys.col$ c
where o.owner# = u.user#
  and o.obj# = c.obj#
  and bitand(c.property,32768) = 32768              -- is unused column
  and bitand(c.property, 1) != 1                    -- not ADT attribute col
  and bitand(c.property, 1024) != 1024              -- not NTAB's setid col
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or exists (select null from v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */)
                 )
      )
  group by u.name, o.name
/

comment on table ALL_UNUSED_COL_TABS is 'All tables with unused columns accessible to the user'
/

comment on column ALL_UNUSED_COL_TABS.OWNER is 'Owner of the table'
/

comment on column ALL_UNUSED_COL_TABS.TABLE_NAME is 'Name of the table'
/

comment on column ALL_UNUSED_COL_TABS.COUNT is 'Number of unused columns in table'
/

