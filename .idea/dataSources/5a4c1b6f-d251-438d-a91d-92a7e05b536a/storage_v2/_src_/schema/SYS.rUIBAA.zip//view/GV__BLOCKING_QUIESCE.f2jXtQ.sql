create view GV_$BLOCKING_QUIESCE as
select "INST_ID","SID" from gv$blocking_quiesce
/

