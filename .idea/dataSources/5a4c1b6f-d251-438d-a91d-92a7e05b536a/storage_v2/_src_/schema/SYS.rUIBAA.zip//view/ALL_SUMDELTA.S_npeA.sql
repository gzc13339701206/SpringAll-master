create view ALL_SUMDELTA as
select s.TABLEOBJ#, s.PARTITIONOBJ#, s.DMLOPERATION, s.SCN,
          s.TIMESTAMP, s.LOWROWID, s.HIGHROWID, s.SEQUENCE
from  sys.obj$ o, sys.user$ u, sys.sumdelta$ s
where o.type# = 2
  and o.owner# = u.user#
  and s.tableobj# = o.obj#
  and (o.owner# = userenv('SCHEMAID')
    or o.obj# in
      (select oa.obj#
         from sys.objauth$ oa
         where grantee# in ( select kzsrorol from x$kzsro)
      )
    or /* user has system privileges */
      exists (select null from v$enabledprivs
        where priv_number in (-45 /* LOCK ANY TABLE */,
                              -47 /* SELECT ANY TABLE */,
                              -48 /* INSERT ANY TABLE */,
                              -49 /* UPDATE ANY TABLE */,
                              -50 /* DELETE ANY TABLE */)
              )
      )
/

comment on table ALL_SUMDELTA is 'Direct path load entries accessible to the user'
/

comment on column ALL_SUMDELTA.TABLEOBJ# is 'Object number of the table'
/

comment on column ALL_SUMDELTA.PARTITIONOBJ# is 'Object number of table partitions (if the table is partitioned)'
/

comment on column ALL_SUMDELTA.DMLOPERATION is 'Type of DML operation applied to the table'
/

comment on column ALL_SUMDELTA.SCN is 'SCN when the bulk DML occurred'
/

comment on column ALL_SUMDELTA.TIMESTAMP is 'Timestamp of log entry'
/

comment on column ALL_SUMDELTA.LOWROWID is 'The start ROWID in the loaded rowid range'
/

comment on column ALL_SUMDELTA.HIGHROWID is 'The end ROWID in the loaded rowid range'
/

comment on column ALL_SUMDELTA.SEQUENCE is 'The sequence# of the direct load'
/

