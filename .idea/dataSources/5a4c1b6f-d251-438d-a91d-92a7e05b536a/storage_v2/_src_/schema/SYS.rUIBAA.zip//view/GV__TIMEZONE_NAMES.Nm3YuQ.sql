create view GV_$TIMEZONE_NAMES as
select "TZNAME","TZABBREV" from gv$timezone_names
/

