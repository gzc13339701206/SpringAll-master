create view EXU8ANAL as
SELECT  obj#, SIGN(NVL(rowcnt, -1))
        FROM    sys.tab$
/

