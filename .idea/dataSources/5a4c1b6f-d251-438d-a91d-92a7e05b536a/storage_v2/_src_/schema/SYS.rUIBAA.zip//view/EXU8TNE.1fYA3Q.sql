create view EXU8TNE as
SELECT  e.tsno, e.fileno, e.blockno,
                CEIL(e.length * ((
                    SELECT  t1$.blocksize
                    FROM    sys.ts$ t1$
                    WHERE   t1$.ts# = e.tsno) / (
                    SELECT  t0$.blocksize
                    FROM    sys.ts$ t0$
                    WHERE   t0$.ts# = 0)))
        FROM    sys.exu9tne e
/

