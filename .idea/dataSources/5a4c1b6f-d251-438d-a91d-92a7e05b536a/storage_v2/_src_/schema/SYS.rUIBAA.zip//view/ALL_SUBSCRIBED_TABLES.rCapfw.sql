create view ALL_SUBSCRIBED_TABLES as
SELECT
   st.handle, t.source_schema_name, t.source_table_name, st.view_name,
   t.change_set_name, s.subscription_name
  FROM sys.cdc_subscribed_tables$ st, sys.cdc_change_tables$ t,
       sys.cdc_subscribers$ s, sys.user$ u
  WHERE st.change_table_obj#=t.obj# AND
        s.handle = st.handle AND
        s.username = u.name AND
        u.user# = userenv('SCHEMAID')
/

comment on table ALL_SUBSCRIBED_TABLES is 'Change Data Capture subscribed tables'
/

comment on column ALL_SUBSCRIBED_TABLES.HANDLE is 'Unique identifier of the subscription'
/

comment on column ALL_SUBSCRIBED_TABLES.SOURCE_SCHEMA_NAME is 'Source schema name of the subscribed table'
/

comment on column ALL_SUBSCRIBED_TABLES.SOURCE_TABLE_NAME is 'Source table name of the subscribed table'
/

comment on column ALL_SUBSCRIBED_TABLES.VIEW_NAME is 'Subscriber view name for the subscribed table'
/

comment on column ALL_SUBSCRIBED_TABLES.CHANGE_SET_NAME is 'Change set name for the subscribed table'
/

comment on column ALL_SUBSCRIBED_TABLES.SUBSCRIPTION_NAME is 'Name of the subscription'
/

