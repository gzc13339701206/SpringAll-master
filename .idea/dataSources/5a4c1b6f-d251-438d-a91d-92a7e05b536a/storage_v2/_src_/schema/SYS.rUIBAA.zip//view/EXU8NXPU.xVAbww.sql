create view EXU8NXPU as
SELECT  owner, name, type
        FROM    sys.exu8nxp
        WHERE   ownerid = UID
/

