create view EXU81OBJECTPKG as
SELECT  package, schema, class, type#, level#
        FROM    sys.exppkgobj$
/

