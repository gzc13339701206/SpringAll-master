create view EXU9OBJSWITCH as
SELECT  a.obj#, a.value, b.value
        FROM    sys.settings$ a, sys.settings$ b, sys.obj$ o
        WHERE   o.obj#  = a.obj# AND
                a.obj#  = b.obj# AND
                a.param = 'plsql_compiler_flags' AND
                b.param = 'nls_length_semantics' AND
                (UID IN (o.owner#, 0) OR
                 EXISTS (
                    SELECT  role
                    FROM    sys.session_roles
                    WHERE   role = 'SELECT_CATALOG_ROLE'))
/

