create view ALL_OPBINDINGS as
select   c.name, b.name, a.bind#, a.functionname, a.returnschema,
         a.returntype, a.impschema, a.imptype,
        decode(bitand(a.property,31), 1, 'WITH INDEX CONTEXT',
               3 , 'COMPUTE ANCILLARY DATA', 4 , 'ANCILLARY TO' ,
               16 , 'WITH COLUMN CONTEXT' ,
               17,  'WITH INDEX, COLUMN CONTEXT',
               19, 'COMPUTE ANCILLARY DATA, WITH COLUMN CONTEXT')
   from  sys.opbinding$ a, sys.obj$ b, sys.user$ c where
  a.obj# = b.obj# and b.owner# = c.user#
  and ( b.owner# = userenv ('SCHEMAID')
    or
    b.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or exists (select null from v$enabledprivs
                  where priv_number in (-200 /* CREATE OPERATOR */,
                                        -201 /* CREATE ANY OPERATOR */,
                                        -202 /* ALTER ANY OPERATOR */,
                                        -203 /* DROP ANY OPERATOR */,
                                        -204 /* EXECUTE OPERATOR */)
                 )
      )
/

comment on table ALL_OPBINDINGS is 'All binding functions for operators available to the user'
/

comment on column ALL_OPBINDINGS.OWNER is 'Owner of the operator'
/

comment on column ALL_OPBINDINGS.OPERATOR_NAME is 'Name of the operator'
/

comment on column ALL_OPBINDINGS.BINDING# is 'Binding# of the operator'
/

comment on column ALL_OPBINDINGS.FUNCTION_NAME is 'Name of the binding function or method as specified by the user'
/

comment on column ALL_OPBINDINGS.RETURN_SCHEMA is 'Name of the schema of the return type - not null only for ADTs'
/

comment on column ALL_OPBINDINGS.RETURN_TYPE is 'Name of the return type'
/

comment on column ALL_OPBINDINGS.IMPLEMENTATION_TYPE_SCHEMA is 'Schema of the implementation type of the indextype '
/

comment on column ALL_OPBINDINGS.IMPLEMENTATION_TYPE is 'Implementation type of the indextype'
/

comment on column ALL_OPBINDINGS.PROPERTY is 'Property of the operator binding'
/

