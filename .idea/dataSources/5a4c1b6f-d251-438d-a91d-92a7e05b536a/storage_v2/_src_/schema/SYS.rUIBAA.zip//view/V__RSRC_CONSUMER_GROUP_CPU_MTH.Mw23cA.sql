create view V_$RSRC_CONSUMER_GROUP_CPU_MTH as
select "NAME" from v$rsrc_consumer_group_cpu_mth
/

