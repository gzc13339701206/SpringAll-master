create view EXU9ACTIONOBJ as
SELECT  o.name, d.obj#, u.name, o.owner#, t.property, o.type#,
                p.level#, p.package, p.schema, o.namespace, p.class
        FROM    sys.exu81obj o, sys.user$ u, sys.exppkgact$ p, sys.tab$ t,
                sys.expdepact$ d
        WHERE   d.obj# = o.obj# AND
                o.owner# = u.user# AND
                d.package = p.package AND
                d.schema = p.schema AND
                ((p.class = 3) OR (p.class = 4)) AND
                d.obj# = t.obj# AND
                (UID IN (o.owner#, 0) OR
                 EXISTS (
                    SELECT  role
                    FROM    sys.session_roles
                    WHERE   role = 'SELECT_CATALOG_ROLE'))
/

