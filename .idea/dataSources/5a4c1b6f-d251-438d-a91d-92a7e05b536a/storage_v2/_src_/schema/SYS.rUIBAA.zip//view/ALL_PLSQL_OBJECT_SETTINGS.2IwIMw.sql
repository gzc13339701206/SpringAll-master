create view ALL_PLSQL_OBJECT_SETTINGS as
select u.name, o.name,
decode(o.type#, 7, 'PROCEDURE', 8, 'FUNCTION', 9, 'PACKAGE',
                11, 'PACKAGE BODY', 12, 'TRIGGER',
                13, 'TYPE', 14, 'TYPE BODY', 'UNDEFINED'),
(select to_number(value) from settings$ s
  where s.obj# = o.obj# and param = 'plsql_optimize_level'),
(select value from settings$ s
  where s.obj# = o.obj# and param = 'plsql_code_type'),
(select value from settings$ s
  where s.obj# = o.obj# and param = 'plsql_debug'),
(select value from settings$ s
  where s.obj# = o.obj# and param = 'plsql_warnings'),
(select value from settings$ s
  where s.obj# = o.obj# and param = 'nls_length_semantics'),
(select value from settings$ s
  where s.obj# = o.obj# and param = 'plsql_ccflags')
from sys.obj$ o, sys.user$ u
where o.owner# = u.user#
  and o.type# in (7, 8, 9, 11, 12, 13, 14)
  and
  (
    o.owner# in (userenv('SCHEMAID'), 1 /* PUBLIC */)
    or
    (
      /* EXECUTE privilege does not let user see package or type body */
      o.type# in (7, 8, 9, 12, 13)
      and
      o.obj# in (select obj# from sys.objauth$
                 where grantee# in (select kzsrorol from x$kzsro)
                   and privilege# = 12 /* EXECUTE */
                )
    )
    or
    (
       o.type# in (7, 8, 9) /* procedure, function, package */
       and
       exists (select null from v$enabledprivs
               where priv_number in (
                                      -144 /* EXECUTE ANY PROCEDURE */,
                                      -141 /* CREATE ANY PROCEDURE */
                                    )
              )
    )
    or
    (
      o.type# = 11 /* package body */
      and
      exists (select null from v$enabledprivs
              where priv_number = -141 /* CREATE ANY PROCEDURE */)
    )
    or
    (
       o.type# = 12 /* trigger */
       and
       exists (select null from v$enabledprivs
               where priv_number = -152 /* CREATE ANY TRIGGER */)
    )
    or
    (
      o.type# = 13 /* type */
      and
      exists (select null from v$enabledprivs
              where priv_number in (-184 /* EXECUTE ANY TYPE */,
                                    -181 /* CREATE ANY TYPE */))
    )
    or
    (
      o.type# = 14 /* type body */
      and
      exists (select null from v$enabledprivs
              where priv_number = -181 /* CREATE ANY TYPE */)
    )
  )
/

comment on table ALL_PLSQL_OBJECT_SETTINGS is 'Compiler settings of stored objects accessible to the user'
/

comment on column ALL_PLSQL_OBJECT_SETTINGS.OWNER is 'Username of the owner of the object'
/

comment on column ALL_PLSQL_OBJECT_SETTINGS.NAME is 'Name of the object'
/

comment on column ALL_PLSQL_OBJECT_SETTINGS.TYPE is 'Type of the object: "PROCEDURE", "FUNCTION",
"PACKAGE", "PACKAGE BODY", "TRIGGER", "TYPE" or "TYPE BODY"'
/

comment on column ALL_PLSQL_OBJECT_SETTINGS.PLSQL_OPTIMIZE_LEVEL is 'The optimization level to use to compile the object'
/

comment on column ALL_PLSQL_OBJECT_SETTINGS.PLSQL_CODE_TYPE is 'The object codes are to be compiled natively or are interpreted'
/

comment on column ALL_PLSQL_OBJECT_SETTINGS.PLSQL_DEBUG is 'The object is to be compiled with debug information or not'
/

comment on column ALL_PLSQL_OBJECT_SETTINGS.PLSQL_WARNINGS is 'The compiler warning settings to use to compile the object'
/

comment on column ALL_PLSQL_OBJECT_SETTINGS.NLS_LENGTH_SEMANTICS is 'The NLS length semantics to use to compile the object'
/

comment on column ALL_PLSQL_OBJECT_SETTINGS.PLSQL_CCFLAGS is 'The conditional compilation flag settings to use to compile the object'
/

