create view EXU81CSC as
SELECT  '8.1.0.0.0'
        FROM    DUAL
/

