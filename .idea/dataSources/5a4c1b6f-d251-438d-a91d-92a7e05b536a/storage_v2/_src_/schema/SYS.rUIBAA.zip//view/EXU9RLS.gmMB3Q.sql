create view EXU9RLS as
SELECT  u.name, o.name, r.gname, r.pname, r.pfschma, r.ppname,
                r.pfname,
                DECODE(BITAND(r.stmt_type, 1), 0, '', 'SELECT,') ||
                DECODE(BITAND(r.stmt_type, 2), 0, '', 'INSERT,') ||
                DECODE(BITAND(r.stmt_type, 4), 0, '', 'UPDATE,') ||
                DECODE(BITAND(r.stmt_type, 8), 0, '', 'DELETE,'),
                r.check_opt, r.enable_flag,
                DECODE(BITAND(r.stmt_type, 16), 0, 0, 1)
        FROM    sys.user$ u, sys.obj$ o, sys.rls$ r
        WHERE   u.user# = o.owner# AND
                r.obj# = o.obj# AND
                (UID IN (o.owner#, 0) OR
                 EXISTS (
                    SELECT  role
                    FROM    sys.session_roles
                    WHERE   role = 'SELECT_CATALOG_ROLE'))
/

