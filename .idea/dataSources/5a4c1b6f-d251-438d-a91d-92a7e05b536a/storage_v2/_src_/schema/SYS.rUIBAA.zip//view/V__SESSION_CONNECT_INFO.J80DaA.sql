create view V_$SESSION_CONNECT_INFO as
select "SID","AUTHENTICATION_TYPE","OSUSER","NETWORK_SERVICE_BANNER" from v$session_connect_info
/

