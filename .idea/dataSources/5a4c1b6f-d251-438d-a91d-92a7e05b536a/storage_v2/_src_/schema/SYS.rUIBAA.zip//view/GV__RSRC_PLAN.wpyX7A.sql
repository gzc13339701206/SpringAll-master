create view GV_$RSRC_PLAN as
select "INST_ID","ID","NAME","IS_TOP_PLAN" from gv$rsrc_plan
/

