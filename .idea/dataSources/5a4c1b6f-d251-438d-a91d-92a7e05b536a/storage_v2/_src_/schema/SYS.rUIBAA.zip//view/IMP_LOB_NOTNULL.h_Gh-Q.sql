create view IMP_LOB_NOTNULL as
SELECT o.name, u.name, c.type#, c.null$
        FROM sys.col$ c, sys.obj$ o, sys.user$ u
        WHERE c.obj#   = o.obj#
        AND   u.user#  = o.owner#
        AND   o.owner# = UID
/

