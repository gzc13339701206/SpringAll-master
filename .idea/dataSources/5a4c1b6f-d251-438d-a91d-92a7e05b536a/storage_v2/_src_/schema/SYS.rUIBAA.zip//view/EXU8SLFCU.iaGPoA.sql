create view EXU8SLFCU as
SELECT  "MOWNER","MOWNERID","MASTER","COLNAME","OLDEST","FLAG"
        FROM    sys.exu8slfc
        WHERE   mownerid = UID
/

