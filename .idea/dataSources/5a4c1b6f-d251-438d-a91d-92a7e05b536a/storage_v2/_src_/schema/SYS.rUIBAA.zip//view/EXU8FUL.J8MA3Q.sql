create view EXU8FUL as
SELECT  u.name
        FROM    sys.x$kzsro, sys.user$ u
        WHERE   kzsrorol != UID AND
                kzsrorol != 1 AND
                u.user# = kzsrorol
/

