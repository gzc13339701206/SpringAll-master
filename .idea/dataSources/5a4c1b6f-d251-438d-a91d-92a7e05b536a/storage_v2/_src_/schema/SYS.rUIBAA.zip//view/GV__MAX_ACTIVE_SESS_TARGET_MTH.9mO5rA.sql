create view GV_$MAX_ACTIVE_SESS_TARGET_MTH as
select "INST_ID","NAME" from gv$max_active_sess_target_mth
/

