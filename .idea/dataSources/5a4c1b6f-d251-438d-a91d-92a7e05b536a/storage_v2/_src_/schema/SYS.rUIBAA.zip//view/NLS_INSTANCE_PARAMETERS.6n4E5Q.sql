create view NLS_INSTANCE_PARAMETERS as
select substr(upper(name), 1, 30),
       substr(value, 1, 40)
from v$parameter
where name like 'nls%'
/

comment on table NLS_INSTANCE_PARAMETERS is 'NLS parameters of the instance'
/

comment on column NLS_INSTANCE_PARAMETERS.PARAMETER is 'Parameter name'
/

comment on column NLS_INSTANCE_PARAMETERS.VALUE is 'Parameter value'
/

