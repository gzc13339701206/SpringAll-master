create view EXU8SPU as
SELECT  "OWNERID","UNAME","ID","NAME","TIME","TYPEID","TYPE","AUDT","SQLVER"
        FROM    sys.exu8spr
        WHERE   UID = ownerid
/

