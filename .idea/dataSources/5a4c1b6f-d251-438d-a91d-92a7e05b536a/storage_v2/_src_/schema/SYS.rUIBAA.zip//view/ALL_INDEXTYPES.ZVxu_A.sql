create view ALL_INDEXTYPES as
select u.name, o.name, u1.name, o1.name, i.interface_version#, t.version#,
io.opcount, decode(bitand(i.property, 48), 0, 'NONE', 16, 'RANGE', 32, 'HASH', 48, 'HASH,RANGE'),
decode(bitand(i.property, 2), 0, 'NO', 2, 'YES')
from sys.indtypes$ i, sys.user$ u, sys.obj$ o,
sys.user$ u1, (select it.obj#, count(*) opcount from
sys.indop$ io1, sys.indtypes$ it where
io1.obj# = it.obj# and bitand(io1.property, 4) != 4
group by it.obj#) io, sys.obj$ o1,
sys.type$ t
where i.obj# = o.obj# and o.owner# = u.user# and
u1.user# = o.owner# and io.obj# = i.obj# and
o1.obj# = i.implobj# and o1.oid$ = t.toid and
( o.owner# = userenv ('SCHEMAID')
    or
    o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or exists (select null from v$enabledprivs
                  where priv_number in (-205 /* CREATE INDEXTYPE */,
                                        -206 /* CREATE ANY INDEXTYPE */,
                                        -207 /* ALTER ANY INDEXTYPE */,
                                        -208 /* DROP ANY INDEXTYPE */)
                 )
      )
/

comment on table ALL_INDEXTYPES is 'All indextypes available to the user'
/

comment on column ALL_INDEXTYPES.OWNER is 'Owner of the indextype'
/

comment on column ALL_INDEXTYPES.INDEXTYPE_NAME is 'Name of the indextype'
/

comment on column ALL_INDEXTYPES.IMPLEMENTATION_SCHEMA is 'Name of the schema for indextype implementation'
/

comment on column ALL_INDEXTYPES.IMPLEMENTATION_NAME is 'Name of indextype implementation'
/

comment on column ALL_INDEXTYPES.INTERFACE_VERSION is 'Version of indextype interface'
/

comment on column ALL_INDEXTYPES.IMPLEMENTATION_VERSION is 'Version of indextype implementation'
/

comment on column ALL_INDEXTYPES.NUMBER_OF_OPERATORS is 'Number of operators associated with the indextype'
/

comment on column ALL_INDEXTYPES.PARTITIONING is 'Kinds of local partitioning supported by the indextype'
/

