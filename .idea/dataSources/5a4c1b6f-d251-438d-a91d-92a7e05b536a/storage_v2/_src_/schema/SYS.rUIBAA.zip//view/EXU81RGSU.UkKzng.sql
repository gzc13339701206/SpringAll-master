create view EXU81RGSU as
SELECT  "REFGROUP","OWNERID","OWNER","INSTSITE"
        FROM    sys.exu81rgs
        WHERE   UID = ownerid
/

