create view ALL_VIEWS as
select u.name, o.name, v.textlength, v.text, t.typetextlength, t.typetext,
       t.oidtextlength, t.oidtext, t.typeowner, t.typename,
       decode(bitand(v.property, 134217728), 134217728,
              (select sv.name from superobj$ h, obj$ sv
              where h.subobj# = o.obj# and h.superobj# = sv.obj#), null)
from sys.obj$ o, sys.view$ v, sys.user$ u, sys.typed_view$ t
where o.obj# = v.obj#
  and o.obj# = t.obj#(+)
  and o.owner# = u.user#
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where oa.grantee# in ( select kzsrorol
                                         from x$kzsro
                                  )
            )
        or /* user has system privileges */
          exists (select null from v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */)
                  )
      )
/

comment on table ALL_VIEWS is 'Description of views accessible to the user'
/

comment on column ALL_VIEWS.OWNER is 'Owner of the view'
/

comment on column ALL_VIEWS.VIEW_NAME is 'Name of the view'
/

comment on column ALL_VIEWS.TEXT_LENGTH is 'Length of the view text'
/

comment on column ALL_VIEWS.TEXT is 'View text'
/

comment on column ALL_VIEWS.TYPE_TEXT_LENGTH is 'Length of the type clause of the object view'
/

comment on column ALL_VIEWS.TYPE_TEXT is 'Type clause of the object view'
/

comment on column ALL_VIEWS.OID_TEXT_LENGTH is 'Length of the WITH OBJECT OID clause of the object view'
/

comment on column ALL_VIEWS.OID_TEXT is 'WITH OBJECT OID clause of the object view'
/

comment on column ALL_VIEWS.VIEW_TYPE_OWNER is 'Owner of the type of the view if the view is an object view'
/

comment on column ALL_VIEWS.VIEW_TYPE is 'Type of the view if the view is an object view'
/

comment on column ALL_VIEWS.SUPERVIEW_NAME is 'Name of the superview, if view is a subview'
/

