create view EXU8CGRU as
SELECT  "OBJID","GRANTOR","GRANTORID","GRANTEE","CREATORID","CNAME","PRIV","SEQUENCE","WGO"
        FROM    sys.exu8cgr
        WHERE   grantorid = UID AND
                creatorid = UID
/

