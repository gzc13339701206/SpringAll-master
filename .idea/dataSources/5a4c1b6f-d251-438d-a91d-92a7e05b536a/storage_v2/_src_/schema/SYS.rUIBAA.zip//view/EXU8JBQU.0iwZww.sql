create view EXU8JBQU as
SELECT  "JOB","OWNERID","OWNER","LOWNER","COWNER","NEXT_DATE","FLAG","INTERVAL#","WHAT","NLSENV","ENV","INSTANCE"
        FROM    sys.exu8jbq
        WHERE   UID = ownerid
/

