create view IMP8UEC as
SELECT  "DUMMY"
        FROM    DUAL
        WHERE   1=0
/

