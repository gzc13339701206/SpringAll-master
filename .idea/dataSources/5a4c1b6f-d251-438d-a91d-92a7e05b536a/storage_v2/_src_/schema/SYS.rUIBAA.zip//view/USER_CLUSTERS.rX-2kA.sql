create view USER_CLUSTERS as
select o.name, ts.name,
          mod(c.pctfree$, 100),
          decode(bitand(ts.flags, 32), 32, to_number(NULL), c.pctused$),
          c.size$,c.initrans,c.maxtrans,
          s.iniexts * ts.blocksize,
          decode(bitand(ts.flags, 3), 1, to_number(NULL),
                               s.extsize * ts.blocksize),
          s.minexts, s.maxexts,
          decode(bitand(ts.flags, 3), 1, to_number(NULL),
                                      s.extpct),
          decode(bitand(ts.flags, 32), 32, to_number(NULL),
             decode(s.lists, 0, 1, s.lists)),
          decode(bitand(ts.flags, 32), 32, to_number(NULL),
             decode(s.groups, 0, 1, s.groups)),
          c.avgchn, decode(c.hashkeys, 0, 'INDEX', 'HASH'),
          decode(c.hashkeys, 0, NULL,
                 decode(c.func, 0, 'COLUMN', 1, 'DEFAULT',
                                2, 'HASH EXPRESSION', 3, 'DEFAULT2', NULL)),
          c.hashkeys,
          lpad(decode(c.degree, 32767, 'DEFAULT', nvl(c.degree,1)),10),
          lpad(decode(c.instances, 32767, 'DEFAULT', nvl(c.instances,1)),10),
          lpad(decode(bitand(c.flags, 8), 8, 'Y', 'N'), 5),
          decode(s.cachehint, 0, 'DEFAULT', 1, 'KEEP', 2, 'RECYCLE', NULL),
          lpad(decode(bitand(c.flags, 65536), 65536, 'Y', 'N'), 5),
          decode(bitand(c.flags, 8388608), 8388608, 'ENABLED', 'DISABLED')
from sys.ts$ ts, sys.seg$ s, sys.clu$ c, sys.obj$ o
where o.owner# = userenv('SCHEMAID')
  and o.obj# = c.obj#
  and c.ts# = ts.ts#
  and c.ts# = s.ts#
  and c.file# = s.file#
  and c.block# = s.block#
/

comment on table USER_CLUSTERS is 'Descriptions of user''s own clusters'
/

comment on column USER_CLUSTERS.CLUSTER_NAME is 'Name of the cluster'
/

comment on column USER_CLUSTERS.TABLESPACE_NAME is 'Name of the tablespace containing the cluster'
/

comment on column USER_CLUSTERS.PCT_FREE is 'Minimum percentage of free space in a block'
/

comment on column USER_CLUSTERS.PCT_USED is 'Minimum percentage of used space in a block'
/

comment on column USER_CLUSTERS.KEY_SIZE is 'Estimated size of cluster key plus associated rows'
/

comment on column USER_CLUSTERS.INI_TRANS is 'Initial number of transactions'
/

comment on column USER_CLUSTERS.MAX_TRANS is 'Maximum number of transactions'
/

comment on column USER_CLUSTERS.INITIAL_EXTENT is 'Size of the initial extent in bytes'
/

comment on column USER_CLUSTERS.NEXT_EXTENT is 'Size of secondary extents in bytes'
/

comment on column USER_CLUSTERS.MIN_EXTENTS is 'Minimum number of extents allowed in the segment'
/

comment on column USER_CLUSTERS.MAX_EXTENTS is 'Maximum number of extents allowed in the segment'
/

comment on column USER_CLUSTERS.PCT_INCREASE is 'Percentage increase in extent size'
/

comment on column USER_CLUSTERS.FREELISTS is 'Number of process freelists allocated in this segment'
/

comment on column USER_CLUSTERS.FREELIST_GROUPS is 'Number of freelist groups allocated in this segment'
/

comment on column USER_CLUSTERS.AVG_BLOCKS_PER_KEY is 'Average number of blocks containing rows with a given cluster key'
/

comment on column USER_CLUSTERS.CLUSTER_TYPE is 'Type of cluster: b-tree index or hash'
/

comment on column USER_CLUSTERS.FUNCTION is 'If a hash cluster, the hash function'
/

comment on column USER_CLUSTERS.HASHKEYS is 'If a hash cluster, the number of hash keys (hash buckets)'
/

comment on column USER_CLUSTERS.DEGREE is 'The number of threads per instance for scanning the cluster'
/

comment on column USER_CLUSTERS.INSTANCES is 'The number of instances across which the cluster is to be scanned'
/

comment on column USER_CLUSTERS.CACHE is 'Whether the cluster is to be cached in the buffer cache'
/

comment on column USER_CLUSTERS.BUFFER_POOL is 'The default buffer pool to be used for cluster blocks'
/

comment on column USER_CLUSTERS.SINGLE_TABLE is 'Whether the cluster can contain only a single table'
/

comment on column USER_CLUSTERS.DEPENDENCIES is 'Should we keep track of row level dependencies?'
/

