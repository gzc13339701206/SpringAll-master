create view ALL_SOURCE_TABLES as
SELECT DISTINCT
   s.source_schema_name, s.source_table_name
  FROM sys.cdc_change_tables$ s, all_tables t
  WHERE s.change_table_schema=t.owner AND
        s.change_table_name=t.table_name
/

comment on table ALL_SOURCE_TABLES is 'Source tables available for Change Data Capture'
/

comment on column ALL_SOURCE_TABLES.SOURCE_SCHEMA_NAME is 'Schema of the source table'
/

comment on column ALL_SOURCE_TABLES.SOURCE_TABLE_NAME is 'Name of the source table'
/

