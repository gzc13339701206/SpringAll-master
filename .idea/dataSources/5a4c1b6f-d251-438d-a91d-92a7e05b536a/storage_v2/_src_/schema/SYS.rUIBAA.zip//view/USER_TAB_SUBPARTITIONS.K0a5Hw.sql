create view USER_TAB_SUBPARTITIONS as
select po.name, po.subname, so.subname,
       tsp.hiboundval, tsp.hiboundlen, tsp.subpart#,
       ts.name,  tsp.pctfree$,
       decode(bitand(ts.flags, 32), 32, to_number(NULL), tsp.pctused$),
       tsp.initrans, tsp.maxtrans,
       s.iniexts * ts.blocksize,
       decode(bitand(ts.flags, 3), 1, to_number(NULL),
                               s.extsize * ts.blocksize),
       s.minexts, s.maxexts,
       decode(bitand(ts.flags, 3), 1, to_number(NULL),
                                      s.extpct),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
           decode(s.lists, 0, 1, s.lists)),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
           decode(s.groups, 0, 1, s.groups)),
       decode(mod(trunc(tsp.flags / 4), 2), 0, 'YES', 'NO'),
       decode(bitand(s.spare1, 2048), 2048, 'ENABLED', 'DISABLED'),
       tsp.rowcnt, tsp.blkcnt, tsp.empcnt, tsp.avgspc, tsp.chncnt,
       tsp.avgrln, tsp.samplesize, tsp.analyzetime,
       decode(s.cachehint, 0, 'DEFAULT', 1, 'KEEP', 2, 'RECYCLE', NULL),
       decode(bitand(tsp.flags, 16), 0, 'NO', 'YES'),
       decode(bitand(tsp.flags, 8), 0, 'NO', 'YES')
from   sys.obj$ so, sys.obj$ po, sys.tabcompartv$ tcp, sys.tabsubpartv$ tsp,
       sys.tab$ t, sys.ts$ ts, sys.seg$ s
where  so.obj# = tsp.obj# and po.obj# = tsp.pobj# and tcp.obj# = tsp.pobj# and
       tcp.bo# = t.obj# and bitand(t.trigflag, 1073741824) != 1073741824 and
       tsp.ts# = ts.ts# and
       tsp.file# = s.file# and tsp.block# = s.block# and tsp.ts# = s.ts# and
       po.owner# = userenv('SCHEMAID') and so.owner# = userenv('SCHEMAID')
       and po.namespace = 1 and po.remoteowner IS NULL and po.linkname IS NULL
       and so.namespace = 1 and so.remoteowner IS NULL and so.linkname IS NULL
/

