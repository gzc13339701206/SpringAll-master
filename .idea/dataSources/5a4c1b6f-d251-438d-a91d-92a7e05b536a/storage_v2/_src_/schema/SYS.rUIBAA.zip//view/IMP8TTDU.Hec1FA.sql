create view IMP8TTDU as
SELECT  o$.name, u$.name, o$.oid$
        FROM    sys.obj$ o$, sys.user$ u$, sys.type$ t$
        WHERE   o$.type# = 13 AND
                o$.owner# = u$.user# AND
                o$.oid$   = t$.toid  AND
                t$.toid  = t$.tvoid AND                  /* Only the latest */
                (o$.owner# = UID OR                 /* owned by current user */
                /* current user or public role have execute access to type */
                 o$.obj# IN (
                    SELECT  oa.obj#
                    FROM    sys.objauth$ oa
                    WHERE   oa.obj# = o$.obj# AND
                            oa.privilege# = 12 AND                /* execute */
                            oa.grantee# IN (UID, 1)) OR
                 /* current user or public role can execute any type */
                 EXISTS (
                    SELECT  NULL
                    FROM    sys.sysauth$ sa
                    WHERE   sa.grantee# IN (UID, 1) AND
                            sa.privilege# = -184))
/

