create view USER_SYNONYMS as
select o.name, s.owner, s.name, s.node
from sys.syn$ s, sys.obj$ o
where o.obj# = s.obj#
  and o.type# = 5
  and o.owner# = userenv('SCHEMAID')
/

comment on table USER_SYNONYMS is 'The user''s private synonyms'
/

comment on column USER_SYNONYMS.SYNONYM_NAME is 'Name of the synonym'
/

comment on column USER_SYNONYMS.TABLE_OWNER is 'Owner of the object referenced by the synonym'
/

comment on column USER_SYNONYMS.TABLE_NAME is 'Name of the object referenced by the synonym'
/

comment on column USER_SYNONYMS.DB_LINK is 'Database link referenced in a remote synonym'
/

