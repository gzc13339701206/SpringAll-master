create view EXU81SLFCU as
SELECT  "MOWNER","MOWNERID","MASTER","COLNAME","OLDEST","FLAG"
        FROM    sys.exu81slfc
        WHERE   mownerid = UID
/

