create view ALL_ENCRYPTED_COLUMNS as
select u.name, o.name, c.name,
          case e.ENCALG when 1 then '3 Key Triple DES 168 bits key'
                        when 2 then 'AES 128 bits key'
                        when 3 then 'AES 192 bits key'
                        when 4 then 'AES 256 bits key'
                        else 'Internal Err'
          end,
          decode(bitand(c.property, 536870912), 0, 'YES', 'NO')
   from user$ u, obj$ o, col$ c, enc$ e
   where e.obj#=o.obj# and o.owner#=u.user# and bitand(flags, 128)=0 and
         e.obj#=c.obj# and bitand(c.property, 67108864) = 67108864 and
         (o.owner# = userenv('SCHEMAID')
          or
          e.obj# in (select obj# from sys.objauth$ where grantee# in
                        (select kzsrorol from x$kzsro))
          or
          exists (select null from v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */))
          )
/

comment on table ALL_ENCRYPTED_COLUMNS is 'Encryption information on all accessible columns'
/

comment on column ALL_ENCRYPTED_COLUMNS.OWNER is 'Owner of the table'
/

comment on column ALL_ENCRYPTED_COLUMNS.TABLE_NAME is 'Name of the table'
/

comment on column ALL_ENCRYPTED_COLUMNS.COLUMN_NAME is 'Name of the column'
/

comment on column ALL_ENCRYPTED_COLUMNS.ENCRYPTION_ALG is 'Encryption algorithm used for the column'
/

comment on column ALL_ENCRYPTED_COLUMNS.SALT is 'Is this column encrypted with salt? YES or NO'
/

