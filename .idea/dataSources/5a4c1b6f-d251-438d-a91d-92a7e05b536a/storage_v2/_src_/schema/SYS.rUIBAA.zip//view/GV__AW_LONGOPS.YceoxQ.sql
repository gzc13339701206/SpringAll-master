create view GV_$AW_LONGOPS as
select "INST_ID","SESSION_ID","CURSOR_NAME","COMMAND","STATUS","ROWS_PROCESSED","START_TIME" from gv$aw_longops
/

