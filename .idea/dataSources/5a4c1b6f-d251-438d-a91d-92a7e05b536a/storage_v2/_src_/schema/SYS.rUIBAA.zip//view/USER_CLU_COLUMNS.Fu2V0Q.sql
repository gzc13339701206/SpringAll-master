create view USER_CLU_COLUMNS as
select oc.name, cc.name, ot.name,
       decode(bitand(tc.property, 1), 1, ac.name, tc.name)
from sys.obj$ oc, sys.col$ cc, sys.obj$ ot, sys.col$ tc, sys.tab$ t,
     sys.attrcol$ ac
where oc.obj#    = cc.obj#
  and t.bobj#    = oc.obj#
  and t.obj#     = tc.obj#
  and tc.segcol# = cc.segcol#
  and t.obj#     = ot.obj#
  and oc.type#   = 3
  and oc.owner#  = userenv('SCHEMAID')
  and tc.obj#    = ac.obj#(+)
  and tc.intcol# = ac.intcol#(+)
/

comment on table USER_CLU_COLUMNS is 'Mapping of table columns to cluster columns'
/

comment on column USER_CLU_COLUMNS.CLUSTER_NAME is 'Cluster name'
/

comment on column USER_CLU_COLUMNS.CLU_COLUMN_NAME is 'Key column in the cluster'
/

comment on column USER_CLU_COLUMNS.TABLE_NAME is 'Clustered table name'
/

comment on column USER_CLU_COLUMNS.TAB_COLUMN_NAME is 'Key column or attribute of object column in the table'
/

