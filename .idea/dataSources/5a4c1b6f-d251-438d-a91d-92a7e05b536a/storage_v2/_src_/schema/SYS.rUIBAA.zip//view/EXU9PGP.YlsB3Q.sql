create view EXU9PGP as
SELECT  g.gname, u.name, o.name
        FROM    sys.rls_grp$ g, sys.user$ u, sys.obj$ o
        WHERE   g.obj# = o.obj# AND
                u.user# = o.owner# AND
                (UID IN (o.owner#, 0) OR
                 EXISTS (
                    SELECT  role
                    FROM    sys.session_roles
                    WHERE   role = 'SELECT_CATALOG_ROLE'))
/

