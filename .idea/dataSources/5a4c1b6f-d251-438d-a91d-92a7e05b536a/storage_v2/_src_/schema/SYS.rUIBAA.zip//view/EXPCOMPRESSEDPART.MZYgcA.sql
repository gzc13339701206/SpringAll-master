create view EXPCOMPRESSEDPART as
SELECT s.spare1, t.obj#
        FROM   sys.tabpart$ t, sys.seg$ s
        WHERE  t.ts#    = s.ts#
        AND    t.file#  = s.file#
        AND    t.block# = s.block#
        AND    s.type#  = 5
        AND    (bitand(s.spare1,4096) = 4096 OR bitand(s.spare1,2048) = 2048)
/

