create view EXU8FPTU as
  SELECT  o.name, u.name, o.owner#, t.toid,
                TO_CHAR(o.mtime, 'YYYY-MM-DD:HH24:MI:SS'), o.obj#, d.d_obj#,
                tm.audit$, sv.sql_version, t.properties,
                o.status, t.version#, t.hashcode, t.typeid,
                NVL(t.roottoid,HEXTORAW('00'))
        FROM    sys.obj$ o, sys.user$ u, sys.type$ t, sys.dependency$ d,
                sys.type_misc$ tm, sys.exu816sqv sv
        WHERE   o.obj# = d.p_obj# AND
                o.type# = 13 AND
                o.oid$ = t.toid AND
                o.owner# = u.user# AND
                o.obj# = tm.obj# AND
                BITAND(t.properties, 2128) = 0 AND /* skip system gen'd types*/
                (o.owner# = UID OR                  /* owned by current user */
                /* current user or public role have execute access to type */
                o.obj# IN (
                    SELECT  oa.obj#
                    FROM    sys.objauth$ oa
                    WHERE   oa.obj# = o.obj# AND
                            oa.privilege# = 12 AND                /* execute */
                            oa.grantee# IN (UID, 1)) OR
                EXISTS ( /* current user or public role can execute any type */
                    SELECT  NULL
                    FROM    sys.sysauth$ sa
                    WHERE   sa.grantee# IN (UID, 1) AND
                            sa.privilege# = -184)) AND
                o.spare1 = sv.version# (+) AND
                t.toid   = t.tvoid                   /* Only the latest type */
     UNION
        SELECT  o.name, u.name, o.owner#, t.toid,
                TO_CHAR(o.mtime,  'YYYY-MM-DD:HH24:MI:SS'), o.obj#, so.obj#,
                tm.audit$, sv.sql_version, t.properties,
                o.status, t.version#, t.hashcode, t.typeid,
                NVL(t.roottoid,HEXTORAW('00'))
        FROM    sys.obj$ o, sys.user$ u, sys.type$ t, sys.obj$ so,
                sys.type_misc$ tm, sys.exu816sqv sv
        WHERE   o.type# = 13 AND
                o.oid$ = t.toid AND
                o.owner# = u.user# AND
                so.oid$ = t.roottoid AND
                o.obj# = tm.obj# AND
                BITAND(t.properties, 2128) = 0 AND /* skip system gen'd types*/
                (o.owner# = UID OR                  /* owned by current user */
                /* current user or public role have execute access to type */
                o.obj# IN (
                        SELECT  oa.obj#
                        FROM    sys.objauth$ oa
                        WHERE   oa.obj# = o.obj# AND
                                oa.privilege# = 12 AND            /* execute */
                                (oa.grantee# = UID OR
                                 oa.grantee# = 1)) OR
                /* current user or public role can execute any type */
                EXISTS (
                        SELECT  NULL
                        FROM    sys.sysauth$ sa
                        WHERE   (sa.grantee# = UID OR
                                 sa.grantee# = 1) AND
                                sa.privilege# = -184 )) AND
                o.spare1 = sv.version# (+)  AND
                t.toid   = t.tvoid                   /* Only the latest type */

