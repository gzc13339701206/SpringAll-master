create view EXU8SLOGU as
SELECT  "MOWNER","MOWNERID","MASTER","SNAPID","SNAPTIME"
        FROM    sys.exu8slog
        WHERE   mownerid = UID
/

