create view USER_SECONDARY_OBJECTS as
select u.name, o.name, u1.name, o1.name
from   sys.user$ u, sys.obj$ o, sys.user$ u1, sys.obj$ o1, sys.secobj$ s
where  s.obj# = o.obj# and o.owner# = u.user# and
       s.secobj# = o1.obj#  and  o1.owner# = u1.user# and
       o.owner# = userenv('SCHEMAID')
/

comment on table USER_SECONDARY_OBJECTS is 'All secondary objects for domain indexes'
/

comment on column USER_SECONDARY_OBJECTS.INDEX_OWNER is 'Name of the domain index owner'
/

comment on column USER_SECONDARY_OBJECTS.INDEX_NAME is 'Name of the domain index'
/

comment on column USER_SECONDARY_OBJECTS.SECONDARY_OBJECT_OWNER is 'Owner of the secondary object'
/

comment on column USER_SECONDARY_OBJECTS.SECONDARY_OBJECT_NAME is 'Name of the secondary object'
/

