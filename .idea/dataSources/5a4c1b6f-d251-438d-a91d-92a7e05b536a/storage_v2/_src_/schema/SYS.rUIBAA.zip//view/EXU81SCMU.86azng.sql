create view EXU81SCMU as
SELECT  "SOWNER","SOWNERID","VNAME","TABNUM","SNACOL","MASCOL","MASPOS","ROLE","INSTSITE","SNAPOS"
        FROM    sys.exu81scm
        WHERE   sownerid = UID
/

