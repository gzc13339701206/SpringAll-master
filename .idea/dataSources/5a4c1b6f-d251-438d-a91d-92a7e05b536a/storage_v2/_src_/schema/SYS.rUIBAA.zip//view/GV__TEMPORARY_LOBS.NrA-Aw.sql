create view GV_$TEMPORARY_LOBS as
select "INST_ID","SID","CACHE_LOBS","NOCACHE_LOBS","ABSTRACT_LOBS" from gv$temporary_lobs
/

