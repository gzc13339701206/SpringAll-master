create view USER_TAB_COL_STATISTICS as
  select table_name, column_name, num_distinct, low_value, high_value,
       density, num_nulls, num_buckets, last_analyzed, sample_size,
       global_stats, user_stats, avg_col_len, HISTOGRAM
from user_tab_columns
where last_analyzed is not null
union all
select /* fixed table column stats */
       ft.kqftanam, c.kqfconam,
       h.distcnt, h.lowval, h.hival,
       h.density, h.null_cnt,
       case when nvl(h.distcnt,0) = 0 then h.distcnt
            when h.row_cnt = 0 then 1
	    when (h.bucket_cnt > 255
                  or
                  (h.bucket_cnt > h.distcnt
                   and h.row_cnt = h.distcnt
                   and h.density*h.bucket_cnt*2 <= 1))
                then h.row_cnt
            else h.bucket_cnt
       end,
       h.timestamp#, h.sample_size,
       decode(bitand(h.spare2, 2), 2, 'YES', 'NO'),
       decode(bitand(h.spare2, 1), 1, 'YES', 'NO'),
       h.avgcln,
       case when nvl(h.row_cnt,0) = 0 then 'NONE'
            when (h.bucket_cnt > 255
                  or
                  (h.bucket_cnt > h.distcnt and h.row_cnt = h.distcnt
                   and h.density*h.bucket_cnt*2 <= 1))
                then 'FREQUENCY'
            else 'HEIGHT BALANCED'
       end
from   sys.x$kqfta ft, sys.fixed_obj$ fobj,
         sys.x$kqfco c, sys.hist_head$ h
where
       ft.kqftaobj = fobj. obj#
       and c.kqfcotob = ft.kqftaobj
       and h.obj# = ft.kqftaobj
       and h.intcol# = c.kqfcocno
       /*
        * if fobj and st are not in sync (happens when db open read only
        * after upgrade), do not display stats.
        */
       and ft.kqftaver =
             fobj.timestamp - to_date('01-01-1991', 'DD-MM-YYYY')
       and h.timestamp# is not null
       and userenv('SCHEMAID') = 0  /* SYS */

comment on table USER_TAB_COL_STATISTICS is 'Columns of user''s tables, views and clusters'
/

comment on column USER_TAB_COL_STATISTICS.TABLE_NAME is 'Table, view or cluster name'
/

comment on column USER_TAB_COL_STATISTICS.COLUMN_NAME is 'Column name'
/

comment on column USER_TAB_COL_STATISTICS.NUM_DISTINCT is 'The number of distinct values in the column'
/

comment on column USER_TAB_COL_STATISTICS.LOW_VALUE is 'The low value in the column'
/

comment on column USER_TAB_COL_STATISTICS.HIGH_VALUE is 'The high value in the column'
/

comment on column USER_TAB_COL_STATISTICS.DENSITY is 'The density of the column'
/

comment on column USER_TAB_COL_STATISTICS.NUM_NULLS is 'The number of nulls in the column'
/

comment on column USER_TAB_COL_STATISTICS.NUM_BUCKETS is 'The number of buckets in histogram for the column'
/

comment on column USER_TAB_COL_STATISTICS.LAST_ANALYZED is 'The date of the most recent time this column was analyzed'
/

comment on column USER_TAB_COL_STATISTICS.SAMPLE_SIZE is 'The sample size used in analyzing this column'
/

comment on column USER_TAB_COL_STATISTICS.GLOBAL_STATS is 'Are the statistics calculated without merging underlying partitions?'
/

comment on column USER_TAB_COL_STATISTICS.USER_STATS is 'Were the statistics entered directly by the user?'
/

comment on column USER_TAB_COL_STATISTICS.AVG_COL_LEN is 'The average length of the column in bytes'
/

