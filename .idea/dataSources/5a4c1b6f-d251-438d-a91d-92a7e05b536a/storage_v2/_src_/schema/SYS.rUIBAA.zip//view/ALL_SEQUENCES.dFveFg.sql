create view ALL_SEQUENCES as
select u.name, o.name,
      s.minvalue, s.maxvalue, s.increment$,
      decode (s.cycle#, 0, 'N', 1, 'Y'),
      decode (s.order$, 0, 'N', 1, 'Y'),
      s.cache, s.highwater
from sys.seq$ s, sys.obj$ o, sys.user$ u
where u.user# = o.owner#
  and o.obj# = s.obj#
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
        or
         exists (select null from v$enabledprivs
                 where priv_number = -109 /* SELECT ANY SEQUENCE */
                 )
      )
/

comment on table ALL_SEQUENCES is 'Description of SEQUENCEs accessible to the user'
/

comment on column ALL_SEQUENCES.SEQUENCE_OWNER is 'Name of the owner of the sequence'
/

comment on column ALL_SEQUENCES.SEQUENCE_NAME is 'SEQUENCE name'
/

comment on column ALL_SEQUENCES.MIN_VALUE is 'Minimum value of the sequence'
/

comment on column ALL_SEQUENCES.MAX_VALUE is 'Maximum value of the sequence'
/

comment on column ALL_SEQUENCES.INCREMENT_BY is 'Value by which sequence is incremented'
/

comment on column ALL_SEQUENCES.CYCLE_FLAG is 'Does sequence wrap around on reaching limit?'
/

comment on column ALL_SEQUENCES.ORDER_FLAG is 'Are sequence numbers generated in order?'
/

comment on column ALL_SEQUENCES.CACHE_SIZE is 'Number of sequence numbers to cache'
/

comment on column ALL_SEQUENCES.LAST_NUMBER is 'Last sequence number written to disk'
/

