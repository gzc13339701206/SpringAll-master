create view USER_PLSQL_OBJECT_SETTINGS as
select o.name,
decode(o.type#, 7, 'PROCEDURE', 8, 'FUNCTION', 9, 'PACKAGE',
                11, 'PACKAGE BODY', 12, 'TRIGGER',
                13, 'TYPE', 14, 'TYPE BODY', 'UNDEFINED'),
(select to_number(value) from settings$ s
  where s.obj# = o.obj# and param = 'plsql_optimize_level'),
(select value from settings$ s
  where s.obj# = o.obj# and param = 'plsql_code_type'),
(select value from settings$ s
  where s.obj# = o.obj# and param = 'plsql_debug'),
(select value from settings$ s
  where s.obj# = o.obj# and param = 'plsql_warnings'),
(select value from settings$ s
  where s.obj# = o.obj# and param = 'nls_length_semantics'),
(select value from settings$ s
  where s.obj# = o.obj# and param = 'plsql_ccflags')
from sys.obj$ o
where o.owner# = userenv('SCHEMAID')
  and o.type# in (7, 8, 9, 11, 12, 13, 14)
/

comment on table USER_PLSQL_OBJECT_SETTINGS is 'Compiler settings of stored objects owned by the user'
/

comment on column USER_PLSQL_OBJECT_SETTINGS.NAME is 'Name of the object'
/

comment on column USER_PLSQL_OBJECT_SETTINGS.TYPE is 'Type of the object: "PROCEDURE", "FUNCTION",
"PACKAGE", "PACKAGE BODY", "TRIGGER", "TYPE" or "TYPE BODY"'
/

comment on column USER_PLSQL_OBJECT_SETTINGS.PLSQL_OPTIMIZE_LEVEL is 'The optimization level to use to compile the object'
/

comment on column USER_PLSQL_OBJECT_SETTINGS.PLSQL_CODE_TYPE is 'The object codes are to be compiled natively or are interpreted'
/

comment on column USER_PLSQL_OBJECT_SETTINGS.PLSQL_DEBUG is 'The object is to be compiled with debug information or not'
/

comment on column USER_PLSQL_OBJECT_SETTINGS.PLSQL_WARNINGS is 'The compiler warning settings to use to compile the object'
/

comment on column USER_PLSQL_OBJECT_SETTINGS.NLS_LENGTH_SEMANTICS is 'The NLS length semantics to use to compile the object'
/

comment on column USER_PLSQL_OBJECT_SETTINGS.PLSQL_CCFLAGS is 'The conditional compilation flag settings to use to compile the object'
/

