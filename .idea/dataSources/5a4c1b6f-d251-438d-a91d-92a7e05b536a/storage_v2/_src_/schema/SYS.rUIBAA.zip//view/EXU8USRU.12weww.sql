create view EXU8USRU as
SELECT  "NAME","USERID","PASSWD","DEFROLE","DATATS","TEMPTS","PROFILE#","PROFNAME","ASTATUS","EXT_USERNAME"
        FROM    sys.exu8usr
        WHERE   userid = UID
/

