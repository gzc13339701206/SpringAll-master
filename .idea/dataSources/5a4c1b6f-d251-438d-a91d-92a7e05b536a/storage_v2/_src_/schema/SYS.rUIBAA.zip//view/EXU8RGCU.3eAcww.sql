create view EXU8RGCU as
SELECT  "OWNER","OWNERID","CHILD","TYPE","REFGROUP"
        FROM    sys.exu8rgc
        WHERE   UID = ownerid
/

