create view EXU8LIBU as
SELECT  "LOWNER","LIBNAME","OWNERID","FILENAME","AUDIT$","MTIME","OBJNO","ISSTATIC","ISTRUSTED"
        FROM    sys.exu8lib
        WHERE   ownerid = UID
/

