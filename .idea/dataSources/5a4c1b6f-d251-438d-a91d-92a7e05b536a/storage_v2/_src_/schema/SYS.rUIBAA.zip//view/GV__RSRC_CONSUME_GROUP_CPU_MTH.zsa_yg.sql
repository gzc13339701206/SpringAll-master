create view GV_$RSRC_CONSUME_GROUP_CPU_MTH as
select "INST_ID","NAME" from gv$rsrc_consumer_group_cpu_mth
/

