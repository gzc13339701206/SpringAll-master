create view EXU8CCOU as
SELECT  "TNAME","TOWNER","TOWNERID","CLUSTER$","TCOLNAM","SEQ","PROPERTY"
        FROM    sys.exu8cco
        WHERE   townerid = UID
/

