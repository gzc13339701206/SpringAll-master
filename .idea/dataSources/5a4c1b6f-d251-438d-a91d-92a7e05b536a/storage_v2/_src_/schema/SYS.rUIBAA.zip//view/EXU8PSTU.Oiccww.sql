create view EXU8PSTU as
SELECT  "OWNER","OWNERID","TNAME","TOBJID","CALLORDER","CALLARG","OBJTYPE","USRARG","PROPERTY"
        FROM    sys.exu8pst
        WHERE   ownerid = UID
/

