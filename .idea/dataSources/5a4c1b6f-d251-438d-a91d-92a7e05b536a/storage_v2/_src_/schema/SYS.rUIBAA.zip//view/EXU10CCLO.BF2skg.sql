create view EXU10CCLO as
SELECT  a.ownerid, a.cno, a.colname, a.colno, a.property, a.nolog
        FROM    sys.exu10ccl a, sys.con$ b , sys.cdef$ c
        WHERE   b.owner# = UID AND
                b.con# = c.con# AND
                c.rcon# = a.cno
/

