create view USER_VARRAYS as
  select distinct op.name, ac.name,
       nvl2(ct.synobj#, (select u.name from user$ u, obj$ o
            where o.owner#=u.user# and o.obj#=ct.synobj#), ut.name),
       nvl2(ct.synobj#, (select o.name from obj$ o
            where o.obj#=ct.synobj#), ot.name),
       NULL,
       lpad(decode(bitand(ct.flags, 64), 64, 'USER_SPECIFIED', 'DEFAULT'), 30),
       lpad(decode(bitand(ct.flags, 32), 32, 'LOCATOR', 'VALUE'), 20),
       lpad((case when bitand(ct.flags, 5120)=0 and bitand(t.properties, 8)= 8
       then 'Y' else 'N' end), 25)
from sys.obj$ op, sys.obj$ ot, sys.col$ c, sys.coltype$ ct, sys.user$ u,
  sys.user$ ut, sys.attrcol$ ac, sys.type$ t, sys.collection$ cl
where op.owner# = userenv('SCHEMAID')
  and c.obj# = op.obj#
  and c.obj# = ac.obj#
  and c.intcol# = ac.intcol#
  and op.obj# = ct.obj#
  and ct.toid = ot.oid$
  and ct.intcol# = c.intcol#
  and ot.owner# = ut.user#
  and ct.toid=cl.toid
  and cl.elem_toid=t.tvoid
  and bitand(ct.flags,8) = 8
  and bitand(c.property, 128) != 128
  and bitand(c.property,32768) != 32768           /* not unused column */
union all
select distinct op.name, ac.name,
       nvl2(ct.synobj#, (select u.name from user$ u, obj$ o
            where o.owner#=u.user# and o.obj#=ct.synobj#), ut.name),
       nvl2(ct.synobj#, (select o.name from obj$ o
            where o.obj#=ct.synobj#), ot.name),
       o.name,
       lpad(decode(bitand(ct.flags, 64), 64, 'USER_SPECIFIED', 'DEFAULT'), 30),
       lpad(decode(bitand(ct.flags, 32), 32, 'LOCATOR', 'VALUE'), 20),
       lpad((case when bitand(ct.flags, 5120)=0 and bitand(t.properties, 8)= 8
       then 'Y' else 'N' end), 25)
from sys.lob$ l, sys.obj$ o, sys.obj$ op, sys.obj$ ot, sys.col$ c,
  sys.coltype$ ct, sys.user$ u, sys.user$ ut, sys.attrcol$ ac, sys.type$ t,
  sys.collection$ cl
where o.owner# = userenv('SCHEMAID')
  and l.obj# = op.obj#
  and l.lobj# = o.obj#
  and c.obj# = op.obj#
  and l.intcol# = c.intcol#
  and c.obj# = ac.obj#
  and c.intcol# = ac.intcol#
  and op.obj# = ct.obj#
  and ct.toid = ot.oid$
  and ct.intcol#=l.intcol#
  and ot.owner# = ut.user#
  and ct.toid=cl.toid
  and cl.elem_toid=t.tvoid
  and bitand(ct.flags,8) = 8
  and bitand(c.property, 128) = 128
  and bitand(c.property,32768) != 32768           /* not unused column */
union all
select op.name, c.name,
       nvl2(ct.synobj#, (select u.name from user$ u, obj$ o
            where o.owner#=u.user# and o.obj#=ct.synobj#), ut.name),
       nvl2(ct.synobj#, (select o.name from obj$ o
            where o.obj#=ct.synobj#), ot.name),
       NULL,
       lpad(decode(bitand(ct.flags, 64), 64, 'USER_SPECIFIED', 'DEFAULT'), 30),
       lpad(decode(bitand(ct.flags, 32), 32, 'LOCATOR', 'VALUE'), 20),
       lpad((case when bitand(ct.flags, 5120)=0 and bitand(t.properties, 8)= 8
       then 'Y' else 'N' end), 25)
from sys.obj$ op, sys.obj$ ot, sys.col$ c, sys.coltype$ ct, sys.user$ ut,
  sys.type$ t, sys.collection$ cl
where op.owner# = userenv('SCHEMAID')
  and c.obj# = op.obj#
  and bitand(c.property,1)=0
  and op.obj# = ct.obj#
  and ct.toid = ot.oid$
  and ct.intcol# = c.intcol#
  and ot.owner# = ut.user#
  and ct.toid=cl.toid
  and cl.elem_toid=t.tvoid
  and bitand(ct.flags,8)=8
  and bitand(c.property, 128) != 128
  and bitand(c.property,32768) != 32768           /* not unused column */
union all
select op.name, c.name,
       nvl2(ct.synobj#, (select u.name from user$ u, obj$ o
            where o.owner#=u.user# and o.obj#=ct.synobj#), ut.name),
       nvl2(ct.synobj#, (select o.name from obj$ o
            where o.obj#=ct.synobj#), ot.name),
       o.name,
       lpad(decode(bitand(ct.flags, 64), 64, 'USER_SPECIFIED', 'DEFAULT'), 30),
       lpad(decode(bitand(ct.flags, 32), 32, 'LOCATOR', 'VALUE'), 20),
       lpad((case when bitand(ct.flags, 5120)=0 and bitand(t.properties, 8)= 8
       then 'Y' else 'N' end), 25)
from sys.lob$ l, sys.obj$ o, sys.obj$ op, sys.obj$ ot,
  sys.col$ c, sys.coltype$ ct, sys.user$ ut, sys.type$ t, sys.collection$ cl
where o.owner# = userenv('SCHEMAID')
  and l.obj# = op.obj#
  and l.lobj# = o.obj#
  and c.obj# = op.obj#
  and l.intcol# = c.intcol#
  and bitand(c.property,1)=0
  and op.obj# = ct.obj#
  and ct.toid = ot.oid$
  and ct.intcol#=l.intcol#
  and ot.owner# = ut.user#
  and ct.toid=cl.toid
  and cl.elem_toid=t.tvoid
  and bitand(ct.flags,8)=8
  and bitand(c.property, 128) = 128
  and bitand(c.property,32768) != 32768           /* not unused column */

comment on table USER_VARRAYS is 'Description of varrays contained in the user''s own tables'
/

comment on column USER_VARRAYS.PARENT_TABLE_NAME is 'Name of the parent table containing the varray'
/

comment on column USER_VARRAYS.PARENT_TABLE_COLUMN is 'Column name of the parent table that corresponds to the varray'
/

comment on column USER_VARRAYS.TYPE_OWNER is 'Owner of the type of which the varray was created'
/

comment on column USER_VARRAYS.TYPE_NAME is 'Name of the type of the varray'
/

comment on column USER_VARRAYS.LOB_NAME is 'Name of the lob if varray is stored in a lob'
/

comment on column USER_VARRAYS.STORAGE_SPEC is 'Indication of default or user-specified storage for the varray'
/

comment on column USER_VARRAYS.RETURN_TYPE is 'Return type of the varray column locator or value'
/

comment on column USER_VARRAYS.ELEMENT_SUBSTITUTABLE is 'Indication of whether the varray element is substitutable or not'
/

