create view INDEX_STATS as
  select kdxstrot+1      height,
        kdxstsbk        blocks,
        o.name,
        o.subname       partition_name,
        kdxstlrw        lf_rows,
        kdxstlbk        lf_blks,
        kdxstlln        lf_rows_len,
        kdxstlub        lf_blk_len,
        kdxstbrw        br_rows,
        kdxstbbk        br_blks,
        kdxstbln        br_rows_len,
        kdxstbub        br_blk_len,
        kdxstdrw        del_lf_rows,
        kdxstdln        del_lf_rows_len,
        kdxstdis        distinct_keys,
        kdxstmrl        most_repeated_key,
        kdxstlbk*kdxstlub+kdxstbbk*kdxstbub     btree_space,
        kdxstlln+kdxstbln+kdxstpln              used_space,
        ceil(((kdxstlln+kdxstbln+kdxstpln)*100)/
        (kdxstlbk*kdxstlub+kdxstbbk*kdxstbub))
                                                pct_used,
        kdxstlrw/decode(kdxstdis, 0, 1, kdxstdis) rows_per_key,
        kdxstrot+1+(kdxstlrw+kdxstdis)/(decode(kdxstdis, 0, 1, kdxstdis)*2)
                                                blks_gets_per_access,
        kdxstnpr        pre_rows,
        kdxstpln        pre_rows_len,
        kdxstokc        opt_cmpr_count,
        kdxstpsk        opt_cmpr_pctsave
  from obj$ o, ind$ i, seg$ s, x$kdxst
 where kdxstobj = o.obj# and kdxstfil = s.file#
  and  kdxstblk = s.block#
  and  kdxsttsn = s.ts#
  and  s.file#  = i.file#
  and  s.block# = i.block#
  and  s.ts# = i.ts#
  and  i.obj#   = o.obj#
union all
 select kdxstrot+1      height,
        kdxstsbk        blocks,
        o.name,
        o.subname       partition_name,
        kdxstlrw        lf_rows,
        kdxstlbk        lf_blks,
        kdxstlln        lf_rows_len,
        kdxstlub        lf_blk_len,
        kdxstbrw        br_rows,
        kdxstbbk        br_blks,
        kdxstbln        br_rows_len,
        kdxstbub        br_blk_len,
        kdxstdrw        del_lf_rows,
        kdxstdln        del_lf_rows_len,
        kdxstdis        distinct_keys,
        kdxstmrl        most_repeated_key,
        kdxstlbk*kdxstlub+kdxstbbk*kdxstbub     btree_space,
        kdxstlln+kdxstbln+kdxstpln              used_space,
        ceil(((kdxstlln+kdxstbln)*100)/
        (kdxstlbk*kdxstlub+kdxstbbk*kdxstbub))
                                                pct_used,
        kdxstlrw/decode(kdxstdis, 0, 1, kdxstdis) rows_per_key,
        kdxstrot+1+(kdxstlrw+kdxstdis)/(decode(kdxstdis, 0, 1, kdxstdis)*2)
                                                blks_gets_per_access,
        kdxstnpr        pre_rows,
        kdxstpln        pre_rows_len,
        kdxstokc        opt_cmpr_count,
        kdxstpsk        opt_cmpr_pctsave
  from obj$ o, seg$ s, indpart$ ip, x$kdxst
 where kdxstobj = o.obj# and kdxstfil = s.file#
  and  kdxstblk = s.block#
  and  kdxsttsn = s.ts#
  and  s.file#  = ip.file#
  and  s.block# = ip.block#
  and  s.ts#    = ip.ts#
  and  ip.obj#  = o.obj#
union all
 select kdxstrot+1      height,
        kdxstsbk        blocks,
        o.name,
        o.subname       partition_name,
        kdxstlrw        lf_rows,
        kdxstlbk        lf_blks,
        kdxstlln        lf_rows_len,
        kdxstlub        lf_blk_len,
        kdxstbrw        br_rows,
        kdxstbbk        br_blks,
        kdxstbln        br_rows_len,
        kdxstbub        br_blk_len,
        kdxstdrw        del_lf_rows,
        kdxstdln        del_lf_rows_len,
        kdxstdis        distinct_keys,
        kdxstmrl        most_repeated_key,
        kdxstlbk*kdxstlub+kdxstbbk*kdxstbub     btree_space,
        kdxstlln+kdxstbln+kdxstpln              used_space,
        ceil(((kdxstlln+kdxstbln)*100)/
        (kdxstlbk*kdxstlub+kdxstbbk*kdxstbub))
                                                pct_used,
        kdxstlrw/decode(kdxstdis, 0, 1, kdxstdis) rows_per_key,
        kdxstrot+1+(kdxstlrw+kdxstdis)/(decode(kdxstdis, 0, 1, kdxstdis)*2)
                                                blks_gets_per_access,
        kdxstnpr        pre_rows,
        kdxstpln        pre_rows_len,
        kdxstokc        opt_cmpr_count,
        kdxstpsk        opt_cmpr_pctsave
  from obj$ o, seg$ s, indsubpart$ isp, x$kdxst
 where kdxstobj = o.obj# and kdxstfil = s.file#
  and  kdxstblk = s.block#
  and  kdxsttsn = s.ts#
  and  s.file#  = isp.file#
  and  s.block# = isp.block#
  and  s.ts#    = isp.ts#
  and  isp.obj#  = o.obj#
/

comment on table INDEX_STATS is 'statistics on the b-tree'
/

comment on column INDEX_STATS.HEIGHT is 'height of the b-tree'
/

comment on column INDEX_STATS.BLOCKS is 'blocks allocated to the segment'
/

comment on column INDEX_STATS.NAME is 'name of the index'
/

comment on column INDEX_STATS.PARTITION_NAME is 'name of the index partition, if partitioned'
/

comment on column INDEX_STATS.LF_ROWS is 'number of leaf rows (values in the index)'
/

comment on column INDEX_STATS.LF_BLKS is 'number of leaf blocks in the b-tree'
/

comment on column INDEX_STATS.LF_ROWS_LEN is 'sum of the lengths of all the leaf rows'
/

comment on column INDEX_STATS.LF_BLK_LEN is 'useable space in a leaf block'
/

comment on column INDEX_STATS.BR_ROWS is 'number of branch rows'
/

comment on column INDEX_STATS.BR_BLKS is 'number of branch blocks in the b-tree'
/

comment on column INDEX_STATS.BR_ROWS_LEN is 'sum of the lengths of all the branch blocks in the b-tree'
/

comment on column INDEX_STATS.BR_BLK_LEN is 'useable space in a branch block'
/

comment on column INDEX_STATS.DEL_LF_ROWS is 'number of deleted leaf rows in the index'
/

comment on column INDEX_STATS.DEL_LF_ROWS_LEN is 'total length of all deleted rows in the index'
/

comment on column INDEX_STATS.DISTINCT_KEYS is 'number of distinct keys in the index'
/

comment on column INDEX_STATS.MOST_REPEATED_KEY is 'how many times the most repeated key is repeated'
/

comment on column INDEX_STATS.BTREE_SPACE is 'total space currently allocated in the b-tree'
/

comment on column INDEX_STATS.USED_SPACE is 'total space that is currently being used in the b-tree'
/

comment on column INDEX_STATS.PCT_USED is 'percent of space allocated in the b-tree that is being used'
/

comment on column INDEX_STATS.ROWS_PER_KEY is 'average number of rows per distinct key'
/

comment on column INDEX_STATS.BLKS_GETS_PER_ACCESS is 'Expected number of consistent mode block gets per row. This assumes that a row chosen at random from the table is being searched for using the index'
/

comment on column INDEX_STATS.PRE_ROWS is 'number of prefix rows (values in the index)'
/

comment on column INDEX_STATS.PRE_ROWS_LEN is 'sum of lengths of all prefix rows'
/

comment on column INDEX_STATS.OPT_CMPR_COUNT is 'optimal prefix compression count for the index'
/

comment on column INDEX_STATS.OPT_CMPR_PCTSAVE is 'percentage storage saving expected from optimal prefix compression'
/

