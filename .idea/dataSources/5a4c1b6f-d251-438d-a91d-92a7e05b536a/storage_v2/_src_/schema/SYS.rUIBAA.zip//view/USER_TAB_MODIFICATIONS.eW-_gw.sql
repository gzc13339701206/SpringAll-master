create view USER_TAB_MODIFICATIONS as
  select o.name, null, null,
       m.inserts, m.updates, m.deletes, m.timestamp,
       decode(bitand(m.flags,1),1,'YES','NO'),
       m.drop_segments
from sys.mon_mods_all$ m, sys.obj$ o, sys.tab$ t
where o.owner# = userenv('SCHEMAID') and o.obj# = m.obj# and o.obj# = t.obj#
union all
  select o.name, o.subname, null,
       m.inserts, m.updates, m.deletes, m.timestamp,
       decode(bitand(m.flags,1),1,'YES','NO'),
       m.drop_segments
  from sys.mon_mods_all$ m, sys.obj$ o
  where o.owner# = userenv('SCHEMAID') and o.obj# = m.obj# and o.type#=19
union all
select o.name, o2.subname, o.subname,
       m.inserts, m.updates, m.deletes, m.timestamp,
       decode(bitand(m.flags,1),1,'YES','NO'),
       m.drop_segments
from sys.mon_mods_all$ m, sys.obj$ o, sys.tabsubpart$ tsp, sys.obj$ o2
where o.owner# = userenv('SCHEMAID') and o.obj# = m.obj# and
      o.obj# = tsp.obj# and o2.obj# = tsp.pobj#
/

comment on table USER_TAB_MODIFICATIONS is 'Information regarding modifications to tables'
/

comment on column USER_TAB_MODIFICATIONS.TABLE_NAME is 'Modified table'
/

comment on column USER_TAB_MODIFICATIONS.PARTITION_NAME is 'Modified partition'
/

comment on column USER_TAB_MODIFICATIONS.SUBPARTITION_NAME is 'Modified subpartition'
/

comment on column USER_TAB_MODIFICATIONS.INSERTS is 'Approximate number of rows inserted since last analyze'
/

comment on column USER_TAB_MODIFICATIONS.UPDATES is 'Approximate number of rows updated since last analyze'
/

comment on column USER_TAB_MODIFICATIONS.DELETES is 'Approximate number of rows deleted since last analyze'
/

comment on column USER_TAB_MODIFICATIONS.TIMESTAMP is 'Timestamp of last time this row was modified'
/

comment on column USER_TAB_MODIFICATIONS.TRUNCATED is 'Was this object truncated since the last analyze?'
/

comment on column USER_TAB_MODIFICATIONS.DROP_SEGMENTS is 'Number of (sub)partition segment dropped since the last analyze?'
/

