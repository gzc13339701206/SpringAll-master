create view EXU81RGCU as
SELECT  "OWNER","OWNERID","CHILD","TYPE","REFGROUP","INSTSITE"
        FROM    sys.exu81rgc
        WHERE   UID = ownerid
/

