create view ALL_COL_COMMENTS as
select u.name, o.name, c.name, co.comment$
from sys.obj$ o, sys.col$ c, sys.user$ u, sys.com$ co
where o.owner# = u.user#
  and o.type# in (2, 4, 5)
  and o.obj# = c.obj#
  and c.obj# = co.obj#(+)
  and c.intcol# = co.col#(+)
  and bitand(c.property, 32) = 0 /* not hidden column */
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
         (select obj#
          from sys.objauth$
          where grantee# in ( select kzsrorol
                              from x$kzsro
                            )
          )
       or
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */))
      )
/

comment on table ALL_COL_COMMENTS is 'Comments on columns of accessible tables and views'
/

comment on column ALL_COL_COMMENTS.OWNER is 'Owner of the object'
/

comment on column ALL_COL_COMMENTS.TABLE_NAME is 'Name of the object'
/

comment on column ALL_COL_COMMENTS.COLUMN_NAME is 'Name of the column'
/

comment on column ALL_COL_COMMENTS.COMMENTS is 'Comment on the column'
/

