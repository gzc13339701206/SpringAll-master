create view EXU81ITYU as
SELECT  "NAME","OBJID","OWNER","OWNERID"
        FROM    sys.exu81ity
        WHERE   ownerid = UID
/

