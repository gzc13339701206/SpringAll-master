create view EXU8DIMU as
SELECT  "OWNERID","OWNER","DIMNAME","DIMTEXT"
        FROM    sys.exu8dim
/

