create view ALL_UPDATABLE_COLUMNS as
select u.name, o.name, c.name,
       decode(bitand(c.fixedstorage,2),
              2, decode(bitand(v.flags,8192), 8192, 'YES', 'NO'),
              decode(bitand(c.property,4096),4096,'NO','YES')),
       decode(bitand(c.fixedstorage,2),
              2, decode(bitand(v.flags,4096), 4096, 'YES', 'NO'),
              decode(bitand(c.property,2048),2048,'NO','YES')),
       decode(bitand(c.fixedstorage,2),
              2, decode(bitand(v.flags,16384), 16384, 'YES', 'NO'),
              decode(bitand(c.property,8192),8192,'NO','YES'))
from sys.obj$ o, sys.user$ u, sys.col$ c, sys.view$ v
where o.owner# = u.user#
  and o.obj#  = c.obj#
  and c.obj#  = v.obj#(+)
  and bitand(c.property, 32) = 0 /* not hidden column */
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
      )
/

comment on table ALL_UPDATABLE_COLUMNS is 'Description of all updatable columns'
/

comment on column ALL_UPDATABLE_COLUMNS.OWNER is 'Table owner'
/

comment on column ALL_UPDATABLE_COLUMNS.TABLE_NAME is 'Table name'
/

comment on column ALL_UPDATABLE_COLUMNS.COLUMN_NAME is 'Column name'
/

comment on column ALL_UPDATABLE_COLUMNS.UPDATABLE is 'Is the column updatable?'
/

comment on column ALL_UPDATABLE_COLUMNS.INSERTABLE is 'Is the column insertable?'
/

comment on column ALL_UPDATABLE_COLUMNS.DELETABLE is 'Is the column deletable?'
/

