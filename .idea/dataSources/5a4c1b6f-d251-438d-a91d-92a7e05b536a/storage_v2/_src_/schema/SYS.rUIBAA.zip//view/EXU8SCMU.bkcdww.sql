create view EXU8SCMU as
SELECT  "SOWNER","SOWNERID","VNAME","TABNUM","SNACOL","MASCOL","MASPOS","ROLE"
        FROM    sys.exu8scm
        WHERE   sownerid = UID
/

