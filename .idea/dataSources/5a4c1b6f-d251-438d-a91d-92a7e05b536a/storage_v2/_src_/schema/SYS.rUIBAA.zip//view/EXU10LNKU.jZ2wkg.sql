create view EXU10LNKU as
SELECT  "OWNER","OWNERID","NAME","USER$","PASSWD","HOST","PUBLIC$","AUTH_USER","AUTH_PASSWD","FLAG","PASSWDX","AUTH_PASSWDX"
        FROM    sys.exu10lnk
        WHERE   ownerid = UID
/

