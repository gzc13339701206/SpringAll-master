create view EXU81ACTIONPKG as
SELECT  package, schema, class, level#
        FROM    sys.exppkgact$
/

