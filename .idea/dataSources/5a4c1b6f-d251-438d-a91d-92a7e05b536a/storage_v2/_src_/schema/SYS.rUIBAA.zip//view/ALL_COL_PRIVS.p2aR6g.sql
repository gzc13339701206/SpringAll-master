create view ALL_COL_PRIVS as
select ur.name, ue.name, u.name, o.name, c.name, tpm.name,
       decode(mod(oa.option$,2), 1, 'YES', 'NO')
from sys.objauth$ oa, sys.obj$ o, sys.user$ u, sys.user$ ur, sys.user$ ue,
     sys.col$ c, table_privilege_map tpm
where oa.obj# = o.obj#
  and oa.grantor# = ur.user#
  and oa.grantee# = ue.user#
  and u.user# = o.owner#
  and oa.obj# = c.obj#
  and oa.col# = c.col#
  and bitand(c.property, 32) = 0 /* not hidden column */
  and oa.col# is not null
  and oa.privilege# = tpm.privilege
  and (oa.grantor# = userenv('SCHEMAID') or
       oa.grantee# in (select kzsrorol from x$kzsro) or
       o.owner# = userenv('SCHEMAID'))
/

comment on table ALL_COL_PRIVS is 'Grants on columns for which the user is the grantor, grantee, owner,
 or an enabled role or PUBLIC is the grantee'
/

comment on column ALL_COL_PRIVS.GRANTOR is 'Name of the user who performed the grant'
/

comment on column ALL_COL_PRIVS.GRANTEE is 'Name of the user to whom access was granted'
/

comment on column ALL_COL_PRIVS.TABLE_SCHEMA is 'Schema of the object'
/

comment on column ALL_COL_PRIVS.TABLE_NAME is 'Name of the object'
/

comment on column ALL_COL_PRIVS.COLUMN_NAME is 'Name of the column'
/

comment on column ALL_COL_PRIVS.PRIVILEGE is 'Column Privilege'
/

comment on column ALL_COL_PRIVS.GRANTABLE is 'Privilege is grantable'
/

