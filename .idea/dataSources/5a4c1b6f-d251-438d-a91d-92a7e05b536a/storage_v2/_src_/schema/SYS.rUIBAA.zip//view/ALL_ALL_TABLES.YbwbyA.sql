create view ALL_ALL_TABLES as
  select OWNER, TABLE_NAME, TABLESPACE_NAME, CLUSTER_NAME, IOT_NAME, STATUS,
     PCT_FREE, PCT_USED,
     INI_TRANS, MAX_TRANS,
     INITIAL_EXTENT, NEXT_EXTENT,
     MIN_EXTENTS, MAX_EXTENTS, PCT_INCREASE,
     FREELISTS, FREELIST_GROUPS, LOGGING,
     BACKED_UP, NUM_ROWS, BLOCKS, EMPTY_BLOCKS,
     AVG_SPACE, CHAIN_CNT, AVG_ROW_LEN,
     AVG_SPACE_FREELIST_BLOCKS, NUM_FREELIST_BLOCKS,
     DEGREE, INSTANCES, CACHE, TABLE_LOCK,
     SAMPLE_SIZE, LAST_ANALYZED, PARTITIONED,
     IOT_TYPE, NULL, NULL, NULL, TEMPORARY, SECONDARY, NESTED,
     BUFFER_POOL, ROW_MOVEMENT,
     GLOBAL_STATS, USER_STATS, DURATION, SKIP_CORRUPT, MONITORING,
     CLUSTER_OWNER, DEPENDENCIES, COMPRESSION, DROPPED
from all_tables
union all
select OWNER, TABLE_NAME, TABLESPACE_NAME, CLUSTER_NAME, IOT_NAME, STATUS,
     PCT_FREE, PCT_USED,
     INI_TRANS, MAX_TRANS,
     INITIAL_EXTENT, NEXT_EXTENT,
     MIN_EXTENTS, MAX_EXTENTS, PCT_INCREASE,
     FREELISTS, FREELIST_GROUPS, LOGGING,
     BACKED_UP, NUM_ROWS, BLOCKS, EMPTY_BLOCKS,
     AVG_SPACE, CHAIN_CNT, AVG_ROW_LEN,
     AVG_SPACE_FREELIST_BLOCKS, NUM_FREELIST_BLOCKS,
     DEGREE, INSTANCES, CACHE, TABLE_LOCK,
     SAMPLE_SIZE, LAST_ANALYZED, PARTITIONED,
     IOT_TYPE, OBJECT_ID_TYPE,
     TABLE_TYPE_OWNER, TABLE_TYPE, TEMPORARY, SECONDARY, NESTED,
     BUFFER_POOL, ROW_MOVEMENT,
     GLOBAL_STATS, USER_STATS, DURATION, SKIP_CORRUPT, MONITORING,
     CLUSTER_OWNER, DEPENDENCIES, COMPRESSION, DROPPED
from all_object_tables
/

comment on table ALL_ALL_TABLES is 'Description of all object and relational tables accessible to the user'
/

comment on column ALL_ALL_TABLES.OWNER is 'Owner of the table'
/

comment on column ALL_ALL_TABLES.TABLE_NAME is 'Name of the table'
/

comment on column ALL_ALL_TABLES.TABLESPACE_NAME is 'Name of the tablespace containing the table'
/

comment on column ALL_ALL_TABLES.CLUSTER_NAME is 'Name of the cluster, if any, to which the table belongs'
/

comment on column ALL_ALL_TABLES.IOT_NAME is 'Name of the index-only table, if any, to which the overflow or mapping table entry belongs'
/

comment on column ALL_ALL_TABLES.STATUS is 'Status of the table will be UNUSABLE if a previous DROP TABLE operation failed,
VALID otherwise'
/

comment on column ALL_ALL_TABLES.PCT_FREE is 'Minimum percentage of free space in a block'
/

comment on column ALL_ALL_TABLES.PCT_USED is 'Minimum percentage of used space in a block'
/

comment on column ALL_ALL_TABLES.INI_TRANS is 'Initial number of transactions'
/

comment on column ALL_ALL_TABLES.MAX_TRANS is 'Maximum number of transactions'
/

comment on column ALL_ALL_TABLES.INITIAL_EXTENT is 'Size of the initial extent in bytes'
/

comment on column ALL_ALL_TABLES.NEXT_EXTENT is 'Size of secondary extents in bytes'
/

comment on column ALL_ALL_TABLES.MIN_EXTENTS is 'Minimum number of extents allowed in the segment'
/

comment on column ALL_ALL_TABLES.MAX_EXTENTS is 'Maximum number of extents allowed in the segment'
/

comment on column ALL_ALL_TABLES.PCT_INCREASE is 'Percentage increase in extent size'
/

comment on column ALL_ALL_TABLES.FREELISTS is 'Number of process freelists allocated in this segment'
/

comment on column ALL_ALL_TABLES.FREELIST_GROUPS is 'Number of freelist groups allocated in this segment'
/

comment on column ALL_ALL_TABLES.LOGGING is 'Logging attribute'
/

comment on column ALL_ALL_TABLES.BACKED_UP is 'Has table been backed up since last modification?'
/

comment on column ALL_ALL_TABLES.NUM_ROWS is 'The number of rows in the table'
/

comment on column ALL_ALL_TABLES.BLOCKS is 'The number of used blocks in the table'
/

comment on column ALL_ALL_TABLES.EMPTY_BLOCKS is 'The number of empty (never used) blocks in the table'
/

comment on column ALL_ALL_TABLES.AVG_SPACE is 'The average available free space in the table'
/

comment on column ALL_ALL_TABLES.CHAIN_CNT is 'The number of chained rows in the table'
/

comment on column ALL_ALL_TABLES.AVG_ROW_LEN is 'The average row length, including row overhead'
/

comment on column ALL_ALL_TABLES.AVG_SPACE_FREELIST_BLOCKS is 'The average freespace of all blocks on a freelist'
/

comment on column ALL_ALL_TABLES.NUM_FREELIST_BLOCKS is 'The number of blocks on the freelist'
/

comment on column ALL_ALL_TABLES.DEGREE is 'The number of threads per instance for scanning the table'
/

comment on column ALL_ALL_TABLES.INSTANCES is 'The number of instances across which the table is to be scanned'
/

comment on column ALL_ALL_TABLES.CACHE is 'Whether the table is to be cached in the buffer cache'
/

comment on column ALL_ALL_TABLES.TABLE_LOCK is 'Whether table locking is enabled or disabled'
/

comment on column ALL_ALL_TABLES.SAMPLE_SIZE is 'The sample size used in analyzing this table'
/

comment on column ALL_ALL_TABLES.LAST_ANALYZED is 'The date of the most recent time this table was analyzed'
/

comment on column ALL_ALL_TABLES.PARTITIONED is 'Is this table partitioned? YES or NO'
/

comment on column ALL_ALL_TABLES.IOT_TYPE is 'If index-only table, then IOT_TYPE is IOT or IOT_OVERFLOW or IOT_MAPPING else NULL'
/

comment on column ALL_ALL_TABLES.OBJECT_ID_TYPE is 'If user-defined OID, then USER-DEFINED, else if system generated OID, then SYST
EM GENERATED'
/

comment on column ALL_ALL_TABLES.TABLE_TYPE_OWNER is 'Owner of the type of the table if the table is an object table'
/

comment on column ALL_ALL_TABLES.TABLE_TYPE is 'Type of the table if the table is an object table'
/

comment on column ALL_ALL_TABLES.TEMPORARY is 'Can the current session only see data that it place in this object itself?'
/

comment on column ALL_ALL_TABLES.SECONDARY is 'Is this table object created as part of icreate for domain indexes?'
/

comment on column ALL_ALL_TABLES.NESTED is 'Is the table a nested table?'
/

comment on column ALL_ALL_TABLES.BUFFER_POOL is 'The default buffer pool to be used for table blocks'
/

comment on column ALL_ALL_TABLES.ROW_MOVEMENT is 'Whether partitioned row movement is enabled or disabled'
/

comment on column ALL_ALL_TABLES.GLOBAL_STATS is 'Are the statistics calculated without merging underlying partitions?'
/

comment on column ALL_ALL_TABLES.USER_STATS is 'Were the statistics entered directly by the user?'
/

comment on column ALL_ALL_TABLES.DURATION is 'If temporary table, then duration is sys$session or sys$transaction else NULL'
/

comment on column ALL_ALL_TABLES.SKIP_CORRUPT is 'Whether skip corrupt blocks is enabled or disabled'
/

comment on column ALL_ALL_TABLES.MONITORING is 'Should we keep track of the amount of modification?'
/

comment on column ALL_ALL_TABLES.CLUSTER_OWNER is 'Owner of the cluster, if any, to which the table belongs'
/

comment on column ALL_ALL_TABLES.DEPENDENCIES is 'Should we keep track of row level dependencies?'
/

comment on column ALL_ALL_TABLES.COMPRESSION is 'Whether table compression is enabled or not'
/

comment on column ALL_ALL_TABLES.DROPPED is 'Whether table is dropped and is in Recycle Bin'
/

