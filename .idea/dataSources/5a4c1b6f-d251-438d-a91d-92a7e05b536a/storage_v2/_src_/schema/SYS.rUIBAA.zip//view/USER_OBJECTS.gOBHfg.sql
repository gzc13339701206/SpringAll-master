create view USER_OBJECTS as
  select o.name, o.subname, o.obj#, o.dataobj#,
       decode(o.type#, 0, 'NEXT OBJECT', 1, 'INDEX', 2, 'TABLE', 3, 'CLUSTER',
                      4, 'VIEW', 5, 'SYNONYM', 6, 'SEQUENCE',
                      7, 'PROCEDURE', 8, 'FUNCTION', 9, 'PACKAGE',
                      11, 'PACKAGE BODY', 12, 'TRIGGER',
                      13, 'TYPE', 14, 'TYPE BODY',
                      19, 'TABLE PARTITION', 20, 'INDEX PARTITION', 21, 'LOB',
                      22, 'LIBRARY', 23, 'DIRECTORY',  24, 'QUEUE',
                      28, 'JAVA SOURCE', 29, 'JAVA CLASS', 30, 'JAVA RESOURCE',
                      32, 'INDEXTYPE', 33, 'OPERATOR',
                      34, 'TABLE SUBPARTITION', 35, 'INDEX SUBPARTITION',
                      40, 'LOB PARTITION', 41, 'LOB SUBPARTITION',
                      42, NVL((SELECT distinct 'REWRITE EQUIVALENCE'
                               FROM sum$ s
                               WHERE s.obj#=o.obj#
                                     and bitand(s.xpflags, 8388608) = 8388608),
                              'MATERIALIZED VIEW'),
                      43, 'DIMENSION',
                      44, 'CONTEXT', 46, 'RULE SET', 47, 'RESOURCE PLAN',
                      48, 'CONSUMER GROUP',
                      51, 'SUBSCRIPTION', 52, 'LOCATION',
                      55, 'XML SCHEMA', 56, 'JAVA DATA',
                      57, 'SECURITY PROFILE', 59, 'RULE',
                      60, 'CAPTURE', 61, 'APPLY',
                      62, 'EVALUATION CONTEXT',
                      66, 'JOB', 67, 'PROGRAM', 68, 'JOB CLASS', 69, 'WINDOW',
                      72, 'WINDOW GROUP', 74, 'SCHEDULE', 79, 'CHAIN',
                      81, 'FILE GROUP',
                     'UNDEFINED'),
       o.ctime, o.mtime,
       to_char(o.stime, 'YYYY-MM-DD:HH24:MI:SS'),
       decode(o.status, 0, 'N/A', 1, 'VALID', 'INVALID'),
       decode(bitand(o.flags, 2), 0, 'N', 2, 'Y', 'N'),
       decode(bitand(o.flags, 4), 0, 'N', 4, 'Y', 'N'),
       decode(bitand(o.flags, 16), 0, 'N', 16, 'Y', 'N')
from sys.obj$ o
where o.owner# = userenv('SCHEMAID')
  and o.linkname is null
  and (o.type# not in (1  /* INDEX - handled below */,
                      10 /* NON-EXISTENT */)
       or
       (o.type# = 1 and 1 = (select 1
                             from sys.ind$ i
                            where i.obj# = o.obj#
                              and i.type# in (1, 2, 3, 4, 6, 7, 9))))
  and o.name != '_NEXT_OBJECT'
  and o.name != '_default_auditing_options_'
union all
select l.name, NULL, to_number(null), to_number(null),
       'DATABASE LINK',
       l.ctime, to_date(null), NULL, 'VALID', 'N', 'N', 'N'
from sys.link$ l
where l.owner# = userenv('SCHEMAID')
/

comment on table USER_OBJECTS is 'Objects owned by the user'
/

comment on column USER_OBJECTS.OBJECT_NAME is 'Name of the object'
/

comment on column USER_OBJECTS.SUBOBJECT_NAME is 'Name of the sub-object (for example, partititon)'
/

comment on column USER_OBJECTS.OBJECT_ID is 'Object number of the object'
/

comment on column USER_OBJECTS.DATA_OBJECT_ID is 'Object number of the segment which contains the object'
/

comment on column USER_OBJECTS.OBJECT_TYPE is 'Type of the object'
/

comment on column USER_OBJECTS.CREATED is 'Timestamp for the creation of the object'
/

comment on column USER_OBJECTS.LAST_DDL_TIME is 'Timestamp for the last DDL change (including GRANT and REVOKE) to the object'
/

comment on column USER_OBJECTS.TIMESTAMP is 'Timestamp for the specification of the object'
/

comment on column USER_OBJECTS.STATUS is 'Status of the object'
/

comment on column USER_OBJECTS.TEMPORARY is 'Can the current session only see data that it place in this object itself?'
/

comment on column USER_OBJECTS.GENERATED is 'Was the name of this object system generated?'
/

comment on column USER_OBJECTS.SECONDARY is 'Is this a secondary object created as part of icreate for domain indexes?'
/

