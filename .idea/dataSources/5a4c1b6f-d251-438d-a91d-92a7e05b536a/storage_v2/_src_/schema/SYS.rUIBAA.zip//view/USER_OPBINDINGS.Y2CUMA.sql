create view USER_OPBINDINGS as
select  c.name, b.name, a.bind#, a.functionname, a.returnschema,
        a.returntype, a.impschema, a.imptype,
        decode(bitand(a.property,31), 1, 'WITH INDEX CONTEXT',
               3 , 'COMPUTE ANCILLARY DATA', 4 , 'ANCILLARY TO',
               16 , 'WITH COLUMN CONTEXT' ,
               17,  'WITH INDEX, COLUMN CONTEXT',
               19, 'COMPUTE ANCILLARY DATA, WITH COLUMN CONTEXT')
  from  sys.opbinding$ a, sys.obj$ b, sys.user$ c
  where a.obj# = b.obj# and b.owner# = c.user#
  and b.owner# = userenv ('SCHEMAID')
/

comment on table USER_OPBINDINGS is 'All binding functions or methods on operators defined by the user'
/

comment on column USER_OPBINDINGS.OWNER is 'Owner of the operator'
/

comment on column USER_OPBINDINGS.OPERATOR_NAME is 'Name of the operator'
/

comment on column USER_OPBINDINGS.BINDING# is 'Binding# of the operator'
/

comment on column USER_OPBINDINGS.FUNCTION_NAME is 'Name of the binding function or method as specified by the user'
/

comment on column USER_OPBINDINGS.RETURN_SCHEMA is 'Name of the schema of the return type - not null only for ADTs'
/

comment on column USER_OPBINDINGS.RETURN_TYPE is 'Name of the return type'
/

comment on column USER_OPBINDINGS.IMPLEMENTATION_TYPE_SCHEMA is 'Schema of the implementation type of the indextype '
/

comment on column USER_OPBINDINGS.IMPLEMENTATION_TYPE is 'Implementation type of the indextype'
/

comment on column USER_OPBINDINGS.PROPERTY is 'Property of the operator binding'
/

