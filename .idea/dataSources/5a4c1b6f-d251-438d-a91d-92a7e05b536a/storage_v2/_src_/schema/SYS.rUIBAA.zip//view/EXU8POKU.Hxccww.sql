create view EXU8POKU as
SELECT  "OBJID","OWNERID","POSNO","NAME","PROPERTY","FUNCTION","FUNCLEN"
        FROM    sys.exu8pok
        WHERE   ownerid = UID
/

