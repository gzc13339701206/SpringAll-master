create view ALL_TAB_PRIVS_RECD as
select ue.name, u.name, o.name, ur.name, tpm.name,
       decode(mod(oa.option$,2), 1, 'YES', 'NO'),
       decode(bitand(oa.option$,2), 2, 'YES', 'NO')
from sys.objauth$ oa, sys.obj$ o, sys.user$ u, sys.user$ ur, sys.user$ ue,
     table_privilege_map tpm
where oa.obj# = o.obj#
  and oa.grantor# = ur.user#
  and oa.grantee# = ue.user#
  and u.user# = o.owner#
  and oa.col# is null
  and oa.privilege# = tpm.privilege
  and oa.grantee# in (select kzsrorol from x$kzsro)
/

comment on table ALL_TAB_PRIVS_RECD is 'Grants on objects for which the user, PUBLIC or enabled role is the grantee'
/

comment on column ALL_TAB_PRIVS_RECD.GRANTEE is 'Name of the user to whom access was granted'
/

comment on column ALL_TAB_PRIVS_RECD.OWNER is 'Owner of the object'
/

comment on column ALL_TAB_PRIVS_RECD.TABLE_NAME is 'Name of the object'
/

comment on column ALL_TAB_PRIVS_RECD.GRANTOR is 'Name of the user who performed the grant'
/

comment on column ALL_TAB_PRIVS_RECD.PRIVILEGE is 'Table Privilege'
/

comment on column ALL_TAB_PRIVS_RECD.GRANTABLE is 'Privilege is grantable'
/

comment on column ALL_TAB_PRIVS_RECD.HIERARCHY is 'Privilege is with hierarchy option'
/

