create view ALL_PROCEDURES as
select u.name, o.name, pi.procedurename,
decode(bitand(pi.properties,8),8,'YES','NO'),
decode(bitand(pi.properties,16),16,'YES','NO'),
u2.name, o2.name,
  decode(bitand(pi.properties,32),32,'YES','NO'),
  decode(bitand(pi.properties,512),512,'YES','NO'),
decode(bitand(pi.properties,256),256,'YES','NO'),
decode(bitand(pi.properties,1024),1024,'CURRENT_USER','DEFINER')
from obj$ o, user$ u, procedureinfo$ pi, obj$ o2, user$ u2
where u.user# = o.owner# and o.obj# = pi.obj#
and pi.itypeobj# = o2.obj# (+) and o2.owner#  = u2.user# (+)
and (o.owner# = userenv('SCHEMAID')
     or exists
      (select null from v$enabledprivs where priv_number in (-144,-141))
     or o.obj# in (select obj# from sys.objauth$ where grantee# in
      (select kzsrorol from x$kzsro) and privilege# = 12))
/

comment on table ALL_PROCEDURES is 'Description of all procedures available to the user'
/

comment on column ALL_PROCEDURES.OBJECT_NAME is 'Name of the object : top level function/procedure/package name'
/

comment on column ALL_PROCEDURES.PROCEDURE_NAME is 'Name of the procedure'
/

comment on column ALL_PROCEDURES.AGGREGATE is 'Is it an aggregate function ?'
/

comment on column ALL_PROCEDURES.PIPELINED is 'Is it a pipelined table function ?'
/

comment on column ALL_PROCEDURES.IMPLTYPEOWNER is 'Name of the owner of the implementation type (if any)'
/

comment on column ALL_PROCEDURES.IMPLTYPENAME is 'Name of the implementation type (if any)'
/

comment on column ALL_PROCEDURES.PARALLEL is 'Is the procedure parallel enabled ?'
/

