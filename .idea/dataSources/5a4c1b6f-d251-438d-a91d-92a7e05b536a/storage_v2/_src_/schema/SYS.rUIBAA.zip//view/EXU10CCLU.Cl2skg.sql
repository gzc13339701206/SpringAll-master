create view EXU10CCLU as
SELECT  "OWNERID","OWNERNAME","CNO","COLNAME","COLNO","INTCOL","PROPERTY","NOLOG"
        FROM    sys.exu10ccl
        WHERE   UID = ownerid
/

