create view EXU81OPRU as
SELECT  "NAME","OBJID","OWNER","OWNERID","SQLVER"
        FROM    sys.exu81opr
        WHERE   ownerid = UID
/

