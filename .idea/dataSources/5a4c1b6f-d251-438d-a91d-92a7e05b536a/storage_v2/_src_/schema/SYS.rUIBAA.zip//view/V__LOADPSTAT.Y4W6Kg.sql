create view V_$LOADPSTAT as
select "OWNER","TABNAME","PARTNAME","LOADED" from v$loadpstat
/

