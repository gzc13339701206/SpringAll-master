create package cwm2_olap_pc_transform as

  procedure create_script
    (p_Directory            varchar2
    ,p_Schema               varchar2
    ,p_PC_Table             varchar2
    ,p_PC_Parent            varchar2
    ,p_PC_Child             varchar2
    ,p_T_Table              varchar2
    ,p_T_Tablespace         varchar2
    ,p_PC_Root              varchar2 default null
    ,p_Levels               number   default null
    ,p_Levels_List          varchar2 default null
    ,p_Short_Description    varchar2 default null
    ,p_Long_Description     varchar2 default null
    ,p_Attributes_List      varchar2 default null
    );

end cwm2_olap_pc_transform;
/

