create PACKAGE OlapFactView AS

PROCEDURE CreateFactTab(exOwnerName IN varchar2,exCubeName IN varchar2,eOutFile IN varchar2,
                        eOutPath IN varchar2,partitioning IN BOOLEAN,mvspcName IN varchar2 default null,indspcName IN varchar2 default null);

PROCEDURE CreateFactTab(runId IN NUMBER,exOwnerName IN varchar2,exCubeName IN varchar2,partitioning IN BOOLEAN);

END OlapFactView;
/

