create package cwm2_olap_mr_security_init authid current_user as

procedure Init_MR_Session_Object_Table;

end cwm2_olap_mr_security_init;
/

