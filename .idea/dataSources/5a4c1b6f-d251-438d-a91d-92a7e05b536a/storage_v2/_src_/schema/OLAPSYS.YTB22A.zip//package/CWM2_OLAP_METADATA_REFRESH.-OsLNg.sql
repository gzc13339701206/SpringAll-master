create package cwm2_olap_metadata_refresh as

procedure mr_refresh;

procedure mr_ac_refresh;

end cwm2_olap_metadata_refresh;
/

