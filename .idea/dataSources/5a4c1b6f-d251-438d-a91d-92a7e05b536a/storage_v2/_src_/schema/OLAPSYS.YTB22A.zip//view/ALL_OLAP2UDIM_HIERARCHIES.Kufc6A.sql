create view ALL$OLAP2UDIM_HIERARCHIES as
  select dh.owner, dh.dimension_name, dh.hierarchy_name, dh.display_name,
       dh.shortdesc short_description, dh.longdesc description, 'UL' solved_code
from
(SELECT
  u.name owner
, d.name dimension_name
, h.hiername hierarchy_name
, hie.displayname display_name
, hie.description shortdesc
, hie.description longdesc
FROM
  sys.user$ u
, sys.obj$ d
, sys.hier$ h
, cwm$hierarchy hie
WHERE u.user# = d.owner#
AND d.type# = 43 /* DIMENSION */
AND (cwm$util.dimension_tables_visible(d.obj#) = 'Y'
     OR EXISTS /* SELECT ANY TABLE, CREATE, ALTER, DROP ANY DIMENSION */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number IN (-47,-215,-216,-217)))
AND d.obj# = h.dimobj#
AND h.dimobj# = hie.dimension_irid
AND h.hiername = hie.name (+)) dh
union all
select owner, dimension_name, hierarchy_name, display_name, short_description,
       description, solved_code
from olapsys.all$olap2_dim_hierarchies
with read only
/

