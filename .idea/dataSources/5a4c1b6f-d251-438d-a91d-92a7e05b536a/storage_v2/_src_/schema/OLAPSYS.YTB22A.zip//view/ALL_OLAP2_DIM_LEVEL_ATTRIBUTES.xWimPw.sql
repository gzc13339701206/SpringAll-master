create view ALL$OLAP2_DIM_LEVEL_ATTRIBUTES as
select
  d.owner owner,
  d.name dimension_name,
  la.name attribute_name,
  la.displayname display_name,
  la.shortdescription short_description,
  la.description description,
  l.name determined_by_level_name
from olapsys.CwM2$dimension d,
     olapsys.CwM2$levelattribute la,
     olapsys.CwM2$Level l
where d.irid = la.dimension_irid and
      la.level_irid = l.irid and
      l.dimension_irid = d.irid and
       d.invalid = 'N' and
       (cwm2$security.dimension_tables_visible(d.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47, -215, -216, -217)))
with read only
/

