create package cwm2_olap_dimension as

  procedure create_dimension(p_Dimension_Owner varchar2
                            ,p_Dimension_Name varchar2
                            ,p_Display_Name varchar2
                            ,p_Plural_Name varchar2
                            ,p_Short_Description varchar2
                            ,p_Description varchar2
                            ,p_Dimension_Type varchar2 default null);


  procedure set_dimension_name(p_Dimension_Owner varchar2
                              ,p_Dimension_Name varchar2
                              ,p_Set_Dimension_Name varchar2);

  procedure set_display_name(p_Dimension_Owner varchar2
                            ,p_Dimension_Name varchar2
                            ,p_Display_Name varchar2);

  procedure set_plural_name(p_Dimension_Owner varchar2
                           ,p_Dimension_Name varchar2
                           ,p_Plural_Name varchar2);


  procedure set_short_description(p_Dimension_Owner varchar2
                                 ,p_Dimension_Name varchar2
                                 ,p_Short_Description varchar2);

  procedure set_description(p_Dimension_Owner varchar2
                           ,p_Dimension_Name varchar2
                           ,p_Description varchar2);

  procedure set_default_display_hierarchy(p_Dimension_Owner varchar2
                                         ,p_Dimension_Name varchar2
                                         ,p_hierarchy_name varchar2);

  procedure drop_dimension(p_Dimension_Owner varchar2
                          ,p_Dimension_Name varchar2
                          ,p_Silent varchar2 default null);

  procedure lock_dimension(p_Dimension_Owner varchar2
                          ,p_Dimension_Name varchar2
                          ,p_Wait_For_Lock boolean default false);

end cwm2_olap_dimension;
/

