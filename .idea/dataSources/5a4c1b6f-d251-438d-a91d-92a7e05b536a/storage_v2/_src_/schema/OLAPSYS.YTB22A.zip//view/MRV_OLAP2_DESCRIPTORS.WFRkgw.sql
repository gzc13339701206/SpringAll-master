create view MRV$OLAP2_DESCRIPTORS as
select
  d.descriptor_id descriptor_id,
  d.descriptor_value descriptor_value,
  d.descriptor_type descriptor_type,
  d.description description
 from olapsys.cwm2$mrall_descriptors d
/

