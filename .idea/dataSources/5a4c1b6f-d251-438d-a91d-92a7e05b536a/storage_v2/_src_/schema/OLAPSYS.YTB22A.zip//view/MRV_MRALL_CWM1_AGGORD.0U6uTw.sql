create view MRV$MRALL_CWM1_AGGORD as
select
 c1aord.owner,
 c1aord.cube_name,
 c1aord.dimension_owner,
 c1aord.dimension_name,
 c1aord.position
 from olapsys.cwm2$mrall_cwm1_aggord c1aord,
      olapsys.olap_session_objects oso
 where oso.version_id = c1aord.version_id and
       oso.id = c1aord.id
/

