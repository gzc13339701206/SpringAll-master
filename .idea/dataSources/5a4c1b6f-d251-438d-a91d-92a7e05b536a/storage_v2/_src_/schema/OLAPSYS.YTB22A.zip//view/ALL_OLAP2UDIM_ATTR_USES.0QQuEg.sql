create view ALL$OLAP2UDIM_ATTR_USES as
  select owner, dimension_name, dim_attribute_name, level_name, lvl_attribute_name
from olapsys.all$olap_dim_attr_uses
union all
select owner, dimension_name, dim_attribute_name, level_name, lvl_attribute_name
from all$olap2_dim_attr_uses
with read only
/

