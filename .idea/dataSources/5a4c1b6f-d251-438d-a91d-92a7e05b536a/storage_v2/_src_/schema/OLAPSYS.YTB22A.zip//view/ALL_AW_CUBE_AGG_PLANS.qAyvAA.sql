create view ALL$AW_CUBE_AGG_PLANS as
  select c.owner owner,
          c.name cube_name,
          cagg.name aggregation_name
   from
     cwm2$cube c,
     cwm2$awcubeagg cagg
   where
     cagg.cube_irid = c.irid and
     cagg.version_id = 'CWM2' and
     (c.invalid = 'N' or c.invalid = 'O') and
     (cwm2$security.fact_table_visible(c.irid) = 'Y'
        OR EXISTS (select null from v$enabledprivs
                   where priv_number in (-47)))
  union all
   select sch.physicalname owner,
          c.physicalname cube_name,
          cagg.name aggregation_name
   from
      cwm$cube c,
      cwm$model sch,
      cwm2$awcubeagg cagg
   where
     sch.irid = c.datamodel_irid and
     cagg.cube_irid = c.irid and
     cagg.version_id = 'CWM' and
     (cwm$util.fact_table_visible(c.irid) = 'Y'
        OR EXISTS (select null from v$enabledprivs
                   where priv_number in (-47)))
with read only
/

