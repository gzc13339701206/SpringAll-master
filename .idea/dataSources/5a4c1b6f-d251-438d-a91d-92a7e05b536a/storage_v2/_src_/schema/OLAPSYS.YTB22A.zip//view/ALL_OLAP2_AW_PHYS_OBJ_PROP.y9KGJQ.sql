create view ALL$OLAP2_AW_PHYS_OBJ_PROP as
SELECT AW.AWOWNER as AW_OWNER,
       AW.AWNAME as AW_NAME,
       AW.AWOBJECT as AW_OBJECT_NAME,
       AW.COL1 as AW_PROP_NAME,
       AW.COL2 as AW_PROP_VALUE
FROM
TABLE(CAST (OLAP_TABLE('SYS.AWMD duration query', 'olapsys.ALL_OLAP2_AW_METADATA_T',
                       'ACTIVE_CATALOG ''ALL_OLAP2_AW_PHYS_OBJ_PROP'' ''ALL''',
                         'MEASURE AWOWNER FROM sys.awmd!AWOWNER
                          MEASURE AWNAME FROM sys.awmd!AWNAME
                          MEASURE AWOBJECT FROM sys.awmd!AWOBJECT
                          MEASURE COL1 FROM sys.awmd!AWOBJECTPROPNAME
                          MEASURE COL2 FROM sys.awmd!AWOBJECTPROPVALUE
                          DIMENSION AWMDKEY FROM sys.awmd!AWMDKEY')
                        AS olapsys.ALL_OLAP2_AW_METADATA_T)) AW
/

