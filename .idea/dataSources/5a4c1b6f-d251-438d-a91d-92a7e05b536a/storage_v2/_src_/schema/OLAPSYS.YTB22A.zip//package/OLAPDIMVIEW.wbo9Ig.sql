create PACKAGE OlapDimView AS


PROCEDURE CreateDimTab(exOwnerName IN varchar2,exDimName IN varchar2,eOutFile IN varchar2,eOutPath IN varchar2, mvspcName IN varchar2 default null,indspcName IN varchar2 default null);


PROCEDURE CreateDimTab(runId IN NUMBER, exOwnerName IN varchar2,exDimName IN varchar2);

END OlapDimView;
/

