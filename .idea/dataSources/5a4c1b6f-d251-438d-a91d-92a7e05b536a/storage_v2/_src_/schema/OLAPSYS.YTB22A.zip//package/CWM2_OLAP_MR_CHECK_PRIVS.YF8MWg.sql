create package cwm2_olap_mr_check_privs authid current_user as

procedure check_current_user_privs(objectmode varchar2, result in out varchar2);

end cwm2_olap_mr_check_privs;
/

