create view ALL$OLAP2UCUBE_MEAS_DIM_USES as
  SELECT distinct
  sch.physicalname owner
, cub.physicalname cube_name
, msr.physicalname measure_name
, cdu.dimension_owner
, cdu.dimension_name
, cdu.name dimension_alias
, fu.irid default_aggr_function_use_id
FROM
  sys.user$ u
, cwm$model sch
, cwm$cube cub
, cwm$measure msr
, cwm$measuredimensionuse mdu
, cwm$cubedimensionuse cdu
, cwm$functionuse fu
, cwm$dimension cd
, sys.user$ du
, sys.obj$ do
WHERE u.name = sch.physicalname
AND sch.irid = cub.datamodel_irid
AND (cwm$util.fact_table_visible(cub.irid) = 'Y'
     OR EXISTS /* SELECT ANY TABLE */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number = -47))
AND cub.irid = msr.itemcontainer_irid
AND msr.irid = mdu.measure_irid
AND mdu.cubedimensionuse_irid = cdu.irid
AND mdu.irid = fu.measuredimensionuse_irid (+)
AND cub.irid = cdu.cube_irid
AND cdu.dimension_owner = du.name
AND cdu.dimension_name = do.name
AND du.user# = do.owner#
AND do.type# = 43
AND do.obj# = cd.irid
AND cd.irid = cdu.abstractdimension_irid
union all
select owner, cube_name, measure_name, dimension_owner, dimension_name,
       dimension_alias, default_aggr_function_use_id
from olapsys.all$olap2_cube_meas_dim_uses
with read only
/

