create view ALL$AW_LOAD_DIM_FILT as
select
    ldm.owner owner,
    ldm.dimension_name dimension_name,
    ldm.load_name load_name,
    lf.lookup_table_owner table_owner,
    lf.lookup_table_name  table_name,
    lf.filtercondition filter_condition
 from olapsys.all$aw_load_dim_map ldm,
      olapsys.cwm2$awdimloadfilter lf
 where ldm.load_irid = lf.dimload_irid
 with read only
/

