create view MRV$OLAP1_POP_CUBES as
select
 cub.irid id
FROM
  cwm$model sch,
  cwm$cube cub
WHERE sch.irid = cub.datamodel_irid and
      cwm$util.fact_table_visible(cub.irid) = 'Y'
/

