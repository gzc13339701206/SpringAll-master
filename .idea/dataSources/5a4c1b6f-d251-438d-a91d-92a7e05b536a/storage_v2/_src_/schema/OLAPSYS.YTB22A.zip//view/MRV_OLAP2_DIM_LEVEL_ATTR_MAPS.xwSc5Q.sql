create view MRV$OLAP2_DIM_LEVEL_ATTR_MAPS as
select
  dlam.owner owner,
  dlam.dimension_name dimension_name,
  dlam.hierarchy_name hierarchy_name,
  dlam.attribute_name attribute_name,
  dlam.lvl_attribute_name lvl_attribute_name,
  dlam.level_name level_name,
  dlam.table_owner table_owner,
  dlam.table_name table_name,
  dlam.column_name column_name,
  dlam.dtype dtype,
  dlam.data_length data_length,
  dlam.data_precision data_precision,
  dlam.olap_api_data_type olap_api_data_type
 from olapsys.cwm2$mrall_dim_level_attr_maps dlam,
      olapsys.olap_session_objects oso
 where oso.version_id = dlam.version_id and
       oso.id = dlam.id
/

