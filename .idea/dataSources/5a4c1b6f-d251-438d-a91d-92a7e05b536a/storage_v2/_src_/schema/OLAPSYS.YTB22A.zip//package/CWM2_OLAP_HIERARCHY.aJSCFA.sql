create package cwm2_olap_hierarchy as

  procedure Create_Hierarchy(p_Dimension_Owner varchar2
                            ,p_Dimension_Name varchar2
                            ,p_Hierarchy_Name varchar2
                            ,p_Display_Name varchar2
                            ,p_Short_Description varchar2
                            ,p_Description varchar2
                            ,p_Solved_Code varchar2);

  procedure Set_Hierarchy_Name(p_Dimension_Owner varchar2
                              ,p_Dimension_Name varchar2
                              ,p_Hierarchy_Name varchar2
                              ,p_Set_Hierarchy_Name varchar2);

  procedure Set_Display_Name(p_Dimension_Owner varchar2
                            ,p_Dimension_Name varchar2
                            ,p_Hierarchy_Name varchar2
                            ,p_Display_Name varchar2);

  procedure Set_Short_Description(p_Dimension_Owner varchar2
                                 ,p_Dimension_Name varchar2
                                 ,p_Hierarchy_Name varchar2
                                 ,p_Short_Description varchar2);

  procedure Set_Description(p_Dimension_Owner varchar2
                           ,p_Dimension_Name varchar2
                           ,p_Hierarchy_Name varchar2
                           ,p_Description varchar2);

  procedure Set_Solved_Code(p_Dimension_Owner varchar2
                          ,p_Dimension_Name varchar2
                          ,p_Hierarchy_Name varchar2
                          ,p_Solved_Code varchar2);

  procedure Drop_Hierarchy(p_Dimension_Owner varchar2
                          ,p_Dimension_Name varchar2
                          ,p_Hierarchy_Name varchar2);

  procedure Lock_Hierarchy(p_Dimension_Owner varchar2
                          ,p_Dimension_Name varchar2
                          ,p_Hierarchy_Name varchar2
                          ,p_Wait_For_Lock boolean default false);

end cwm2_olap_hierarchy;
/

