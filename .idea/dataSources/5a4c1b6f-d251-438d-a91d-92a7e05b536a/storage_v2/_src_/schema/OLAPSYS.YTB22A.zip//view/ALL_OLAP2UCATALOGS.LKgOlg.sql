create view ALL$OLAP2UCATALOGS as
  select
  catalog_id,
  catalog_name,
  parent_catalog_id,
  description
from olapsys.all$olap_catalogs
union all
select catalog_id,
  catalog_name,
  parent_catalog_id,
  description
from olapsys.all$olap2_catalogs
with read only
/

