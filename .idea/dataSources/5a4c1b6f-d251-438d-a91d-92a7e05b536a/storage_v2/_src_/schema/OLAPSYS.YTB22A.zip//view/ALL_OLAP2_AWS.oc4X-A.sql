create view ALL$OLAP2_AWS as
  select a.owner owner, a.aw_name AW, a.aw_number AW_NUMBER,
       a.aw_version aw_version, '10.1.0.3' sf_version
from all_aws a
where a.aw_number > 999
and a.aw_number in (select distinct aw_number from all_aw_prop_name
                 where property_name = 'AW$VERSION10.1.0.3')
and a.aw_number not in (select distinct aw_number from all_aw_prop_name
                 where property_name = 'AW$VERSION10.2')
union all
select a.owner owner, a.aw_name AW, a.aw_number AW_NUMBER,
       a.aw_version aw_version, '10.2' sf_version
from all_aws a
where a.aw_number > 999
and a.aw_number in (select distinct aw_number from all_aw_prop_name
                 where property_name = 'AW$VERSION10.2')
union all
select a.owner owner, a.aw_name AW, a.aw_number AW_NUMBER,
       a.aw_version aw_version, null sf_version
from all_aws a
where a.aw_number > 999
and a.aw_number not in (select distinct aw_number from all_aw_prop_name
                     where property_name = 'AW$VERSION10.1.0.3')
/

