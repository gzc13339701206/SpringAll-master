create view ALL$AW_LOAD_CUBE_PARM as
select
   lcm.owner owner,
   lcm.cube_name cube_name,
   lcm.load_name load_name,
   clp.name parm_name,
   clpv.value parm_value
 from olapsys.all$aw_load_cube_map lcm,
      olapsys.cwm2$awcubeloadparm clp,
      olapsys.cwm2$awcubeloadparmvalue clpv
 where lcm.load_irid = clpv.cubeload_irid
   and clpv.parmname_irid = clp.irid
with read only
/

