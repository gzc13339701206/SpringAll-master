create view ALL$OLAP2UCATALOG_ENTITY_USES as
  select distinct
  ce.classification_irid catalog_id
, sch.physicalname entity_owner
, cub.physicalname entity_name
, msr.physicalname child_entity_name
FROM
  cwm$classification c
, cwm$classificationentry ce
, cwm$classificationtype cty
, cwm$measure msr
, cwm$cube cub
, cwm$model sch
, sys.user$ u
, cwm$cubedimensionuse cdu
, cwm$dimension cd
, sys.user$ du
, sys.obj$ do
WHERE cty.irid = c.classificationtype_irid
AND cty.name = 'ORACLE_OLAP_CATALOG'
AND c.irid = ce.classification_irid
AND ce.name = 'MEASURE'
AND ce.element_irid = msr.irid
AND msr.itemcontainer_irid = cub.irid
AND sch.irid = cub.datamodel_irid
AND sch.physicalname = u.name
AND cdu.cube_irid = cub.irid
AND cdu.dimension_owner = du.name
AND cdu.dimension_name = do.name
AND du.user# = do.owner#
AND do.obj# = cd.irid
AND do.type# = 43
AND cd.irid = cdu.abstractdimension_irid
AND (cwm$util.fact_table_visible(cub.irid) = 'Y'
     OR EXISTS /* SELECT ANY TABLE */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number = -47))
union all
select catalog_id,
 entity_owner,
 entity_name,
 child_entity_name
from olapsys.all$olap2_catalog_entity_uses
with read only
/

