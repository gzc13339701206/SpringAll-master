create view ALL$OLAP2_CUBE_MEASURE_MAPS as
select distinct c.owner owner,
  c.name cube_name,
  m.name measure_name,
  fdhm.irid dim_hier_combo_id,
  u.name fact_table_owner,
  o.name fact_table_name,
  col.name column_name
from olapsys.CwM2$Cube c,
     olapsys.CwM2$Measure m,
     olapsys.CwM2$MeasureTableMap mtm,
     olapsys.CwM2$Dimension d,
     olapsys.CwM2$CubeDimensionUse cdu,
     olapsys.CwM2$FactDimHierMap fdhm,
     sys.obj$ o,
     sys.user$ u,
     sys.col$ col
where c.irid = m.cube_irid and
      d.irid = cdu.dimension_irid and
      c.irid = cdu.cube_irid and
      m.irid = mtm.measure_irid and
      fdhm.cube_irid = c.irid and
      mtm.FactDimHier_IRID = fdhm.irid and
      mtm.factcolumn_ID = col.col# and
      mtm.facttablename_ID = o.obj# and
      o.owner# = u.user# and
      o.obj# = col.obj# and
       (c.invalid = 'N' or c.invalid = 'O') and
       (cwm2$security.fact_table_visible(c.irid) = 'Y'
       OR EXISTS (select null from v$enabledprivs
                  where priv_number in (-47)))
with read only
/

