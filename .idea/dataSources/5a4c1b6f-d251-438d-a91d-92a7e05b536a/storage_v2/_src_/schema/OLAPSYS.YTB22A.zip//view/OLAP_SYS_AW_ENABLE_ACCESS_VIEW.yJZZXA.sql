create view OLAP_SYS_AW_ENABLE_ACCESS_VIEW as
SELECT AW_ACCESS_INFO FROM
    TABLE(CAST(OLAP_TABLE('SYS.AWCREATE duration session',
                          'OLAPSYS.OLAP_SYS_AW_ENABLE_ACCESS_TBL',
                          '',
                          'DIMENSION AW_ACCESS_INFO FROM OLAP_SYS_RETURN_INFO')
                      AS OLAP_SYS_AW_ENABLE_ACCESS_TBL))
/

