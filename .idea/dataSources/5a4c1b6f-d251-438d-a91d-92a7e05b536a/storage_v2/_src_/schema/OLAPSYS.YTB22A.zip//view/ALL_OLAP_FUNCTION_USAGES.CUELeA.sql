create view ALL$OLAP_FUNCTION_USAGES as
  SELECT
  u.irid function_usage_id
, f.name function_name
FROM
  cwm$function f
, cwm$functionuse u
, cwm$measuredimensionuse mdu
, cwm$measure msr
WHERE f.irid = u.function_irid
AND u.measuredimensionuse_irid = mdu.irid
AND mdu.measure_irid = msr.irid
AND (    cwm$util.fact_table_visible(msr.itemcontainer_irid) = 'Y'
     OR EXISTS /* SELECT ANY TABLE */
       (SELECT null FROM v$enabledprivs
        WHERE priv_number = -47))
UNION ALL SELECT
  u.irid function_usage_id
, f.name function_name
FROM
  cwm$function f
, cwm$functionuse u
WHERE f.irid = u.function_irid
AND u.measuredimensionuse_irid IS NULL
WITH READ ONLY
/

