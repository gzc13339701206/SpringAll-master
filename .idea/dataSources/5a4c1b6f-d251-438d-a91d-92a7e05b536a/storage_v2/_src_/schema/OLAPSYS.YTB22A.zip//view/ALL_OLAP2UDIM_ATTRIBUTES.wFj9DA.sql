create view ALL$OLAP2UDIM_ATTRIBUTES as
  select owner, dimension_name, attribute_name, display_name,
       short_description, description, desc_id
from all$olapmr_dim_attributes
union all
select owner, dimension_name, attribute_name, display_name,
       short_description, description, desc_id
from all$olap2_dim_attributes
with read only
/

