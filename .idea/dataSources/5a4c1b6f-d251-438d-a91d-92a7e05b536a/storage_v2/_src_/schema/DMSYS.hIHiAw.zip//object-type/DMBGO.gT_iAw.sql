create TYPE dmbgo AS OBJECT (
  gap_start  INTEGER,
  gap_type   INTEGER,
  gap_length INTEGER
);
/

