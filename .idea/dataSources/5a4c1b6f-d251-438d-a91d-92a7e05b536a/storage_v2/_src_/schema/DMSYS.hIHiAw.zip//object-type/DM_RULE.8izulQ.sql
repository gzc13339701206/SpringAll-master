create TYPE DM_Rule AS OBJECT
  (rule_id            INTEGER
  ,antecedent         DM_Predicates
  ,consequent         DM_Predicates
  ,rule_support       NUMBER
  ,rule_confidence    NUMBER
  ,antecedent_support NUMBER
  ,consequent_support NUMBER
  ,number_of_items    INTEGER);
/

