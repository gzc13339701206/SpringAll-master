create TYPE DM_Histogram_bin AS OBJECT
  (attribute_name VARCHAR2(30)
  ,bin_id         NUMBER
  ,lower_bound    NUMBER
  ,upper_bound    NUMBER
  ,label          VARCHAR2(4000)
  ,count          NUMBER
  )
/

