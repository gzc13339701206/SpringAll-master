create TYPE DM_Model_Setting AS OBJECT
  (setting_name  VARCHAR2(30)
  ,setting_value VARCHAR2(128))
/

