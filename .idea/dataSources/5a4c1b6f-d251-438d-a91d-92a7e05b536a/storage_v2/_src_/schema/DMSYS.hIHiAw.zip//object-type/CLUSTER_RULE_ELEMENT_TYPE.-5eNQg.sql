create TYPE cluster_rule_element_type AUTHID CURRENT_USER AS OBJECT
  (attribute_name        VARCHAR2(30)
  ,attribute_id          NUMBER(6)
  ,attribute_relevance   NUMBER
  ,record_count          NUMBER(10)
  ,entries               dmsys.cl_predicate_tab_type
  )
/

