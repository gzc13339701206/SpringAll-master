create TYPE predicate_type AUTHID CURRENT_USER AS OBJECT
  (attribute_name        VARCHAR2(30)
  ,attribute_id          NUMBER(6)
  ,comparison_function   NUMBER(2)
  ,value                 dmsys.category_tab_type
  )
/

