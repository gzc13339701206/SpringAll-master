create TYPE histogram_entry_type AUTHID CURRENT_USER AS OBJECT
  (count                 NUMBER
  ,value                 NUMBER(5)
  )
/

