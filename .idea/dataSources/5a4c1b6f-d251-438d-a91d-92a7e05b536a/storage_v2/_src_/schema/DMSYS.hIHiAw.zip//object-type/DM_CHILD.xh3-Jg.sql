create TYPE DM_Child AS OBJECT
  (id NUMBER
  )
/

