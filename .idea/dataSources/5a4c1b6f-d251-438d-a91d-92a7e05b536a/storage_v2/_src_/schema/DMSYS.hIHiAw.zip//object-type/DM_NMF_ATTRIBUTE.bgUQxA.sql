create TYPE DM_NMF_Attribute AS OBJECT
  (attribute_name  VARCHAR2(30)
  ,attribute_value VARCHAR2(4000)
  ,coefficient     NUMBER)
/

