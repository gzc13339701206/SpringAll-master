create TYPE category_type AUTHID CURRENT_USER AS OBJECT
  (value                 NUMBER(5)
  )
/

