create TYPE DM_ItemSet AS OBJECT
  (itemset_id      INTEGER
  ,items           DM_Items
  ,support         NUMBER
  ,number_of_items NUMBER);
/

