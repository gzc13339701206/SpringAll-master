create TYPE Cluster_rule_type AUTHID CURRENT_USER AS OBJECT
  (cluster_id            NUMBER(7)
  ,record_count          NUMBER(10)
  ,antecedent            dmsys.cluster_rule_element_tab_type
  )
/

