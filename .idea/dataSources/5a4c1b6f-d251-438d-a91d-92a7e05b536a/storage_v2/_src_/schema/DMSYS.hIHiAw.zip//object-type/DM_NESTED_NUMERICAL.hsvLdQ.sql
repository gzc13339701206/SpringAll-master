create TYPE DM_Nested_Numerical AS OBJECT
  (attribute_name VARCHAR2(30)
  ,value          NUMBER)
/

