create TYPE cl_predicate_type AUTHID CURRENT_USER AS OBJECT
  (comparison_function   NUMBER(2)
  ,value                 dmsys.category_tab_type
  )
/

