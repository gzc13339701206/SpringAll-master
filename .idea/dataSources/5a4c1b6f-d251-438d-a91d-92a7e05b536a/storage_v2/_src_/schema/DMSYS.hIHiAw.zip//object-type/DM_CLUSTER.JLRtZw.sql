create TYPE DM_Cluster AS OBJECT
  (id               NUMBER
  ,record_count     NUMBER
  ,parent           NUMBER
  ,tree_level       NUMBER
  ,dispersion       NUMBER
  ,split_predicate  DM_Predicates
  ,child            DM_Children
  ,centroid         DM_Centroids
  ,histogram        DM_Histograms
  ,rule             DM_rule
  )
/

