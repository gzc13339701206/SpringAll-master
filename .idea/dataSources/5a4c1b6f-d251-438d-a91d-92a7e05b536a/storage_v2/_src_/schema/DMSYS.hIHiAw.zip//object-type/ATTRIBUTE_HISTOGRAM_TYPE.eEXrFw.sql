create TYPE attribute_histogram_type AUTHID CURRENT_USER AS OBJECT
  (attribute_name        VARCHAR2(32)
  ,attribute_id          NUMBER(6)
  ,entries               dmsys.histogram_entry_tab_type
  )
/

