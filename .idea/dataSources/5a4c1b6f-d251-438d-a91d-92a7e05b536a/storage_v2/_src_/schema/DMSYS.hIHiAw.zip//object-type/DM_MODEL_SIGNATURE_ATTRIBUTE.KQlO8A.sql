create TYPE DM_Model_Signature_Attribute AS OBJECT
  (attribute_name VARCHAR2(30)
  ,attribute_type VARCHAR2(106));
/

