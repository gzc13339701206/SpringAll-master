create TYPE DM_Predicate AUTHID CURRENT_USER AS OBJECT
  (attribute_name       VARCHAR2(30)
  ,conditional_operator CHAR(2) /* =, <>, <, >, <=, >= */
  ,attribute_num_value  NUMBER
  ,attribute_str_value  VARCHAR2(4000)
  ,attribute_support    NUMBER
  ,attribute_confidence NUMBER)
/

