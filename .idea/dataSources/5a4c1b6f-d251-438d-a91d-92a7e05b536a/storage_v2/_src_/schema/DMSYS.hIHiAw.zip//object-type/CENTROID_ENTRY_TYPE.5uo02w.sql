create TYPE centroid_entry_type AUTHID CURRENT_USER AS OBJECT
  (attribute_name        VARCHAR2(30)
  ,attribute_id          NUMBER(6)
  ,value                 NUMBER(5)
  )
/

