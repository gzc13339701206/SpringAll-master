create view DM_USER_MODELS as
  (SELECT name,
        function_name,
        algorithm_name,
        ctime creation_date,
        build_duration,
        target_attribute,
  model_size
   FROM dm$p_model
  WHERE owner# = SYS_CONTEXT('USERENV','CURRENT_USERID'))
/

