create PACKAGE dbms_predictive_analytics AUTHID CURRENT_USER AS
  --
  -- PUBLIC PROCEDURES AND FUNCTIONS
  --

  -- Procedure: PREDICT
  -- The purpose of this procedure is to produce predictions for unknown targets.
  -- The input data table should contain records where the target value is known (not null).
  -- The known cases will be used to train and test a model. Any cases where the target
  -- is unknown, i.e. where the target value is null, will not be considered during model
  -- training. Once a mining model is built internally, it will be used to score all the
  -- records from the input data (both known and unknown), and a table will be persisted
  -- containing the results. In the case of binary classification, an ROC analysis of the
  -- results will be performed, and the predictions will be adjusted to support the optimal
  -- probability threshold resulting in the highest True Positive Rate (TPR) versus False
  -- Positive Rate (FPR).
  PROCEDURE predict(
                  accuracy            OUT NUMBER,
                  data_table_name     IN VARCHAR2,
                  case_id_column_name IN VARCHAR2,
                  target_column_name  IN VARCHAR2,
                  result_table_name   IN VARCHAR2,
                  data_schema_name    IN VARCHAR2 DEFAULT NULL);

  -- Procedure: EXPLAIN
  -- This procedure is used for identifying attributes that are important/useful for
  -- explaining the variation on an attribute of interest (e.g., a measure of an OLAP
  -- fact table). Only known cases (i.e. cases where the value of the explain column is
  -- not null) will be taken into consideration when assessing the importance of the input
  -- attributes upon the dependent attribute. The resulting table will contain one row for
  -- each of the input attributes.
  PROCEDURE explain(
                  data_table_name     IN VARCHAR2,
                  explain_column_name IN VARCHAR2,
                  result_table_name   IN VARCHAR2,
                  data_schema_name    IN VARCHAR2 DEFAULT NULL);

END dbms_predictive_analytics;
/

