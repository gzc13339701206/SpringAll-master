create TYPE dm_ranked_attribute AS OBJECT
  (attribute_name    VARCHAR2(30),
   importance_value  NUMBER,
   rank              NUMBER(38))
/

