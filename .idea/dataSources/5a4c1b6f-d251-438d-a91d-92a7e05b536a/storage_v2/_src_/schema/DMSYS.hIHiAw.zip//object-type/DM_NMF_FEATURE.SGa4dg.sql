create TYPE DM_NMF_Feature AS OBJECT
  (feature_id    NUMBER
  ,attribute_set DM_NMF_Attribute_Set)
/

