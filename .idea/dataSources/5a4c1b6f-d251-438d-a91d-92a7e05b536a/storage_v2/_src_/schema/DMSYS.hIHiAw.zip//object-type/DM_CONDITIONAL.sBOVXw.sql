create TYPE DM_Conditional AS OBJECT
  (attribute_name          VARCHAR2(30)
  ,attribute_str_value     VARCHAR2(4000)
  ,attribute_num_value     NUMBER
  ,conditional_probability NUMBER)
/

