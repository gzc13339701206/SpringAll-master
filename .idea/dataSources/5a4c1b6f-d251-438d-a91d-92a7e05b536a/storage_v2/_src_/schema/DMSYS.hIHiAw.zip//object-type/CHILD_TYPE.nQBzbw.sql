create TYPE child_type AUTHID CURRENT_USER AS OBJECT
  (id                    NUMBER(7)
  )
/

