create TYPE DM_ABN_Detail AS OBJECT
  (rule_id      INTEGER
  ,antecedent   DM_Predicates
  ,consequent   DM_Predicates
  ,rule_support NUMBER)
/

