create TYPE DM_Nested_Categorical AS OBJECT
  (attribute_name VARCHAR2(30)
  ,value          VARCHAR2(4000))
/

