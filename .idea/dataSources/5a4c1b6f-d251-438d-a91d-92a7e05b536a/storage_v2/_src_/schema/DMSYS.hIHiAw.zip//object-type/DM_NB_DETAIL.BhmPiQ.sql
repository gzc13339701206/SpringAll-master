create TYPE DM_NB_Detail AS OBJECT
  (target_attribute_name      VARCHAR2(30)
  ,target_attribute_str_value VARCHAR2(4000)
  ,target_attribute_num_value NUMBER
  ,prior_probability          NUMBER
  ,conditionals               DM_Conditionals)
/

