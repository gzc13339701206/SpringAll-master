create TYPE DM_Centroid AS OBJECT
  (attribute_name VARCHAR2(30)
  ,mean           NUMBER
  ,mode_value     VARCHAR2(4000)
  ,variance       NUMBER
  )
/

