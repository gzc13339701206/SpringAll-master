create TYPE DM_SVM_Linear_Coeff AS OBJECT
  (class         VARCHAR2(4000)
  ,attribute_set DM_SVM_Attribute_Set)
/

