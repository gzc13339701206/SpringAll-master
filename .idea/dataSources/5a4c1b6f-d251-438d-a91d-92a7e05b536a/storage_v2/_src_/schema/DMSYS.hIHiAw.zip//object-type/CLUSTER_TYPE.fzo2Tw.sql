create TYPE cluster_type AUTHID CURRENT_USER AS OBJECT
  (id                    NUMBER(7)
  ,record_count          NUMBER(10)
  ,tree_level            NUMBER(7)
  ,parent                NUMBER(7)
  ,split_predicate       dmsys.predicate_tab_type
  ,centroid              dmsys.centroid_tab_type
  ,histogram             dmsys.attribute_histogram_tab_type
  ,child                 dmsys.child_tab_type
  )
/

